ALTER TABLE public.crews ADD COLUMN IF NOT EXISTS color text;
ALTER TABLE public.schedules ADD COLUMN IF NOT EXISTS color text;