
-- ============================================================
-- Phase 2.1 — Financial Capacity Engine
-- Additive schema changes only.
-- ============================================================

-- ---------- Enums (guarded) ----------
DO $$ BEGIN
  CREATE TYPE public.billing_method AS ENUM ('fixed_price','hourly','variation','progress');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.revenue_allocation_method AS ENUM ('start_month','prorated_dates','prorated_progress');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.revenue_recognition_method AS ENUM ('on_completion','progress_percent','milestone');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.target_scope AS ENUM ('company','crew','division','region','business_unit');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.target_period AS ENUM ('month','week','day');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ---------- Extend jobs ----------
ALTER TABLE public.jobs
  ADD COLUMN IF NOT EXISTS contract_value numeric(14,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS forecast_revenue numeric(14,2),
  ADD COLUMN IF NOT EXISTS billing_method public.billing_method DEFAULT 'fixed_price',
  ADD COLUMN IF NOT EXISTS retention_pct numeric(5,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS revenue_category text,
  ADD COLUMN IF NOT EXISTS business_unit text,
  ADD COLUMN IF NOT EXISTS division text,
  ADD COLUMN IF NOT EXISTS region text,
  ADD COLUMN IF NOT EXISTS priority text,
  ADD COLUMN IF NOT EXISTS job_type text,
  ADD COLUMN IF NOT EXISTS estimated_labour_hours numeric(10,2),
  ADD COLUMN IF NOT EXISTS estimated_duration_days integer,
  ADD COLUMN IF NOT EXISTS estimated_productivity numeric(10,2);

-- ---------- Extend crews ----------
ALTER TABLE public.crews
  ADD COLUMN IF NOT EXISTS business_unit text,
  ADD COLUMN IF NOT EXISTS division text,
  ADD COLUMN IF NOT EXISTS region text,
  ADD COLUMN IF NOT EXISTS monthly_revenue_target numeric(14,2),
  ADD COLUMN IF NOT EXISTS weekly_revenue_target numeric(14,2);

-- ============================================================
-- revenue_targets
-- ============================================================
CREATE TABLE IF NOT EXISTS public.revenue_targets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope public.target_scope NOT NULL DEFAULT 'company',
  scope_ref text,                          -- crew id / division name / region name; null for company
  period public.target_period NOT NULL DEFAULT 'month',
  period_start date NOT NULL,              -- first day of the target period
  target_amount numeric(14,2) NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (scope, scope_ref, period, period_start)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.revenue_targets TO anon, authenticated;
GRANT ALL ON public.revenue_targets TO service_role;

ALTER TABLE public.revenue_targets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "revenue_targets open" ON public.revenue_targets;
CREATE POLICY "revenue_targets open" ON public.revenue_targets
  FOR ALL USING (true) WITH CHECK (true);

DROP TRIGGER IF EXISTS trg_revenue_targets_updated_at ON public.revenue_targets;
CREATE TRIGGER trg_revenue_targets_updated_at
BEFORE UPDATE ON public.revenue_targets
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS idx_revenue_targets_lookup
  ON public.revenue_targets (scope, scope_ref, period, period_start);

-- ============================================================
-- app_settings (single-row config)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.app_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  singleton boolean NOT NULL DEFAULT true UNIQUE,
  revenue_allocation_method public.revenue_allocation_method NOT NULL DEFAULT 'prorated_progress',
  revenue_recognition_method public.revenue_recognition_method NOT NULL DEFAULT 'progress_percent',
  traffic_light_green_pct numeric(5,2) NOT NULL DEFAULT 95,   -- >= green
  traffic_light_amber_pct numeric(5,2) NOT NULL DEFAULT 80,   -- >= amber, else red
  capacity_near_pct numeric(5,2) NOT NULL DEFAULT 70,
  capacity_full_pct numeric(5,2) NOT NULL DEFAULT 90,
  financial_year_start_month smallint NOT NULL DEFAULT 7,     -- AU FY default
  progress_billing_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_settings TO anon, authenticated;
GRANT ALL ON public.app_settings TO service_role;

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "app_settings open" ON public.app_settings;
CREATE POLICY "app_settings open" ON public.app_settings
  FOR ALL USING (true) WITH CHECK (true);

DROP TRIGGER IF EXISTS trg_app_settings_updated_at ON public.app_settings;
CREATE TRIGGER trg_app_settings_updated_at
BEFORE UPDATE ON public.app_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Seed the singleton row if missing
INSERT INTO public.app_settings (singleton)
SELECT true
WHERE NOT EXISTS (SELECT 1 FROM public.app_settings);

-- ============================================================
-- Seed a demo company monthly target for the current month
-- so the new dashboard KPIs have something meaningful to show.
-- ============================================================
INSERT INTO public.revenue_targets (scope, scope_ref, period, period_start, target_amount, notes)
SELECT 'company', NULL, 'month', date_trunc('month', now())::date, 750000, 'Seeded default company target'
WHERE NOT EXISTS (
  SELECT 1 FROM public.revenue_targets
  WHERE scope = 'company' AND period = 'month'
    AND period_start = date_trunc('month', now())::date
);
