
-- Allow first-user bootstrap: any authenticated user may insert their own role
-- ONLY while no owner exists yet. Once an owner is set, only admin/owner can manage roles.
CREATE POLICY "Bootstrap first owner"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id
  AND NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'owner')
);
