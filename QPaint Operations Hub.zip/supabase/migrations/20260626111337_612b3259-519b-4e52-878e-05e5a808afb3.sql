
-- Enum for pipeline stages
DO $$ BEGIN
  CREATE TYPE public.deal_stage AS ENUM (
    'Lead Received',
    'Contact Qualified',
    'Site Visit Booked',
    'Site Visit Completed',
    'Quote Review',
    'Quote Sent'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.deal_priority AS ENUM ('Low','Normal','High','Urgent');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id text NOT NULL UNIQUE,
  client_name text NOT NULL,
  property_address text,
  contact_person text,
  phone text,
  email text,
  owner text,
  client_ranking text,
  category text,
  quote_type text,
  referral_source text,
  extent_of_work text,
  description text,
  appointment_date date,
  appointment_time time,
  estimator text,
  site_visit_status text,
  site_visit_notes text,
  quote_status text,
  quote_sent_date date,
  expected_value numeric(12,2) DEFAULT 0,
  target_hours numeric(8,2),
  actual_hours numeric(8,2),
  quote_notes text,
  google_maps_link text,
  google_drive_link text,
  stage public.deal_stage NOT NULL DEFAULT 'Lead Received',
  priority public.deal_priority NOT NULL DEFAULT 'Normal',
  last_activity_at timestamptz,
  next_activity_at timestamptz,
  converted_job_id uuid REFERENCES public.jobs(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.deals TO authenticated;
GRANT ALL ON public.deals TO service_role;

ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "deals_authenticated_all" ON public.deals
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TRIGGER deals_set_updated_at
  BEFORE UPDATE ON public.deals
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.deal_stage_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES public.deals(id) ON DELETE CASCADE,
  from_stage public.deal_stage,
  to_stage public.deal_stage NOT NULL,
  changed_by uuid,
  changed_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.deal_stage_history TO authenticated;
GRANT ALL ON public.deal_stage_history TO service_role;

ALTER TABLE public.deal_stage_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "deal_stage_history_read" ON public.deal_stage_history
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "deal_stage_history_insert" ON public.deal_stage_history
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS deals_stage_idx ON public.deals(stage);
CREATE INDEX IF NOT EXISTS deal_stage_history_deal_idx ON public.deal_stage_history(deal_id, changed_at DESC);

-- Link a scheduled job back to its CRM deal
ALTER TABLE public.jobs
  ADD COLUMN IF NOT EXISTS source_deal_id uuid REFERENCES public.deals(id) ON DELETE SET NULL;
