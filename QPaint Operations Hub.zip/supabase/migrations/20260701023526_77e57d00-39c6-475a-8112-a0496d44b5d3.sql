ALTER TABLE public.pipelines       ADD COLUMN IF NOT EXISTS pipedrive_id bigint UNIQUE, ADD COLUMN IF NOT EXISTS synced_at timestamptz;
ALTER TABLE public.pipeline_stages ADD COLUMN IF NOT EXISTS pipedrive_id bigint UNIQUE, ADD COLUMN IF NOT EXISTS synced_at timestamptz;
ALTER TABLE public.contacts        ADD COLUMN IF NOT EXISTS pipedrive_id bigint UNIQUE, ADD COLUMN IF NOT EXISTS synced_at timestamptz;
ALTER TABLE public.deals           ADD COLUMN IF NOT EXISTS pipedrive_id bigint UNIQUE, ADD COLUMN IF NOT EXISTS synced_at timestamptz, ADD COLUMN IF NOT EXISTS pipedrive_org_name text, ADD COLUMN IF NOT EXISTS pipedrive_status text, ADD COLUMN IF NOT EXISTS pipedrive_owner_name text;

CREATE TABLE IF NOT EXISTS public.sync_state (
  source text PRIMARY KEY,
  last_run_at timestamptz,
  last_status text,
  last_error text,
  stats jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.sync_state TO authenticated, anon;
GRANT ALL ON public.sync_state TO service_role;
ALTER TABLE public.sync_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sync_state readable" ON public.sync_state FOR SELECT USING (true);