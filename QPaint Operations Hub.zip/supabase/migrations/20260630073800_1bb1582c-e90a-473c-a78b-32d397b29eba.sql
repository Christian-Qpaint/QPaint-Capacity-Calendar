
-- 1. Contacts table
CREATE TABLE public.contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text,
  phone text,
  address text,
  company text,
  ranking text,
  source text,
  notes text,
  total_deals integer NOT NULL DEFAULT 0,
  total_jobs integer NOT NULL DEFAULT 0,
  lifetime_value numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.contacts TO authenticated;
GRANT SELECT ON public.contacts TO anon;
GRANT ALL ON public.contacts TO service_role;

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "contacts_read_all" ON public.contacts FOR SELECT USING (true);
CREATE POLICY "contacts_write_auth" ON public.contacts FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TRIGGER contacts_set_updated_at
BEFORE UPDATE ON public.contacts
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE UNIQUE INDEX contacts_email_unique ON public.contacts (lower(email)) WHERE email IS NOT NULL AND length(email) > 0;
CREATE INDEX contacts_phone_idx ON public.contacts (phone);
CREATE INDEX contacts_name_idx ON public.contacts (lower(name));

-- 2. Add contact_id to deals & jobs
ALTER TABLE public.deals ADD COLUMN contact_id uuid REFERENCES public.contacts(id) ON DELETE SET NULL;
ALTER TABLE public.jobs  ADD COLUMN contact_id uuid REFERENCES public.contacts(id) ON DELETE SET NULL;

CREATE INDEX deals_contact_id_idx ON public.deals (contact_id);
CREATE INDEX jobs_contact_id_idx  ON public.jobs (contact_id);

-- 3. Auto-create/link contact function
CREATE OR REPLACE FUNCTION public.ensure_contact_for_record()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_name text;
  v_email text;
  v_phone text;
  v_address text;
  v_ranking text;
  v_source text;
  v_contact_id uuid;
BEGIN
  IF TG_TABLE_NAME = 'deals' THEN
    v_name    := COALESCE(NULLIF(NEW.contact_person, ''), NULLIF(NEW.client_name, ''));
    v_email   := NULLIF(NEW.email, '');
    v_phone   := NULLIF(NEW.phone, '');
    v_address := NULLIF(NEW.property_address, '');
    v_ranking := NEW.client_ranking;
    v_source  := NEW.referral_source;
  ELSE
    v_name    := COALESCE(NULLIF(NEW.client_contact, ''), NULLIF(NEW.client_name, ''));
    v_address := NULLIF(NEW.location, '');
  END IF;

  IF NEW.contact_id IS NOT NULL THEN
    RETURN NEW;
  END IF;

  IF v_name IS NULL AND v_email IS NULL AND v_phone IS NULL THEN
    RETURN NEW;
  END IF;

  -- Match by email first, then by phone+name
  IF v_email IS NOT NULL THEN
    SELECT id INTO v_contact_id FROM public.contacts WHERE lower(email) = lower(v_email) LIMIT 1;
  END IF;

  IF v_contact_id IS NULL AND v_phone IS NOT NULL AND v_name IS NOT NULL THEN
    SELECT id INTO v_contact_id FROM public.contacts
     WHERE phone = v_phone AND lower(name) = lower(v_name) LIMIT 1;
  END IF;

  IF v_contact_id IS NULL THEN
    INSERT INTO public.contacts (name, email, phone, address, ranking, source)
    VALUES (COALESCE(v_name, 'Unnamed Contact'), v_email, v_phone, v_address, v_ranking, v_source)
    RETURNING id INTO v_contact_id;
  ELSE
    -- Enrich missing fields
    UPDATE public.contacts SET
      email   = COALESCE(email, v_email),
      phone   = COALESCE(phone, v_phone),
      address = COALESCE(address, v_address),
      ranking = COALESCE(ranking, v_ranking),
      source  = COALESCE(source, v_source)
    WHERE id = v_contact_id;
  END IF;

  NEW.contact_id := v_contact_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER deals_ensure_contact
BEFORE INSERT OR UPDATE OF client_name, contact_person, email, phone ON public.deals
FOR EACH ROW EXECUTE FUNCTION public.ensure_contact_for_record();

CREATE TRIGGER jobs_ensure_contact
BEFORE INSERT OR UPDATE OF client_name, client_contact, location ON public.jobs
FOR EACH ROW EXECUTE FUNCTION public.ensure_contact_for_record();

-- 4. Recompute aggregate counters
CREATE OR REPLACE FUNCTION public.recompute_contact_stats(p_contact_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_contact_id IS NULL THEN RETURN; END IF;
  UPDATE public.contacts c SET
    total_deals = (SELECT count(*) FROM public.deals d WHERE d.contact_id = p_contact_id),
    total_jobs  = (SELECT count(*) FROM public.jobs  j WHERE j.contact_id = p_contact_id),
    lifetime_value = COALESCE((SELECT sum(expected_value) FROM public.deals d WHERE d.contact_id = p_contact_id), 0)
  WHERE c.id = p_contact_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.trg_recompute_contact_stats()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM public.recompute_contact_stats(OLD.contact_id);
    RETURN OLD;
  ELSE
    PERFORM public.recompute_contact_stats(NEW.contact_id);
    IF TG_OP = 'UPDATE' AND OLD.contact_id IS DISTINCT FROM NEW.contact_id THEN
      PERFORM public.recompute_contact_stats(OLD.contact_id);
    END IF;
    RETURN NEW;
  END IF;
END;
$$;

CREATE TRIGGER deals_recompute_contact AFTER INSERT OR UPDATE OF contact_id, expected_value OR DELETE ON public.deals
FOR EACH ROW EXECUTE FUNCTION public.trg_recompute_contact_stats();

CREATE TRIGGER jobs_recompute_contact AFTER INSERT OR UPDATE OF contact_id OR DELETE ON public.jobs
FOR EACH ROW EXECUTE FUNCTION public.trg_recompute_contact_stats();

-- 5. Backfill existing deals & jobs
UPDATE public.deals SET client_name = client_name WHERE contact_id IS NULL;
UPDATE public.jobs  SET client_name = client_name WHERE contact_id IS NULL;
