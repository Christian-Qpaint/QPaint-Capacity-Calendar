
-- ============================================================
-- Part 1: extend deals with job-execution columns
-- ============================================================
ALTER TABLE public.deals
  ADD COLUMN IF NOT EXISTS start_date date,
  ADD COLUMN IF NOT EXISTS target_finish_date date,
  ADD COLUMN IF NOT EXISTS hours_worked numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS completion_percentage integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS billing_status text NOT NULL DEFAULT 'Not Ready',
  ADD COLUMN IF NOT EXISTS assigned_crew_id uuid REFERENCES public.crews(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS supervisor_id uuid REFERENCES public.staff(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS job_notes text;

-- ============================================================
-- Part 2: create job_notes + job_blockers, keyed to deals
-- ============================================================
CREATE TABLE IF NOT EXISTS public.job_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES public.deals(id) ON DELETE CASCADE,
  author_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  author_name text,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_notes TO authenticated;
GRANT ALL ON public.job_notes TO service_role;
ALTER TABLE public.job_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can read job notes" ON public.job_notes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can write job notes" ON public.job_notes FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER job_notes_updated_at BEFORE UPDATE ON public.job_notes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX IF NOT EXISTS job_notes_deal_id_idx ON public.job_notes(deal_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.job_blockers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES public.deals(id) ON DELETE CASCADE,
  kind text NOT NULL DEFAULT 'other',           -- weather | material | client | crew | other
  label text NOT NULL,
  body text,
  tone text NOT NULL DEFAULT 'warning',         -- warning | critical
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_blockers TO authenticated;
GRANT ALL ON public.job_blockers TO service_role;
ALTER TABLE public.job_blockers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can read blockers" ON public.job_blockers FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can write blockers" ON public.job_blockers FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER job_blockers_updated_at BEFORE UPDATE ON public.job_blockers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX IF NOT EXISTS job_blockers_deal_id_idx ON public.job_blockers(deal_id, resolved_at NULLS FIRST, created_at DESC);

-- ============================================================
-- Part 3: destructive — wipe dependent rows & re-point FKs
-- ============================================================
DELETE FROM public.schedules;
DELETE FROM public.job_contractor_assignments;
DELETE FROM public.job_milestones;
DELETE FROM public.job_progress_updates;
DELETE FROM public.billing_reports;

ALTER TABLE public.schedules DROP CONSTRAINT IF EXISTS schedules_job_id_fkey;
ALTER TABLE public.schedules ADD CONSTRAINT schedules_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.deals(id) ON DELETE CASCADE;

ALTER TABLE public.job_contractor_assignments DROP CONSTRAINT IF EXISTS job_contractor_assignments_job_id_fkey;
ALTER TABLE public.job_contractor_assignments ADD CONSTRAINT job_contractor_assignments_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.deals(id) ON DELETE CASCADE;

ALTER TABLE public.job_milestones DROP CONSTRAINT IF EXISTS job_milestones_job_id_fkey;
ALTER TABLE public.job_milestones ADD CONSTRAINT job_milestones_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.deals(id) ON DELETE CASCADE;

ALTER TABLE public.job_progress_updates DROP CONSTRAINT IF EXISTS job_progress_updates_job_id_fkey;
ALTER TABLE public.job_progress_updates ADD CONSTRAINT job_progress_updates_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.deals(id) ON DELETE CASCADE;

ALTER TABLE public.billing_reports DROP CONSTRAINT IF EXISTS billing_reports_job_id_fkey;
ALTER TABLE public.billing_reports ADD CONSTRAINT billing_reports_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.deals(id) ON DELETE CASCADE;

-- deals.converted_job_id used to point to jobs; no longer meaningful, drop the FK
ALTER TABLE public.deals DROP CONSTRAINT IF EXISTS deals_converted_job_id_fkey;

-- Drop the retired jobs table
DROP TABLE IF EXISTS public.jobs CASCADE;
