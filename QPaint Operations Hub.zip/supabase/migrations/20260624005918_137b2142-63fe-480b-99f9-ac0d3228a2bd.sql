
-- ===== ENUMS =====
CREATE TYPE public.job_status AS ENUM ('Not Started','Scheduled','In Progress','Delayed','On Hold','Completed');
CREATE TYPE public.billing_status AS ENUM ('Not Ready','Ready for Invoice','Invoiced','Paid');
CREATE TYPE public.crew_status AS ENUM ('Available','Partially Booked','Fully Booked','Overbooked','On Leave');
CREATE TYPE public.staff_status AS ENUM ('Active','On Leave','Sick','Inactive');
CREATE TYPE public.schedule_status AS ENUM ('Planned','In Progress','Completed','Cancelled');
CREATE TYPE public.availability_status AS ENUM ('Available','Assigned','Leave','Sick','Unavailable','Training');
CREATE TYPE public.blocker_type AS ENUM ('None','Weather','Client Delay','Material Delay','Staff Shortage','Access','Other');

-- ===== updated_at helper =====
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- ===== CREWS =====
CREATE TABLE public.crews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  leader_id UUID,
  crew_type TEXT,
  weekly_capacity_hours NUMERIC(6,2) NOT NULL DEFAULT 152,
  status public.crew_status NOT NULL DEFAULT 'Available',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.crews TO authenticated, anon;
GRANT ALL ON public.crews TO service_role;
ALTER TABLE public.crews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "crews open" ON public.crews FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_crews_updated BEFORE UPDATE ON public.crews FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ===== STAFF =====
CREATE TABLE public.staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  role TEXT,
  skills TEXT[] NOT NULL DEFAULT '{}',
  crew_id UUID REFERENCES public.crews(id) ON DELETE SET NULL,
  normal_hours_per_week NUMERIC(5,2) NOT NULL DEFAULT 38,
  contact_number TEXT,
  email TEXT,
  status public.staff_status NOT NULL DEFAULT 'Active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staff TO authenticated, anon;
GRANT ALL ON public.staff TO service_role;
ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff open" ON public.staff FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_staff_updated BEFORE UPDATE ON public.staff FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- crews.leader_id FK (deferred so staff exists)
ALTER TABLE public.crews ADD CONSTRAINT crews_leader_fk FOREIGN KEY (leader_id) REFERENCES public.staff(id) ON DELETE SET NULL;

-- ===== JOBS =====
CREATE TABLE public.jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_code TEXT NOT NULL UNIQUE,
  client_name TEXT NOT NULL,
  job_name TEXT NOT NULL,
  location TEXT,
  client_contact TEXT,
  start_date DATE,
  target_finish_date DATE,
  estimated_hours NUMERIC(7,2) NOT NULL DEFAULT 0,
  hours_worked NUMERIC(7,2) NOT NULL DEFAULT 0,
  completion_percentage NUMERIC(5,2) NOT NULL DEFAULT 0 CHECK (completion_percentage BETWEEN 0 AND 100),
  status public.job_status NOT NULL DEFAULT 'Not Started',
  billing_status public.billing_status NOT NULL DEFAULT 'Not Ready',
  assigned_crew_id UUID REFERENCES public.crews(id) ON DELETE SET NULL,
  supervisor_id UUID REFERENCES public.staff(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.jobs TO authenticated, anon;
GRANT ALL ON public.jobs TO service_role;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "jobs open" ON public.jobs FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_jobs_updated BEFORE UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX idx_jobs_status ON public.jobs(status);
CREATE INDEX idx_jobs_crew ON public.jobs(assigned_crew_id);

-- ===== SCHEDULES =====
CREATE TABLE public.schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  crew_id UUID REFERENCES public.crews(id) ON DELETE SET NULL,
  staff_ids UUID[] NOT NULL DEFAULT '{}',
  scheduled_date DATE NOT NULL,
  start_time TIME,
  end_time TIME,
  planned_hours NUMERIC(5,2) NOT NULL DEFAULT 0,
  actual_hours NUMERIC(5,2),
  status public.schedule_status NOT NULL DEFAULT 'Planned',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.schedules TO authenticated, anon;
GRANT ALL ON public.schedules TO service_role;
ALTER TABLE public.schedules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "schedules open" ON public.schedules FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_schedules_updated BEFORE UPDATE ON public.schedules FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX idx_schedules_date ON public.schedules(scheduled_date);
CREATE INDEX idx_schedules_crew_date ON public.schedules(crew_id, scheduled_date);

-- ===== JOB PROGRESS UPDATES =====
CREATE TABLE public.job_progress_updates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  progress_percentage NUMERIC(5,2) NOT NULL CHECK (progress_percentage BETWEEN 0 AND 100),
  hours_worked NUMERIC(6,2) NOT NULL DEFAULT 0,
  update_note TEXT,
  blocker_type public.blocker_type NOT NULL DEFAULT 'None',
  updated_by UUID REFERENCES public.staff(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_progress_updates TO authenticated, anon;
GRANT ALL ON public.job_progress_updates TO service_role;
ALTER TABLE public.job_progress_updates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "progress open" ON public.job_progress_updates FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_progress_job ON public.job_progress_updates(job_id);

-- ===== STAFF AVAILABILITY =====
CREATE TABLE public.staff_availability (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id UUID NOT NULL REFERENCES public.staff(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  availability_status public.availability_status NOT NULL DEFAULT 'Available',
  available_hours NUMERIC(4,2) NOT NULL DEFAULT 8,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (staff_id, date)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staff_availability TO authenticated, anon;
GRANT ALL ON public.staff_availability TO service_role;
ALTER TABLE public.staff_availability ENABLE ROW LEVEL SECURITY;
CREATE POLICY "avail open" ON public.staff_availability FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_avail_updated BEFORE UPDATE ON public.staff_availability FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ===== JOB MILESTONES =====
CREATE TABLE public.job_milestones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  milestone_name TEXT NOT NULL,
  is_completed BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMPTZ,
  notes TEXT
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_milestones TO authenticated, anon;
GRANT ALL ON public.job_milestones TO service_role;
ALTER TABLE public.job_milestones ENABLE ROW LEVEL SECURITY;
CREATE POLICY "milestones open" ON public.job_milestones FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX idx_milestones_job ON public.job_milestones(job_id);

-- ===== BILLING REPORTS =====
CREATE TABLE public.billing_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  completion_percentage NUMERIC(5,2) NOT NULL DEFAULT 0,
  billing_status public.billing_status NOT NULL DEFAULT 'Not Ready',
  admin_notes TEXT,
  ready_for_invoice BOOLEAN NOT NULL DEFAULT false,
  invoice_sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.billing_reports TO authenticated, anon;
GRANT ALL ON public.billing_reports TO service_role;
ALTER TABLE public.billing_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "billing open" ON public.billing_reports FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER trg_billing_updated BEFORE UPDATE ON public.billing_reports FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX idx_billing_job ON public.billing_reports(job_id);

-- ===== SEED DATA =====
DO $$
DECLARE
  c_alpha UUID := gen_random_uuid();
  c_bravo UUID := gen_random_uuid();
  c_charlie UUID := gen_random_uuid();
  c_delta UUID := gen_random_uuid();
  c_echo UUID := gen_random_uuid();
  s_jordan UUID := gen_random_uuid();
  s_priya UUID := gen_random_uuid();
  s_marco UUID := gen_random_uuid();
  s_anna UUID := gen_random_uuid();
  s_tom UUID := gen_random_uuid();
  s_lila UUID := gen_random_uuid();
  s_ben UUID := gen_random_uuid();
  s_henry UUID := gen_random_uuid();
  s_sara UUID := gen_random_uuid();
  s_ravi UUID := gen_random_uuid();
  j1 UUID := gen_random_uuid();
  j2 UUID := gen_random_uuid();
  j3 UUID := gen_random_uuid();
  j4 UUID := gen_random_uuid();
  j5 UUID := gen_random_uuid();
  j6 UUID := gen_random_uuid();
BEGIN
  -- crews (leader_id set after staff insert)
  INSERT INTO public.crews (id, name, crew_type, weekly_capacity_hours, status, notes) VALUES
    (c_alpha,   'Residential Crew A', 'Residential', 190, 'Fully Booked',     'High-utilization crew'),
    (c_bravo,   'Residential Crew B', 'Residential', 152, 'Partially Booked', null),
    (c_charlie, 'Commercial Crew',    'Commercial',  228, 'Fully Booked',     'Specialises in office fitouts'),
    (c_delta,   'Touch-up Crew',      'Touch-up',    152, 'On Leave',         '2 painters on leave/sick'),
    (c_echo,    'Prep Team',          'Prep',        190, 'Available',        null);

  -- staff
  INSERT INTO public.staff (id, full_name, role, skills, crew_id, normal_hours_per_week, contact_number, email, status) VALUES
    (s_jordan, 'Jordan Mills',  'Crew Lead',  ARRAY['Interior','Exterior','Spray'],   c_alpha,   38, '0411 222 333', 'jordan@qpaint.com.au',  'Active'),
    (s_priya,  'Priya Shah',    'Crew Lead',  ARRAY['Interior','Heritage'],           c_bravo,   38, '0422 333 444', 'priya@qpaint.com.au',   'Active'),
    (s_marco,  'Marco Diaz',    'Crew Lead',  ARRAY['Commercial','Spray','Epoxy floors'], c_charlie, 38, '0433 444 555', 'marco@qpaint.com.au', 'Active'),
    (s_anna,   'Anna Kovac',    'Crew Lead',  ARRAY['Touch-up','Interior'],           c_delta,   38, '0444 555 666', 'anna@qpaint.com.au',    'Active'),
    (s_tom,    'Tom Becker',    'Crew Lead',  ARRAY['Prep','Exterior'],               c_echo,    38, '0455 666 777', 'tom@qpaint.com.au',     'Active'),
    (s_lila,   'Lila Nguyen',   'Painter',    ARRAY['Interior'],                       c_alpha,   38, '0466 777 888', 'lila@qpaint.com.au',    'Active'),
    (s_ben,    'Ben Carter',    'Painter',    ARRAY['Exterior','Roof'],                c_bravo,   38, '0477 888 999', 'ben@qpaint.com.au',     'On Leave'),
    (s_henry,  'Henry Liu',     'Apprentice', ARRAY['Prep','Interior'],                c_charlie, 38, '0488 999 000', 'henry@qpaint.com.au',   'Active'),
    (s_sara,   'Sara Okafor',   'Painter',    ARRAY['Interior','Touch-up'],            c_delta,   38, '0499 000 111', 'sara@qpaint.com.au',    'Sick'),
    (s_ravi,   'Ravi Khan',     'Painter',    ARRAY['Prep','Exterior'],                c_echo,    38, '0410 111 222', 'ravi@qpaint.com.au',    'Active');

  -- crew leaders
  UPDATE public.crews SET leader_id = s_jordan  WHERE id = c_alpha;
  UPDATE public.crews SET leader_id = s_priya   WHERE id = c_bravo;
  UPDATE public.crews SET leader_id = s_marco   WHERE id = c_charlie;
  UPDATE public.crews SET leader_id = s_anna    WHERE id = c_delta;
  UPDATE public.crews SET leader_id = s_tom     WHERE id = c_echo;

  -- jobs
  INSERT INTO public.jobs (id, job_code, client_name, job_name, location, client_contact, start_date, target_finish_date, estimated_hours, hours_worked, completion_percentage, status, billing_status, assigned_crew_id, supervisor_id, notes) VALUES
    (j1, 'QP-1042', 'Marina Heights HOA',  'Marina Heights Repaint',     '12 Marina Pde, Bondi',        'Sue Lim · 0400 111 222',    '2026-06-18', '2026-07-02', 510, 316, 62,  'In Progress', 'Not Ready',         c_alpha,   s_jordan, 'Weather risk Friday'),
    (j2, 'QP-1043', 'Lumen Hospitality',   'Cafe Lumen Interior',        '88 Oxford St, Paddington',    'Marc Chen · 0400 222 333',  '2026-06-26', '2026-06-30', 130,   0,  0,  'Scheduled',   'Not Ready',         c_bravo,   s_priya,  'Materials confirmed'),
    (j3, 'QP-1044', 'Northside Health',    'Northside Medical Fitout',   '5 Pacific Hwy, Chatswood',    'Dr Patel · 0400 333 444',   '2026-06-20', '2026-07-10', 905, 318, 35,  'In Progress', 'Not Ready',         c_charlie, s_marco,  'Variation pending'),
    (j4, 'QP-1045', 'Dept of Education',   'Wattle Primary School',      '210 Wattle Rd, Ryde',         'J. Reilly · 0400 444 555',  '2026-06-15', '2026-07-15', 670, 121, 18,  'On Hold',     'Not Ready',         c_delta,   s_anna,   'Client access delay'),
    (j5, 'QP-1039', 'Eastview Strata',     'Eastview Apartments',        '44 Eastview Ave, Coogee',     'K. Mehta · 0400 555 666',   '2026-05-28', '2026-06-22',1080,1080, 100, 'Completed',   'Ready for Invoice', c_alpha,   s_jordan, 'Sign-off received'),
    (j6, 'QP-1040', 'Harbour REIT',        'Harbour Office Tower L12',   '1 George St, Sydney',         'A. Webb · 0400 666 777',    '2026-05-30', '2026-06-20',1670,1670, 100, 'Completed',   'Invoiced',          c_charlie, s_marco,  'Invoice #INV-2208 sent');

  -- schedules (this week / next week)
  INSERT INTO public.schedules (job_id, crew_id, staff_ids, scheduled_date, start_time, end_time, planned_hours, actual_hours, status, notes) VALUES
    (j1, c_alpha,   ARRAY[s_jordan,s_lila],         '2026-06-24', '07:00','15:30', 8, 8,    'Completed',   'Second coat north wing'),
    (j1, c_alpha,   ARRAY[s_jordan,s_lila],         '2026-06-25', '07:00','15:30', 8, NULL, 'Planned',     null),
    (j1, c_alpha,   ARRAY[s_jordan,s_lila],         '2026-06-26', '07:00','15:30', 8, NULL, 'Planned',     'Weather watch'),
    (j2, c_bravo,   ARRAY[s_priya],                 '2026-06-26', '08:00','16:00', 8, NULL, 'Planned',     'Site mobilisation'),
    (j3, c_charlie, ARRAY[s_marco,s_henry],         '2026-06-24', '07:30','16:00', 8.5, 8,  'Completed',   'Ceilings level 3'),
    (j3, c_charlie, ARRAY[s_marco,s_henry],         '2026-06-25', '07:30','16:00', 8.5, NULL,'Planned',    null),
    (j4, c_delta,   ARRAY[s_anna],                  '2026-06-25', '08:00','12:00', 4, NULL, 'Planned',     'Awaiting site access');

  -- progress updates
  INSERT INTO public.job_progress_updates (job_id, progress_percentage, hours_worked, update_note, blocker_type, updated_by) VALUES
    (j1, 55, 280, 'First coat complete on north wing.',                       'None',           s_jordan),
    (j1, 62, 316, 'Second coat started, weather risk Friday.',                'Weather',        s_jordan),
    (j3, 28, 250, 'Level 2 ceilings done.',                                    'None',           s_marco),
    (j3, 35, 318, 'Variation requested by client — pending sign-off.',         'Client Delay',   s_marco),
    (j4, 18, 121, 'On hold — school facilities team blocking access.',         'Client Delay',   s_anna),
    (j5,100, 1080,'Final handover walkthrough complete.',                      'None',           s_jordan);

  -- staff availability (this week sample)
  INSERT INTO public.staff_availability (staff_id, date, availability_status, available_hours, reason) VALUES
    (s_ben,  '2026-06-24', 'Leave', 0, 'Annual leave'),
    (s_ben,  '2026-06-25', 'Leave', 0, 'Annual leave'),
    (s_ben,  '2026-06-26', 'Leave', 0, 'Annual leave'),
    (s_sara, '2026-06-24', 'Sick',  0, 'Flu'),
    (s_sara, '2026-06-25', 'Sick',  0, 'Flu'),
    (s_henry,'2026-06-26', 'Training', 4, 'Spray gun certification'),
    (s_ravi, '2026-06-24', 'Available', 8, null),
    (s_ravi, '2026-06-25', 'Available', 8, null);

  -- milestones
  INSERT INTO public.job_milestones (job_id, milestone_name, is_completed, completed_at, notes) VALUES
    (j1,'Site prep',       true,  '2026-06-19 16:00+10', null),
    (j1,'Surface prep',    true,  '2026-06-20 16:00+10', null),
    (j1,'First coat',      true,  '2026-06-22 16:00+10', null),
    (j1,'Second coat',     false, null,                    'In progress'),
    (j1,'Touch-ups',       false, null,                    null),
    (j1,'Client sign-off', false, null,                    null),
    (j3,'Site prep',       true,  '2026-06-20 16:00+10', null),
    (j3,'Ceilings',        true,  '2026-06-24 16:00+10', null),
    (j3,'Walls — first coat', false, null, 'Variation pending'),
    (j5,'Site prep',       true,  '2026-05-29 16:00+10', null),
    (j5,'All coats',       true,  '2026-06-20 16:00+10', null),
    (j5,'Client sign-off', true,  '2026-06-22 16:00+10', 'Signed by K. Mehta');

  -- billing reports
  INSERT INTO public.billing_reports (job_id, completion_percentage, billing_status, admin_notes, ready_for_invoice, invoice_sent_at) VALUES
    (j5, 100, 'Ready for Invoice', 'Final sign-off received; invoice ready to send.', true,  NULL),
    (j6, 100, 'Invoiced',          'Invoice #INV-2208 sent 2026-06-21.',              true,  '2026-06-21 09:30+10'),
    (j1,  62, 'Not Ready',         'Mid-project; progress claim due at 75%.',         false, NULL);
END $$;
