
-- Pipelines & stages (user-editable)
CREATE TABLE public.pipelines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  kind text NOT NULL DEFAULT 'custom', -- 'sales' | 'jobs' | 'custom'
  position int NOT NULL DEFAULT 0,
  color text,
  description text,
  -- When a deal lands in a pipeline with auto_schedule=true, a schedule row is auto-created
  auto_schedule boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pipelines TO authenticated;
GRANT SELECT ON public.pipelines TO anon;
GRANT ALL ON public.pipelines TO service_role;
ALTER TABLE public.pipelines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pipelines_read_all" ON public.pipelines FOR SELECT USING (true);
CREATE POLICY "pipelines_write_auth" ON public.pipelines FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.pipeline_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id uuid NOT NULL REFERENCES public.pipelines(id) ON DELETE CASCADE,
  name text NOT NULL,
  position int NOT NULL DEFAULT 0,
  color text,
  is_won boolean NOT NULL DEFAULT false,
  is_lost boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pipeline_stages TO authenticated;
GRANT SELECT ON public.pipeline_stages TO anon;
GRANT ALL ON public.pipeline_stages TO service_role;
ALTER TABLE public.pipeline_stages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stages_read_all" ON public.pipeline_stages FOR SELECT USING (true);
CREATE POLICY "stages_write_auth" ON public.pipeline_stages FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX pipeline_stages_pipeline_idx ON public.pipeline_stages(pipeline_id, position);

CREATE TRIGGER set_pipelines_updated_at BEFORE UPDATE ON public.pipelines
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER set_pipeline_stages_updated_at BEFORE UPDATE ON public.pipeline_stages
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Add pipeline references to deals; keep legacy `stage` enum for backward compat
ALTER TABLE public.deals
  ADD COLUMN pipeline_id uuid REFERENCES public.pipelines(id) ON DELETE SET NULL,
  ADD COLUMN pipeline_stage_id uuid REFERENCES public.pipeline_stages(id) ON DELETE SET NULL;
ALTER TABLE public.deals ALTER COLUMN stage DROP NOT NULL;
CREATE INDEX deals_pipeline_idx ON public.deals(pipeline_id, pipeline_stage_id);

-- Seed the two default pipelines + stages
WITH sales_pipe AS (
  INSERT INTO public.pipelines (name, kind, position, color, auto_schedule, description)
  VALUES ('Sales', 'sales', 0, '#3b82f6', false, 'Lead → quote sent')
  RETURNING id
), jobs_pipe AS (
  INSERT INTO public.pipelines (name, kind, position, color, auto_schedule, description)
  VALUES ('Jobs', 'jobs', 1, '#f97316', true, 'Operational delivery — items here appear on the Capacity Calendar')
  RETURNING id
)
INSERT INTO public.pipeline_stages (pipeline_id, name, position, color, is_won)
SELECT sales_pipe.id, s.name, s.pos, s.color, s.won FROM sales_pipe, (VALUES
  ('Lead Received',         0, '#64748b', false),
  ('Contact Qualified',     1, '#3b82f6', false),
  ('Site Visit Booked',     2, '#6366f1', false),
  ('Site Visit Completed',  3, '#8b5cf6', false),
  ('Quote Review',          4, '#f59e0b', false),
  ('Quote Sent',            5, '#10b981', true)
) AS s(name, pos, color, won)
UNION ALL
SELECT jobs_pipe.id, s.name, s.pos, s.color, s.won FROM jobs_pipe, (VALUES
  ('1. Admin',              0, '#64748b', false),
  ('2. Ready to Schedule',  1, '#3b82f6', false),
  ('3. Booked',             2, '#6366f1', false),
  ('4. In Progress',        3, '#f59e0b', false),
  ('5. Completed',          4, '#10b981', false),
  ('6. On Hold',            5, '#ef4444', false),
  ('7. All Done & Paid',    6, '#059669', true)
) AS s(name, pos, color, won);

-- Migrate existing deals.stage → pipeline_stage_id in Sales pipeline
UPDATE public.deals d
SET pipeline_id = ps.pipeline_id,
    pipeline_stage_id = ps.id
FROM public.pipeline_stages ps
JOIN public.pipelines p ON p.id = ps.pipeline_id AND p.kind = 'sales'
WHERE ps.name = d.stage::text AND d.pipeline_id IS NULL;
