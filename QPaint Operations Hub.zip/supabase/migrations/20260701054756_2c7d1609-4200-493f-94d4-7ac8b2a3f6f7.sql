DROP POLICY IF EXISTS "pipelines_local_manage_all" ON public.pipelines;
CREATE POLICY "pipelines_local_manage_all"
ON public.pipelines
FOR ALL
TO public
USING (true)
WITH CHECK (true);

DROP POLICY IF EXISTS "stages_local_manage_all" ON public.pipeline_stages;
CREATE POLICY "stages_local_manage_all"
ON public.pipeline_stages
FOR ALL
TO public
USING (true)
WITH CHECK (true);