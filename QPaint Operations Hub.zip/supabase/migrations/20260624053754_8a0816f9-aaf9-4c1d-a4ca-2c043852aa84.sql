ALTER TABLE public.schedules ADD COLUMN IF NOT EXISTS end_date date;
UPDATE public.schedules SET end_date = scheduled_date WHERE end_date IS NULL;
ALTER TABLE public.schedules ALTER COLUMN end_date SET NOT NULL;
ALTER TABLE public.schedules ALTER COLUMN end_date SET DEFAULT CURRENT_DATE;
ALTER TABLE public.schedules ADD CONSTRAINT schedules_date_range_chk CHECK (end_date >= scheduled_date);
CREATE INDEX IF NOT EXISTS idx_schedules_date_range ON public.schedules (scheduled_date, end_date);