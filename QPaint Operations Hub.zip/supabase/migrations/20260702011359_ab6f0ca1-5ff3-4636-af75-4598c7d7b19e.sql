
-- =========================
-- ROLES
-- =========================
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('owner','ops_manager','crew_leader','contractor','admin');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  staff_id uuid REFERENCES public.staff(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "Users can read their own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins manage roles" ON public.user_roles
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'owner'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'owner'));

-- =========================
-- SUBCONTRACTOR COMPANIES
-- =========================
CREATE TABLE IF NOT EXISTS public.subcontractor_companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  contact_name text,
  email text,
  phone text,
  address text,
  trade text,
  insurance_provider text,
  insurance_expiry date,
  license_number text,
  compliance_status text NOT NULL DEFAULT 'pending', -- pending | verified | expired
  notes text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subcontractor_companies TO authenticated;
GRANT ALL ON public.subcontractor_companies TO service_role;
ALTER TABLE public.subcontractor_companies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read companies" ON public.subcontractor_companies
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Ops/owner manage companies" ON public.subcontractor_companies
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'ops_manager') OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'ops_manager') OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_sub_companies_updated_at BEFORE UPDATE ON public.subcontractor_companies
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- =========================
-- CONTRACTORS (individuals)
-- =========================
CREATE TABLE IF NOT EXISTS public.contractors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES public.subcontractor_companies(id) ON DELETE SET NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  name text NOT NULL,
  email text,
  phone text,
  trade text,
  skills text[] DEFAULT '{}',
  hourly_cost numeric(10,2),
  hourly_bill_rate numeric(10,2),
  is_active boolean NOT NULL DEFAULT true,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contractors TO authenticated;
GRANT ALL ON public.contractors TO service_role;
ALTER TABLE public.contractors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated read contractors" ON public.contractors
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Ops/owner manage contractors" ON public.contractors
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'ops_manager') OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'ops_manager') OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_contractors_updated_at BEFORE UPDATE ON public.contractors
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- =========================
-- JOB CONTRACTOR ASSIGNMENTS
-- =========================
CREATE TABLE IF NOT EXISTS public.job_contractor_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  contractor_id uuid NOT NULL REFERENCES public.contractors(id) ON DELETE CASCADE,
  allocated_hours numeric(10,2) DEFAULT 0,
  hours_worked numeric(10,2) DEFAULT 0,
  hourly_rate numeric(10,2),
  status text NOT NULL DEFAULT 'scheduled', -- scheduled | in_progress | completed | cancelled
  start_date date,
  end_date date,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (job_id, contractor_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_contractor_assignments TO authenticated;
GRANT ALL ON public.job_contractor_assignments TO service_role;
ALTER TABLE public.job_contractor_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Read own or ops assignments" ON public.job_contractor_assignments
  FOR SELECT TO authenticated USING (
    public.has_role(auth.uid(), 'owner')
    OR public.has_role(auth.uid(), 'ops_manager')
    OR public.has_role(auth.uid(), 'admin')
    OR EXISTS (
      SELECT 1 FROM public.contractors c
      WHERE c.id = job_contractor_assignments.contractor_id AND c.user_id = auth.uid()
    )
  );
CREATE POLICY "Ops manage assignments" ON public.job_contractor_assignments
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'ops_manager') OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'ops_manager') OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_job_ctr_assign_updated_at BEFORE UPDATE ON public.job_contractor_assignments
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- =========================
-- CREW LEADER LINK (staff -> auth user)
-- =========================
ALTER TABLE public.staff ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.crews ADD COLUMN IF NOT EXISTS leader_staff_id uuid REFERENCES public.staff(id) ON DELETE SET NULL;

-- =========================
-- SEED sample contractor data
-- =========================
INSERT INTO public.subcontractor_companies (name, contact_name, email, phone, trade, insurance_provider, insurance_expiry, compliance_status)
VALUES
  ('Pinnacle Prep Services', 'David Chen', 'david@pinnacleprep.com', '555-0142', 'Surface Prep', 'HDI Insurance', '2027-03-15', 'verified'),
  ('Skyline Spray Co.', 'Maria Lopez', 'maria@skylinespray.com', '555-0198', 'Spray Painting', 'AAMI Business', '2026-11-01', 'verified'),
  ('EliteScaffold Partners', 'Tom Reilly', 'tom@elitescaffold.com', '555-0175', 'Scaffolding', 'QBE', '2026-09-30', 'pending')
ON CONFLICT DO NOTHING;

INSERT INTO public.contractors (company_id, name, email, phone, trade, skills, hourly_cost, hourly_bill_rate, is_active)
SELECT id, 'David Chen', 'david@pinnacleprep.com', '555-0142', 'Surface Prep', ARRAY['prep','sanding','patching']::text[], 55.00, 85.00, true
FROM public.subcontractor_companies WHERE name = 'Pinnacle Prep Services'
ON CONFLICT DO NOTHING;

INSERT INTO public.contractors (company_id, name, email, phone, trade, skills, hourly_cost, hourly_bill_rate, is_active)
SELECT id, 'Maria Lopez', 'maria@skylinespray.com', '555-0198', 'Spray Painting', ARRAY['spray','airless','commercial']::text[], 65.00, 95.00, true
FROM public.subcontractor_companies WHERE name = 'Skyline Spray Co.'
ON CONFLICT DO NOTHING;

INSERT INTO public.contractors (company_id, name, email, phone, trade, skills, hourly_cost, hourly_bill_rate, is_active)
SELECT id, 'Jarrah Nguyen', 'jarrah@skylinespray.com', '555-0203', 'Spray Painting', ARRAY['spray','residential']::text[], 60.00, 90.00, true
FROM public.subcontractor_companies WHERE name = 'Skyline Spray Co.'
ON CONFLICT DO NOTHING;

INSERT INTO public.contractors (company_id, name, email, phone, trade, skills, hourly_cost, hourly_bill_rate, is_active)
SELECT id, 'Tom Reilly', 'tom@elitescaffold.com', '555-0175', 'Scaffolding', ARRAY['scaffolding','safety']::text[], 70.00, 110.00, true
FROM public.subcontractor_companies WHERE name = 'EliteScaffold Partners'
ON CONFLICT DO NOTHING;
