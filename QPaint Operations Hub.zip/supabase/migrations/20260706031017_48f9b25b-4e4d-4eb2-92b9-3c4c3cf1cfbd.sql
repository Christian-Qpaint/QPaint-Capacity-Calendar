
-- =========================================================================
-- Lock down public-role policies. Drop insecure ones and replace with
-- authenticated + role-scoped policies.
-- =========================================================================

-- app_settings: owner only
DROP POLICY IF EXISTS "app_settings open" ON public.app_settings;
CREATE POLICY "app_settings_read_auth" ON public.app_settings
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "app_settings_owner_manage" ON public.app_settings
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role));

-- billing_reports: owner/ops_manager
DROP POLICY IF EXISTS "billing open" ON public.billing_reports;
CREATE POLICY "billing_reports_ops_manage" ON public.billing_reports
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- crews: owner/ops_manager/crew_leader
DROP POLICY IF EXISTS "crews open" ON public.crews;
CREATE POLICY "crews_ops_manage" ON public.crews
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role));

-- job_milestones
DROP POLICY IF EXISTS "milestones open" ON public.job_milestones;
CREATE POLICY "job_milestones_ops_manage" ON public.job_milestones
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role));

-- job_progress_updates
DROP POLICY IF EXISTS "progress open" ON public.job_progress_updates;
CREATE POLICY "job_progress_ops_manage" ON public.job_progress_updates
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role));

-- revenue_targets: owner/ops_manager
DROP POLICY IF EXISTS "revenue_targets open" ON public.revenue_targets;
CREATE POLICY "revenue_targets_ops_manage" ON public.revenue_targets
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- schedules
DROP POLICY IF EXISTS "schedules open" ON public.schedules;
CREATE POLICY "schedules_ops_manage" ON public.schedules
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role));

-- staff: owner/ops_manager
DROP POLICY IF EXISTS "staff open" ON public.staff;
CREATE POLICY "staff_ops_manage" ON public.staff
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- staff_availability: owner/ops_manager
DROP POLICY IF EXISTS "avail open" ON public.staff_availability;
CREATE POLICY "staff_availability_ops_manage" ON public.staff_availability
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- sync_state: owner only
DROP POLICY IF EXISTS "sync_state readable" ON public.sync_state;
CREATE POLICY "sync_state_owner_read" ON public.sync_state
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- pipelines
DROP POLICY IF EXISTS "pipelines_local_manage_all" ON public.pipelines;
DROP POLICY IF EXISTS "pipelines_read_all" ON public.pipelines;
DROP POLICY IF EXISTS "pipelines_write_auth" ON public.pipelines;
CREATE POLICY "pipelines_read_auth" ON public.pipelines
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "pipelines_ops_manage" ON public.pipelines
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- pipeline_stages
DROP POLICY IF EXISTS "stages_local_manage_all" ON public.pipeline_stages;
DROP POLICY IF EXISTS "stages_read_all" ON public.pipeline_stages;
DROP POLICY IF EXISTS "stages_write_auth" ON public.pipeline_stages;
CREATE POLICY "pipeline_stages_read_auth" ON public.pipeline_stages
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "pipeline_stages_ops_manage" ON public.pipeline_stages
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- contacts: authenticated read only
DROP POLICY IF EXISTS "contacts_read_all" ON public.contacts;
DROP POLICY IF EXISTS "contacts_write_auth" ON public.contacts;
CREATE POLICY "contacts_read_auth" ON public.contacts
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "contacts_ops_manage" ON public.contacts
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- deals: scope to CRM roles (owner/ops_manager)
DROP POLICY IF EXISTS "deals_authenticated_all" ON public.deals;
CREATE POLICY "deals_ops_manage" ON public.deals
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- deal_stage_history
DROP POLICY IF EXISTS "deal_stage_history_read" ON public.deal_stage_history;
DROP POLICY IF EXISTS "deal_stage_history_insert" ON public.deal_stage_history;
CREATE POLICY "deal_stage_history_read_ops" ON public.deal_stage_history
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));
CREATE POLICY "deal_stage_history_insert_ops" ON public.deal_stage_history
  FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role));

-- job_notes
DROP POLICY IF EXISTS "Authenticated can read job notes" ON public.job_notes;
DROP POLICY IF EXISTS "Authenticated can write job notes" ON public.job_notes;
CREATE POLICY "job_notes_ops_manage" ON public.job_notes
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role));

-- job_blockers
DROP POLICY IF EXISTS "Authenticated can read blockers" ON public.job_blockers;
DROP POLICY IF EXISTS "Authenticated can write blockers" ON public.job_blockers;
CREATE POLICY "job_blockers_ops_manage" ON public.job_blockers
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'crew_leader'::app_role));

-- contractors: restrict read to ops/owner (removes broad auth read)
DROP POLICY IF EXISTS "Authenticated read contractors" ON public.contractors;
CREATE POLICY "contractors_ops_read" ON public.contractors
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role));

-- subcontractor_companies: restrict read to ops/owner
DROP POLICY IF EXISTS "Authenticated read companies" ON public.subcontractor_companies;
CREATE POLICY "subcontractor_companies_ops_read" ON public.subcontractor_companies
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'ops_manager'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role));

-- =========================================================================
-- SECURITY DEFINER function EXECUTE privileges.
-- Trigger-only functions must not be callable from PostgREST at all.
-- has_role is invoked from RLS policies by signed-in users, so authenticated
-- must retain EXECUTE.
-- =========================================================================
REVOKE ALL ON FUNCTION public.recompute_contact_stats(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_recompute_contact_stats() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.ensure_contact_for_record() FROM PUBLIC, anon, authenticated;

REVOKE ALL ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated;
