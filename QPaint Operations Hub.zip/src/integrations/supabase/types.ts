export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          capacity_full_pct: number
          capacity_near_pct: number
          created_at: string
          financial_year_start_month: number
          id: string
          progress_billing_enabled: boolean
          revenue_allocation_method: Database["public"]["Enums"]["revenue_allocation_method"]
          revenue_recognition_method: Database["public"]["Enums"]["revenue_recognition_method"]
          singleton: boolean
          traffic_light_amber_pct: number
          traffic_light_green_pct: number
          updated_at: string
        }
        Insert: {
          capacity_full_pct?: number
          capacity_near_pct?: number
          created_at?: string
          financial_year_start_month?: number
          id?: string
          progress_billing_enabled?: boolean
          revenue_allocation_method?: Database["public"]["Enums"]["revenue_allocation_method"]
          revenue_recognition_method?: Database["public"]["Enums"]["revenue_recognition_method"]
          singleton?: boolean
          traffic_light_amber_pct?: number
          traffic_light_green_pct?: number
          updated_at?: string
        }
        Update: {
          capacity_full_pct?: number
          capacity_near_pct?: number
          created_at?: string
          financial_year_start_month?: number
          id?: string
          progress_billing_enabled?: boolean
          revenue_allocation_method?: Database["public"]["Enums"]["revenue_allocation_method"]
          revenue_recognition_method?: Database["public"]["Enums"]["revenue_recognition_method"]
          singleton?: boolean
          traffic_light_amber_pct?: number
          traffic_light_green_pct?: number
          updated_at?: string
        }
        Relationships: []
      }
      billing_reports: {
        Row: {
          admin_notes: string | null
          billing_status: Database["public"]["Enums"]["billing_status"]
          completion_percentage: number
          created_at: string
          id: string
          invoice_sent_at: string | null
          job_id: string
          ready_for_invoice: boolean
          updated_at: string
        }
        Insert: {
          admin_notes?: string | null
          billing_status?: Database["public"]["Enums"]["billing_status"]
          completion_percentage?: number
          created_at?: string
          id?: string
          invoice_sent_at?: string | null
          job_id: string
          ready_for_invoice?: boolean
          updated_at?: string
        }
        Update: {
          admin_notes?: string | null
          billing_status?: Database["public"]["Enums"]["billing_status"]
          completion_percentage?: number
          created_at?: string
          id?: string
          invoice_sent_at?: string | null
          job_id?: string
          ready_for_invoice?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "billing_reports_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      contacts: {
        Row: {
          address: string | null
          company: string | null
          created_at: string
          email: string | null
          id: string
          lifetime_value: number
          name: string
          notes: string | null
          phone: string | null
          pipedrive_id: number | null
          ranking: string | null
          source: string | null
          synced_at: string | null
          total_deals: number
          total_jobs: number
          updated_at: string
        }
        Insert: {
          address?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          id?: string
          lifetime_value?: number
          name: string
          notes?: string | null
          phone?: string | null
          pipedrive_id?: number | null
          ranking?: string | null
          source?: string | null
          synced_at?: string | null
          total_deals?: number
          total_jobs?: number
          updated_at?: string
        }
        Update: {
          address?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          id?: string
          lifetime_value?: number
          name?: string
          notes?: string | null
          phone?: string | null
          pipedrive_id?: number | null
          ranking?: string | null
          source?: string | null
          synced_at?: string | null
          total_deals?: number
          total_jobs?: number
          updated_at?: string
        }
        Relationships: []
      }
      contractors: {
        Row: {
          company_id: string | null
          created_at: string
          email: string | null
          hourly_bill_rate: number | null
          hourly_cost: number | null
          id: string
          is_active: boolean
          name: string
          notes: string | null
          phone: string | null
          skills: string[] | null
          trade: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          company_id?: string | null
          created_at?: string
          email?: string | null
          hourly_bill_rate?: number | null
          hourly_cost?: number | null
          id?: string
          is_active?: boolean
          name: string
          notes?: string | null
          phone?: string | null
          skills?: string[] | null
          trade?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          company_id?: string | null
          created_at?: string
          email?: string | null
          hourly_bill_rate?: number | null
          hourly_cost?: number | null
          id?: string
          is_active?: boolean
          name?: string
          notes?: string | null
          phone?: string | null
          skills?: string[] | null
          trade?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "contractors_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "subcontractor_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      crews: {
        Row: {
          business_unit: string | null
          color: string | null
          created_at: string
          crew_type: string | null
          division: string | null
          id: string
          leader_id: string | null
          leader_staff_id: string | null
          monthly_revenue_target: number | null
          name: string
          notes: string | null
          region: string | null
          status: Database["public"]["Enums"]["crew_status"]
          updated_at: string
          weekly_capacity_hours: number
          weekly_revenue_target: number | null
        }
        Insert: {
          business_unit?: string | null
          color?: string | null
          created_at?: string
          crew_type?: string | null
          division?: string | null
          id?: string
          leader_id?: string | null
          leader_staff_id?: string | null
          monthly_revenue_target?: number | null
          name: string
          notes?: string | null
          region?: string | null
          status?: Database["public"]["Enums"]["crew_status"]
          updated_at?: string
          weekly_capacity_hours?: number
          weekly_revenue_target?: number | null
        }
        Update: {
          business_unit?: string | null
          color?: string | null
          created_at?: string
          crew_type?: string | null
          division?: string | null
          id?: string
          leader_id?: string | null
          leader_staff_id?: string | null
          monthly_revenue_target?: number | null
          name?: string
          notes?: string | null
          region?: string | null
          status?: Database["public"]["Enums"]["crew_status"]
          updated_at?: string
          weekly_capacity_hours?: number
          weekly_revenue_target?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "crews_leader_fk"
            columns: ["leader_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crews_leader_staff_id_fkey"
            columns: ["leader_staff_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
      deal_stage_history: {
        Row: {
          changed_at: string
          changed_by: string | null
          deal_id: string
          from_stage: Database["public"]["Enums"]["deal_stage"] | null
          id: string
          to_stage: Database["public"]["Enums"]["deal_stage"]
        }
        Insert: {
          changed_at?: string
          changed_by?: string | null
          deal_id: string
          from_stage?: Database["public"]["Enums"]["deal_stage"] | null
          id?: string
          to_stage: Database["public"]["Enums"]["deal_stage"]
        }
        Update: {
          changed_at?: string
          changed_by?: string | null
          deal_id?: string
          from_stage?: Database["public"]["Enums"]["deal_stage"] | null
          id?: string
          to_stage?: Database["public"]["Enums"]["deal_stage"]
        }
        Relationships: [
          {
            foreignKeyName: "deal_stage_history_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      deals: {
        Row: {
          actual_hours: number | null
          appointment_date: string | null
          appointment_time: string | null
          assigned_crew_id: string | null
          billing_method: string | null
          billing_status: string
          business_unit: string | null
          category: string | null
          client_name: string
          client_ranking: string | null
          completion_percentage: number
          contact_id: string | null
          contact_person: string | null
          contract_value: number | null
          converted_job_id: string | null
          created_at: string
          description: string | null
          division: string | null
          email: string | null
          estimated_duration_days: number | null
          estimated_labour_hours: number | null
          estimated_productivity: number | null
          estimator: string | null
          expected_value: number | null
          extent_of_work: string | null
          forecast_revenue: number | null
          google_drive_link: string | null
          google_maps_link: string | null
          hours_worked: number
          id: string
          job_notes: string | null
          job_type: string | null
          last_activity_at: string | null
          next_activity_at: string | null
          owner: string | null
          phone: string | null
          pipedrive_id: number | null
          pipedrive_org_name: string | null
          pipedrive_owner_name: string | null
          pipedrive_status: string | null
          pipeline_id: string | null
          pipeline_stage_id: string | null
          priority: Database["public"]["Enums"]["deal_priority"]
          property_address: string | null
          quote_id: string
          quote_notes: string | null
          quote_sent_date: string | null
          quote_status: string | null
          quote_type: string | null
          referral_source: string | null
          region: string | null
          retention_pct: number | null
          revenue_category: string | null
          site_visit_notes: string | null
          site_visit_status: string | null
          stage: Database["public"]["Enums"]["deal_stage"] | null
          start_date: string | null
          supervisor_id: string | null
          synced_at: string | null
          target_finish_date: string | null
          target_hours: number | null
          updated_at: string
        }
        Insert: {
          actual_hours?: number | null
          appointment_date?: string | null
          appointment_time?: string | null
          assigned_crew_id?: string | null
          billing_method?: string | null
          billing_status?: string
          business_unit?: string | null
          category?: string | null
          client_name: string
          client_ranking?: string | null
          completion_percentage?: number
          contact_id?: string | null
          contact_person?: string | null
          contract_value?: number | null
          converted_job_id?: string | null
          created_at?: string
          description?: string | null
          division?: string | null
          email?: string | null
          estimated_duration_days?: number | null
          estimated_labour_hours?: number | null
          estimated_productivity?: number | null
          estimator?: string | null
          expected_value?: number | null
          extent_of_work?: string | null
          forecast_revenue?: number | null
          google_drive_link?: string | null
          google_maps_link?: string | null
          hours_worked?: number
          id?: string
          job_notes?: string | null
          job_type?: string | null
          last_activity_at?: string | null
          next_activity_at?: string | null
          owner?: string | null
          phone?: string | null
          pipedrive_id?: number | null
          pipedrive_org_name?: string | null
          pipedrive_owner_name?: string | null
          pipedrive_status?: string | null
          pipeline_id?: string | null
          pipeline_stage_id?: string | null
          priority?: Database["public"]["Enums"]["deal_priority"]
          property_address?: string | null
          quote_id: string
          quote_notes?: string | null
          quote_sent_date?: string | null
          quote_status?: string | null
          quote_type?: string | null
          referral_source?: string | null
          region?: string | null
          retention_pct?: number | null
          revenue_category?: string | null
          site_visit_notes?: string | null
          site_visit_status?: string | null
          stage?: Database["public"]["Enums"]["deal_stage"] | null
          start_date?: string | null
          supervisor_id?: string | null
          synced_at?: string | null
          target_finish_date?: string | null
          target_hours?: number | null
          updated_at?: string
        }
        Update: {
          actual_hours?: number | null
          appointment_date?: string | null
          appointment_time?: string | null
          assigned_crew_id?: string | null
          billing_method?: string | null
          billing_status?: string
          business_unit?: string | null
          category?: string | null
          client_name?: string
          client_ranking?: string | null
          completion_percentage?: number
          contact_id?: string | null
          contact_person?: string | null
          contract_value?: number | null
          converted_job_id?: string | null
          created_at?: string
          description?: string | null
          division?: string | null
          email?: string | null
          estimated_duration_days?: number | null
          estimated_labour_hours?: number | null
          estimated_productivity?: number | null
          estimator?: string | null
          expected_value?: number | null
          extent_of_work?: string | null
          forecast_revenue?: number | null
          google_drive_link?: string | null
          google_maps_link?: string | null
          hours_worked?: number
          id?: string
          job_notes?: string | null
          job_type?: string | null
          last_activity_at?: string | null
          next_activity_at?: string | null
          owner?: string | null
          phone?: string | null
          pipedrive_id?: number | null
          pipedrive_org_name?: string | null
          pipedrive_owner_name?: string | null
          pipedrive_status?: string | null
          pipeline_id?: string | null
          pipeline_stage_id?: string | null
          priority?: Database["public"]["Enums"]["deal_priority"]
          property_address?: string | null
          quote_id?: string
          quote_notes?: string | null
          quote_sent_date?: string | null
          quote_status?: string | null
          quote_type?: string | null
          referral_source?: string | null
          region?: string | null
          retention_pct?: number | null
          revenue_category?: string | null
          site_visit_notes?: string | null
          site_visit_status?: string | null
          stage?: Database["public"]["Enums"]["deal_stage"] | null
          start_date?: string | null
          supervisor_id?: string | null
          synced_at?: string | null
          target_finish_date?: string | null
          target_hours?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "deals_assigned_crew_id_fkey"
            columns: ["assigned_crew_id"]
            isOneToOne: false
            referencedRelation: "crews"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_pipeline_id_fkey"
            columns: ["pipeline_id"]
            isOneToOne: false
            referencedRelation: "pipelines"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_pipeline_stage_id_fkey"
            columns: ["pipeline_stage_id"]
            isOneToOne: false
            referencedRelation: "pipeline_stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_supervisor_id_fkey"
            columns: ["supervisor_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
      job_blockers: {
        Row: {
          body: string | null
          created_at: string
          deal_id: string
          id: string
          kind: string
          label: string
          resolved_at: string | null
          tone: string
          updated_at: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          deal_id: string
          id?: string
          kind?: string
          label: string
          resolved_at?: string | null
          tone?: string
          updated_at?: string
        }
        Update: {
          body?: string | null
          created_at?: string
          deal_id?: string
          id?: string
          kind?: string
          label?: string
          resolved_at?: string | null
          tone?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_blockers_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      job_contractor_assignments: {
        Row: {
          allocated_hours: number | null
          contractor_id: string
          created_at: string
          end_date: string | null
          hourly_rate: number | null
          hours_worked: number | null
          id: string
          job_id: string
          notes: string | null
          start_date: string | null
          status: string
          updated_at: string
        }
        Insert: {
          allocated_hours?: number | null
          contractor_id: string
          created_at?: string
          end_date?: string | null
          hourly_rate?: number | null
          hours_worked?: number | null
          id?: string
          job_id: string
          notes?: string | null
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          allocated_hours?: number | null
          contractor_id?: string
          created_at?: string
          end_date?: string | null
          hourly_rate?: number | null
          hours_worked?: number | null
          id?: string
          job_id?: string
          notes?: string | null
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_contractor_assignments_contractor_id_fkey"
            columns: ["contractor_id"]
            isOneToOne: false
            referencedRelation: "contractors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_contractor_assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      job_milestones: {
        Row: {
          completed_at: string | null
          id: string
          is_completed: boolean
          job_id: string
          milestone_name: string
          notes: string | null
        }
        Insert: {
          completed_at?: string | null
          id?: string
          is_completed?: boolean
          job_id: string
          milestone_name: string
          notes?: string | null
        }
        Update: {
          completed_at?: string | null
          id?: string
          is_completed?: boolean
          job_id?: string
          milestone_name?: string
          notes?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_milestones_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      job_notes: {
        Row: {
          author_id: string | null
          author_name: string | null
          body: string
          created_at: string
          deal_id: string
          id: string
          updated_at: string
        }
        Insert: {
          author_id?: string | null
          author_name?: string | null
          body: string
          created_at?: string
          deal_id: string
          id?: string
          updated_at?: string
        }
        Update: {
          author_id?: string | null
          author_name?: string | null
          body?: string
          created_at?: string
          deal_id?: string
          id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_notes_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      job_progress_updates: {
        Row: {
          blocker_type: Database["public"]["Enums"]["blocker_type"]
          created_at: string
          hours_worked: number
          id: string
          job_id: string
          progress_percentage: number
          update_note: string | null
          updated_by: string | null
        }
        Insert: {
          blocker_type?: Database["public"]["Enums"]["blocker_type"]
          created_at?: string
          hours_worked?: number
          id?: string
          job_id: string
          progress_percentage: number
          update_note?: string | null
          updated_by?: string | null
        }
        Update: {
          blocker_type?: Database["public"]["Enums"]["blocker_type"]
          created_at?: string
          hours_worked?: number
          id?: string
          job_id?: string
          progress_percentage?: number
          update_note?: string | null
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_progress_updates_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_progress_updates_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_stages: {
        Row: {
          color: string | null
          created_at: string
          id: string
          is_lost: boolean
          is_won: boolean
          name: string
          pipedrive_id: number | null
          pipeline_id: string
          position: number
          synced_at: string | null
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          id?: string
          is_lost?: boolean
          is_won?: boolean
          name: string
          pipedrive_id?: number | null
          pipeline_id: string
          position?: number
          synced_at?: string | null
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          id?: string
          is_lost?: boolean
          is_won?: boolean
          name?: string
          pipedrive_id?: number | null
          pipeline_id?: string
          position?: number
          synced_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "pipeline_stages_pipeline_id_fkey"
            columns: ["pipeline_id"]
            isOneToOne: false
            referencedRelation: "pipelines"
            referencedColumns: ["id"]
          },
        ]
      }
      pipelines: {
        Row: {
          auto_schedule: boolean
          color: string | null
          created_at: string
          description: string | null
          id: string
          kind: string
          name: string
          pipedrive_id: number | null
          position: number
          synced_at: string | null
          updated_at: string
        }
        Insert: {
          auto_schedule?: boolean
          color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          kind?: string
          name: string
          pipedrive_id?: number | null
          position?: number
          synced_at?: string | null
          updated_at?: string
        }
        Update: {
          auto_schedule?: boolean
          color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          kind?: string
          name?: string
          pipedrive_id?: number | null
          position?: number
          synced_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      revenue_targets: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          period: Database["public"]["Enums"]["target_period"]
          period_start: string
          scope: Database["public"]["Enums"]["target_scope"]
          scope_ref: string | null
          target_amount: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          period?: Database["public"]["Enums"]["target_period"]
          period_start: string
          scope?: Database["public"]["Enums"]["target_scope"]
          scope_ref?: string | null
          target_amount?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          period?: Database["public"]["Enums"]["target_period"]
          period_start?: string
          scope?: Database["public"]["Enums"]["target_scope"]
          scope_ref?: string | null
          target_amount?: number
          updated_at?: string
        }
        Relationships: []
      }
      schedules: {
        Row: {
          actual_hours: number | null
          color: string | null
          created_at: string
          crew_id: string | null
          end_date: string
          end_time: string | null
          id: string
          job_id: string
          notes: string | null
          planned_hours: number
          scheduled_date: string
          staff_ids: string[]
          start_time: string | null
          status: Database["public"]["Enums"]["schedule_status"]
          updated_at: string
        }
        Insert: {
          actual_hours?: number | null
          color?: string | null
          created_at?: string
          crew_id?: string | null
          end_date?: string
          end_time?: string | null
          id?: string
          job_id: string
          notes?: string | null
          planned_hours?: number
          scheduled_date: string
          staff_ids?: string[]
          start_time?: string | null
          status?: Database["public"]["Enums"]["schedule_status"]
          updated_at?: string
        }
        Update: {
          actual_hours?: number | null
          color?: string | null
          created_at?: string
          crew_id?: string | null
          end_date?: string
          end_time?: string | null
          id?: string
          job_id?: string
          notes?: string | null
          planned_hours?: number
          scheduled_date?: string
          staff_ids?: string[]
          start_time?: string | null
          status?: Database["public"]["Enums"]["schedule_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "schedules_crew_id_fkey"
            columns: ["crew_id"]
            isOneToOne: false
            referencedRelation: "crews"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedules_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      staff: {
        Row: {
          contact_number: string | null
          created_at: string
          crew_id: string | null
          email: string | null
          full_name: string
          id: string
          normal_hours_per_week: number
          role: string | null
          skills: string[]
          status: Database["public"]["Enums"]["staff_status"]
          updated_at: string
          user_id: string | null
        }
        Insert: {
          contact_number?: string | null
          created_at?: string
          crew_id?: string | null
          email?: string | null
          full_name: string
          id?: string
          normal_hours_per_week?: number
          role?: string | null
          skills?: string[]
          status?: Database["public"]["Enums"]["staff_status"]
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          contact_number?: string | null
          created_at?: string
          crew_id?: string | null
          email?: string | null
          full_name?: string
          id?: string
          normal_hours_per_week?: number
          role?: string | null
          skills?: string[]
          status?: Database["public"]["Enums"]["staff_status"]
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "staff_crew_id_fkey"
            columns: ["crew_id"]
            isOneToOne: false
            referencedRelation: "crews"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_availability: {
        Row: {
          availability_status: Database["public"]["Enums"]["availability_status"]
          available_hours: number
          created_at: string
          date: string
          id: string
          reason: string | null
          staff_id: string
          updated_at: string
        }
        Insert: {
          availability_status?: Database["public"]["Enums"]["availability_status"]
          available_hours?: number
          created_at?: string
          date: string
          id?: string
          reason?: string | null
          staff_id: string
          updated_at?: string
        }
        Update: {
          availability_status?: Database["public"]["Enums"]["availability_status"]
          available_hours?: number
          created_at?: string
          date?: string
          id?: string
          reason?: string | null
          staff_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_availability_staff_id_fkey"
            columns: ["staff_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
      subcontractor_companies: {
        Row: {
          address: string | null
          compliance_status: string
          contact_name: string | null
          created_at: string
          email: string | null
          id: string
          insurance_expiry: string | null
          insurance_provider: string | null
          is_active: boolean
          license_number: string | null
          name: string
          notes: string | null
          phone: string | null
          trade: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          compliance_status?: string
          contact_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          insurance_expiry?: string | null
          insurance_provider?: string | null
          is_active?: boolean
          license_number?: string | null
          name: string
          notes?: string | null
          phone?: string | null
          trade?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          compliance_status?: string
          contact_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          insurance_expiry?: string | null
          insurance_provider?: string | null
          is_active?: boolean
          license_number?: string | null
          name?: string
          notes?: string | null
          phone?: string | null
          trade?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      sync_state: {
        Row: {
          last_error: string | null
          last_run_at: string | null
          last_status: string | null
          source: string
          stats: Json | null
          updated_at: string
        }
        Insert: {
          last_error?: string | null
          last_run_at?: string | null
          last_status?: string | null
          source: string
          stats?: Json | null
          updated_at?: string
        }
        Update: {
          last_error?: string | null
          last_run_at?: string | null
          last_status?: string | null
          source?: string
          stats?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          staff_id: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          staff_id?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          staff_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_staff_id_fkey"
            columns: ["staff_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      recompute_contact_stats: {
        Args: { p_contact_id: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "owner" | "ops_manager" | "crew_leader" | "contractor" | "admin"
      availability_status:
        | "Available"
        | "Assigned"
        | "Leave"
        | "Sick"
        | "Unavailable"
        | "Training"
      billing_method: "fixed_price" | "hourly" | "variation" | "progress"
      billing_status: "Not Ready" | "Ready for Invoice" | "Invoiced" | "Paid"
      blocker_type:
        | "None"
        | "Weather"
        | "Client Delay"
        | "Material Delay"
        | "Staff Shortage"
        | "Access"
        | "Other"
      crew_status:
        | "Available"
        | "Partially Booked"
        | "Fully Booked"
        | "Overbooked"
        | "On Leave"
      deal_priority: "Low" | "Normal" | "High" | "Urgent"
      deal_stage:
        | "Lead Received"
        | "Contact Qualified"
        | "Site Visit Booked"
        | "Site Visit Completed"
        | "Quote Review"
        | "Quote Sent"
      job_status:
        | "Not Started"
        | "Scheduled"
        | "In Progress"
        | "Delayed"
        | "On Hold"
        | "Completed"
      revenue_allocation_method:
        | "start_month"
        | "prorated_dates"
        | "prorated_progress"
      revenue_recognition_method:
        | "on_completion"
        | "progress_percent"
        | "milestone"
      schedule_status: "Planned" | "In Progress" | "Completed" | "Cancelled"
      staff_status: "Active" | "On Leave" | "Sick" | "Inactive"
      target_period: "month" | "week" | "day"
      target_scope: "company" | "crew" | "division" | "region" | "business_unit"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "ops_manager", "crew_leader", "contractor", "admin"],
      availability_status: [
        "Available",
        "Assigned",
        "Leave",
        "Sick",
        "Unavailable",
        "Training",
      ],
      billing_method: ["fixed_price", "hourly", "variation", "progress"],
      billing_status: ["Not Ready", "Ready for Invoice", "Invoiced", "Paid"],
      blocker_type: [
        "None",
        "Weather",
        "Client Delay",
        "Material Delay",
        "Staff Shortage",
        "Access",
        "Other",
      ],
      crew_status: [
        "Available",
        "Partially Booked",
        "Fully Booked",
        "Overbooked",
        "On Leave",
      ],
      deal_priority: ["Low", "Normal", "High", "Urgent"],
      deal_stage: [
        "Lead Received",
        "Contact Qualified",
        "Site Visit Booked",
        "Site Visit Completed",
        "Quote Review",
        "Quote Sent",
      ],
      job_status: [
        "Not Started",
        "Scheduled",
        "In Progress",
        "Delayed",
        "On Hold",
        "Completed",
      ],
      revenue_allocation_method: [
        "start_month",
        "prorated_dates",
        "prorated_progress",
      ],
      revenue_recognition_method: [
        "on_completion",
        "progress_percent",
        "milestone",
      ],
      schedule_status: ["Planned", "In Progress", "Completed", "Cancelled"],
      staff_status: ["Active", "On Leave", "Sick", "Inactive"],
      target_period: ["month", "week", "day"],
      target_scope: ["company", "crew", "division", "region", "business_unit"],
    },
  },
} as const
