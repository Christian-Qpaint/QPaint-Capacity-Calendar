import { createServerFn } from "@tanstack/react-start";

/**
 * One-way sync: Pipedrive → local DB.
 * Local edits stay local (we do NOT push back).
 *
 * Split into small phases so the client can drive progress and refresh the
 * UI incrementally instead of waiting for one long request.
 */

const BASE = "https://api.pipedrive.com/v1";
const PAGE_LIMIT = 500;

type PDPipeline = { id: number; name: string; order_nr: number; active: boolean };
type PDStage = { id: number; name: string; order_nr: number; pipeline_id: number };
type PDPerson = {
  id: number;
  name: string | null;
  email?: Array<{ value: string; primary?: boolean }> | null;
  phone?: Array<{ value: string; primary?: boolean }> | null;
  org_id?: { name?: string; address?: string } | null;
};
type PDDeal = {
  id: number;
  title: string;
  value: number | null;
  currency: string | null;
  status: string;
  stage_id: number;
  pipeline_id: number;
  person_id: { value: number; name?: string } | number | null;
  org_id: { value: number; name?: string; address?: string } | null;
  user_id: { name?: string } | number | null;
  add_time: string | null;
  update_time: string | null;
  expected_close_date: string | null;
  won_time: string | null;
  lost_time: string | null;
};

type PDPage<T> = {
  success: boolean;
  data: T[] | null;
  additional_data?: { pagination?: { more_items_in_collection?: boolean; next_start?: number } };
};

async function pdFetchRaw<T>(token: string, path: string, params: Record<string, string | number> = {}): Promise<PDPage<T>> {
  const url = new URL(BASE + path);
  url.searchParams.set("api_token", token);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, String(v));
  const r = await fetch(url.toString());
  if (!r.ok) throw new Error(`Pipedrive ${path} ${r.status}: ${await r.text().catch(() => "")}`);
  const j = (await r.json()) as PDPage<T>;
  if (!j.success) throw new Error(`Pipedrive ${path} not successful`);
  return j;
}

function token() {
  const t = process.env.PIPEDRIVE_API_TOKEN;
  if (!t) throw new Error("PIPEDRIVE_API_TOKEN is not configured");
  return t;
}

// -----------------------------------------------------------------------------
// Phase 1 — pipelines + stages (small, always fast). Returns totals so the
// client can build a progress plan.
// -----------------------------------------------------------------------------
export const syncPdMeta = createServerFn({ method: "POST" }).handler(async () => {
  const t = token();
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const pipelinesRaw = (await pdFetchRaw<PDPipeline>(t, "/pipelines")).data ?? [];
  if (pipelinesRaw.length) {
    const rows = pipelinesRaw.map((p) => ({
      pipedrive_id: p.id,
      name: p.name,
      position: p.order_nr ?? 0,
      kind: "custom" as const,
      auto_schedule: false,
      synced_at: new Date().toISOString(),
    }));
    const { error } = await supabaseAdmin.from("pipelines").upsert(rows, { onConflict: "pipedrive_id" });
    if (error) throw error;
  }

  const { data: pipeRows } = await supabaseAdmin.from("pipelines").select("id,pipedrive_id");
  const pipelineIdByPd = new Map<number, string>();
  for (const row of pipeRows ?? []) if (row.pipedrive_id != null) pipelineIdByPd.set(Number(row.pipedrive_id), row.id as string);

  const stagesRaw = (await pdFetchRaw<PDStage>(t, "/stages")).data ?? [];
  const stageRows = stagesRaw
    .filter((s) => pipelineIdByPd.has(s.pipeline_id))
    .map((s) => ({
      pipedrive_id: s.id,
      pipeline_id: pipelineIdByPd.get(s.pipeline_id)!,
      name: s.name,
      position: s.order_nr ?? 0,
      synced_at: new Date().toISOString(),
    }));
  if (stageRows.length) {
    const { error } = await supabaseAdmin.from("pipeline_stages").upsert(stageRows, { onConflict: "pipedrive_id" });
    if (error) throw error;
  }

  // Cheap totals via a first page (limit=1) so the UI can render a bar.
  const [contactHead, dealHead] = await Promise.all([
    pdFetchRaw<PDPerson>(t, "/persons", { start: 0, limit: 1 }),
    pdFetchRaw<PDDeal>(t, "/deals", { start: 0, limit: 1, status: "all_not_deleted" }),
  ]);
  const contactMore = !!contactHead.additional_data?.pagination?.more_items_in_collection;
  const dealMore = !!dealHead.additional_data?.pagination?.more_items_in_collection;

  return {
    pipelines: pipelinesRaw.length,
    stages: stageRows.length,
    // Pipedrive doesn't return absolute totals; give the client a floor so it
    // can render a moving bar. It will keep going until done=true.
    contactsHint: contactMore ? PAGE_LIMIT : (contactHead.data?.length ?? 0),
    dealsHint: dealMore ? PAGE_LIMIT : (dealHead.data?.length ?? 0),
  };
});

// -----------------------------------------------------------------------------
// Phase 2 — contacts, one page at a time.
// -----------------------------------------------------------------------------
export const syncPdContactsChunk = createServerFn({ method: "POST" })
  .inputValidator((data: { start?: number } | undefined) => ({ start: Math.max(0, Number(data?.start ?? 0)) }))
  .handler(async ({ data }) => {
    const t = token();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const page = await pdFetchRaw<PDPerson>(t, "/persons", { start: data.start, limit: PAGE_LIMIT });
    const persons = page.data ?? [];

    for (const p of persons) {
      const email = p.email?.find((e) => e.primary)?.value ?? p.email?.[0]?.value ?? null;
      const phone = p.phone?.find((e) => e.primary)?.value ?? p.phone?.[0]?.value ?? null;
      const payload = {
        pipedrive_id: p.id,
        name: p.name ?? "Unnamed",
        email,
        phone,
        address: p.org_id?.address ?? null,
        source: "pipedrive",
        synced_at: new Date().toISOString(),
      };

      let existingId: string | null = null;
      const { data: byPd } = await supabaseAdmin.from("contacts").select("id").eq("pipedrive_id", p.id).maybeSingle();
      if (byPd?.id) existingId = byPd.id as string;
      if (!existingId && email) {
        const { data: byEmail } = await supabaseAdmin.from("contacts").select("id").ilike("email", email).limit(1);
        if (byEmail && byEmail[0]?.id) existingId = byEmail[0].id as string;
      }
      if (!existingId && phone && p.name) {
        const { data: byPhone } = await supabaseAdmin.from("contacts").select("id").eq("phone", phone).ilike("name", p.name).limit(1);
        if (byPhone && byPhone[0]?.id) existingId = byPhone[0].id as string;
      }

      if (existingId) {
        const { error } = await supabaseAdmin.from("contacts").update(payload).eq("id", existingId);
        if (error) throw error;
      } else {
        const { error } = await supabaseAdmin.from("contacts").insert(payload);
        if (error) {
          // Case-insensitive / race unique conflict on email — fall back to update by email.
          if (email && (error.code === "23505" || /duplicate key/i.test(error.message))) {
            const { error: updErr } = await supabaseAdmin.from("contacts").update(payload).ilike("email", email);
            if (updErr) throw updErr;
          } else {
            throw error;
          }
        }
      }
    }

    const pg = page.additional_data?.pagination;
    return {
      processed: persons.length,
      nextStart: pg?.more_items_in_collection ? (pg.next_start ?? data.start + PAGE_LIMIT) : null,
      done: !pg?.more_items_in_collection,
    };
  });

// -----------------------------------------------------------------------------
// Phase 3 — deals, one page at a time, batch upsert.
// -----------------------------------------------------------------------------
const VALID_STAGE_ENUM = new Set([
  "Lead Received",
  "Contact Qualified",
  "Site Visit Booked",
  "Site Visit Completed",
  "Quote Review",
  "Quote Sent",
]);

export const syncPdDealsChunk = createServerFn({ method: "POST" })
  .inputValidator((data: { start?: number } | undefined) => ({ start: Math.max(0, Number(data?.start ?? 0)) }))
  .handler(async ({ data }) => {
    const t = token();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [{ data: stageRows }, { data: contactRows }] = await Promise.all([
      supabaseAdmin.from("pipeline_stages").select("id,pipedrive_id,pipeline_id,name"),
      supabaseAdmin.from("contacts").select("id,pipedrive_id"),
    ]);
    const stageIdByPd = new Map<number, { id: string; pipeline_id: string; name: string }>();
    for (const s of stageRows ?? []) {
      if (s.pipedrive_id != null) stageIdByPd.set(Number(s.pipedrive_id), { id: s.id as string, pipeline_id: s.pipeline_id as string, name: s.name as string });
    }
    const contactIdByPd = new Map<number, string>();
    for (const c of contactRows ?? []) if (c.pipedrive_id != null) contactIdByPd.set(Number(c.pipedrive_id), c.id as string);

    const page = await pdFetchRaw<PDDeal>(t, "/deals", { start: data.start, limit: PAGE_LIMIT, status: "all_not_deleted" });
    const deals = page.data ?? [];

    const rows: Record<string, unknown>[] = [];
    let skipped = 0;
    for (const d of deals) {
      const stage = stageIdByPd.get(d.stage_id);
      if (!stage) { skipped++; continue; }
      const personId = typeof d.person_id === "object" && d.person_id ? d.person_id.value : (typeof d.person_id === "number" ? d.person_id : null);
      const contactLocalId = personId ? contactIdByPd.get(personId) ?? null : null;
      const personName = (typeof d.person_id === "object" && d.person_id?.name) || null;
      const orgName = d.org_id?.name ?? null;
      const ownerName = typeof d.user_id === "object" && d.user_id ? d.user_id.name ?? null : null;

      const row: Record<string, unknown> = {
        pipedrive_id: d.id,
        quote_id: `PD-${d.id}`,
        client_name: orgName ?? personName ?? d.title ?? "Untitled",
        contact_person: personName,
        property_address: d.org_id?.address ?? null,
        description: d.title,
        expected_value: d.value,
        pipeline_id: stage.pipeline_id,
        pipeline_stage_id: stage.id,
        pipedrive_status: d.status,
        pipedrive_org_name: orgName,
        pipedrive_owner_name: ownerName,
        contact_id: contactLocalId,
        synced_at: new Date().toISOString(),
      };
      if (VALID_STAGE_ENUM.has(stage.name)) row.stage = stage.name;
      rows.push(row);
    }

    let errorMsg: string | null = null;
    if (rows.length) {
      const { error } = await supabaseAdmin.from("deals").upsert(rows as never, { onConflict: "pipedrive_id" });
      if (error) errorMsg = error.message;
    }

    const pg = page.additional_data?.pagination;
    return {
      processed: rows.length,
      skipped,
      error: errorMsg,
      nextStart: pg?.more_items_in_collection ? (pg.next_start ?? data.start + PAGE_LIMIT) : null,
      done: !pg?.more_items_in_collection,
    };
  });

// -----------------------------------------------------------------------------
// Phase 4 — final bookkeeping.
// -----------------------------------------------------------------------------
export const syncPdFinalize = createServerFn({ method: "POST" })
  .inputValidator((data: { pipelines?: number; stages?: number; contacts?: number; deals?: number } | undefined) => ({
    pipelines: Number(data?.pipelines ?? 0),
    stages: Number(data?.stages ?? 0),
    contacts: Number(data?.contacts ?? 0),
    deals: Number(data?.deals ?? 0),
  }))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("sync_state").upsert({
      source: "pipedrive",
      last_run_at: new Date().toISOString(),
      last_status: "ok",
      last_error: null,
      stats: data,
      updated_at: new Date().toISOString(),
    });
    return { ok: true };
  });

// -----------------------------------------------------------------------------
// Back-compat: one-shot sync (kept for scripts/tests). The UI uses the
// phased functions above so it can show progress.
// -----------------------------------------------------------------------------
export const syncPipedrive = createServerFn({ method: "POST" }).handler(async () => {
  const startedAt = Date.now();
  const meta = await syncPdMeta();
  let start: number | null = 0;
  let contacts = 0;
  while (start !== null) {
    const r = await syncPdContactsChunk({ data: { start } });
    contacts += r.processed;
    start = r.nextStart;
  }
  start = 0;
  let deals = 0;
  while (start !== null) {
    const r = await syncPdDealsChunk({ data: { start } });
    deals += r.processed;
    start = r.nextStart;
  }
  const stats = { pipelines: meta.pipelines, stages: meta.stages, contacts, deals };
  await syncPdFinalize({ data: stats });
  return { ok: true, stats, durationMs: Date.now() - startedAt };
});
