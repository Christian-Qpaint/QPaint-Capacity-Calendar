/**
 * Lightweight tagged logger so console output is consistent and grep-able.
 *   log.info("jobs:list", { count })   → [info][jobs:list] { count }
 *   log.warn("auth", "no session")
 *   log.error("mutate:createJob", err)
 *
 * Cheap, sync, side-effect-free wrapper around console — easy to swap for a
 * remote sink later without touching call sites.
 */
type LogArgs = unknown[];

function emit(level: "info" | "warn" | "error", tag: string, args: LogArgs) {
  const prefix = `[${level}][${tag}]`;
  const fn = level === "info" ? console.info : level === "warn" ? console.warn : console.error;
  fn(prefix, ...args);
}

export const log = {
  info: (tag: string, ...args: LogArgs) => emit("info", tag, args),
  warn: (tag: string, ...args: LogArgs) => emit("warn", tag, args),
  error: (tag: string, ...args: LogArgs) => emit("error", tag, args),
};
