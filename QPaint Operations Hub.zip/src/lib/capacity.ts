// Centralized capacity & job-risk calculations for QPaint.
// Pure functions — safe to use in dashboards, reports, calendar, and detail pages.

export type CapacityStatus = "Available" | "Near Capacity" | "Full" | "Overbooked";

export interface DailyCapacityInput {
  /** Total staff hours scheduled to be available that day (pre-leave). */
  staffHours: number;
  /** Hours lost to leave / sick / unavailable / training. */
  leaveHours?: number;
  /** Sum of planned_hours across all schedules for that day. */
  bookedHours: number;
}

export interface DailyCapacity {
  availableHours: number;
  bookedHours: number;
  remainingHours: number;
  utilizationPct: number;
  status: CapacityStatus;
}

/** Rule 1–5: full daily capacity calculation for a crew or staff group. */
export function calculateDailyCapacity(input: DailyCapacityInput): DailyCapacity {
  const available = Math.max(0, input.staffHours - (input.leaveHours ?? 0));
  const booked = Math.max(0, input.bookedHours);
  const remaining = available - booked;
  const utilization = available > 0 ? (booked / available) * 100 : booked > 0 ? 101 : 0;
  return {
    availableHours: available,
    bookedHours: booked,
    remainingHours: remaining,
    utilizationPct: Math.round(utilization),
    status: capacityStatus(utilization),
  };
}

/** Rule 5: map utilization % to a capacity status bucket. */
export function capacityStatus(utilizationPct: number): CapacityStatus {
  if (utilizationPct > 100) return "Overbooked";
  if (utilizationPct > 90) return "Full";
  if (utilizationPct > 70) return "Near Capacity";
  return "Available";
}

/** Tailwind/semantic tone tokens for capacity status. */
export function capacityTone(status: CapacityStatus) {
  switch (status) {
    case "Overbooked":
      return { bar: "bg-critical", chip: "bg-critical/15 text-critical border-critical/30" };
    case "Full":
      return { bar: "bg-warning", chip: "bg-warning/15 text-warning border-warning/30" };
    case "Near Capacity":
      return { bar: "bg-warning/70", chip: "bg-warning/10 text-warning border-warning/20" };
    default:
      return { bar: "bg-success", chip: "bg-success/15 text-success border-success/30" };
  }
}

/** Rule 6: hours remaining for a job. */
export function jobRemainingHours(estimated: number, worked: number): number {
  return Math.max(0, estimated - worked);
}

// ---------- Job risk ----------

export type JobRisk = "On Track" | "Watch" | "At Risk" | "Critical";

export interface JobRiskInput {
  completionPct: number;        // 0–100
  startDate: string | Date;
  targetFinishDate: string | Date;
  today?: string | Date;
  hasBlocker?: boolean;
  hasCrewAssigned?: boolean;
  crewOverbooked?: boolean;
}

export interface JobRiskResult {
  risk: JobRisk;
  reasons: string[];
  plannedPct: number;
  delta: number; // actual − planned
}

/** Rule 7: composite job-risk evaluation. */
export function evaluateJobRisk(input: JobRiskInput): JobRiskResult {
  const today = new Date(input.today ?? new Date());
  const start = new Date(input.startDate);
  const end = new Date(input.targetFinishDate);

  const total = Math.max(1, end.getTime() - start.getTime());
  const elapsed = Math.min(total, Math.max(0, today.getTime() - start.getTime()));
  const plannedPct = Math.round((elapsed / total) * 100);
  const delta = input.completionPct - plannedPct;

  const daysToFinish = Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  const reasons: string[] = [];
  if (!input.hasCrewAssigned) reasons.push("No crew assigned");
  if (input.crewOverbooked) reasons.push("Assigned crew is overbooked");
  if (input.hasBlocker) reasons.push("Active blocker");
  if (delta <= -15) reasons.push(`Behind plan by ${Math.abs(delta)}%`);
  else if (delta <= -5) reasons.push(`Tracking ${Math.abs(delta)}% behind plan`);
  if (daysToFinish <= 3 && input.completionPct < 90) {
    reasons.push(`Target finish in ${Math.max(0, daysToFinish)}d, only ${input.completionPct}% complete`);
  }

  let risk: JobRisk = "On Track";
  if (!input.hasCrewAssigned || delta <= -20 || (daysToFinish <= 1 && input.completionPct < 85)) {
    risk = "Critical";
  } else if (input.hasBlocker || input.crewOverbooked || delta <= -10 || (daysToFinish <= 5 && input.completionPct < 70)) {
    risk = "At Risk";
  } else if (delta <= -5 || (daysToFinish <= 7 && input.completionPct < 80)) {
    risk = "Watch";
  }

  return { risk, reasons, plannedPct, delta };
}

/** Tone tokens for a job risk level. */
export function riskTone(risk: JobRisk) {
  switch (risk) {
    case "Critical":
      return "bg-critical/15 text-critical border-critical/30";
    case "At Risk":
      return "bg-warning/15 text-warning border-warning/30";
    case "Watch":
      return "bg-warning/10 text-warning border-warning/20";
    default:
      return "bg-success/15 text-success border-success/30";
  }
}
