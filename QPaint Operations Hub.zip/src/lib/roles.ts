import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "owner" | "ops_manager" | "crew_leader" | "contractor" | "admin";

export const ROLE_LABELS: Record<AppRole, string> = {
  owner: "Owner / Executive",
  ops_manager: "Operations Manager",
  crew_leader: "Crew Leader",
  contractor: "Contractor",
  admin: "Admin",
};

const ROLE_PRIORITY: AppRole[] = ["owner", "admin", "ops_manager", "crew_leader", "contractor"];

export function useMyRoles() {
  return useQuery({
    queryKey: ["my-roles"],
    queryFn: async (): Promise<AppRole[]> => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return [];
      const { data, error } = await supabase
        .from("user_roles" as never)
        .select("role")
        .eq("user_id", userData.user.id);
      if (error) return [];
      return (data ?? []).map((r: { role: AppRole }) => r.role);
    },
    staleTime: 60_000,
  });
}

export function pickPrimaryRole(roles: AppRole[]): AppRole {
  for (const r of ROLE_PRIORITY) if (roles.includes(r)) return r;
  return "owner"; // default view when no roles assigned yet
}
