export type JobStatus = "Scheduled" | "In Progress" | "On Hold" | "Completed" | "Billing";

export interface Job {
  id: string;
  name: string;
  client: string;
  address: string;
  crew: string;
  status: JobStatus;
  progress: number;
  start: string;
  end: string;
  value: number;
  billingReady: boolean;
}

export const jobs: Job[] = [
  { id: "QP-1042", name: "Marina Heights Repaint", client: "Marina Heights HOA", address: "12 Marina Pde, Bondi", crew: "Crew Alpha", status: "In Progress", progress: 62, start: "2026-06-18", end: "2026-07-02", value: 48500, billingReady: false },
  { id: "QP-1043", name: "Cafe Lumen Interior", client: "Lumen Hospitality", address: "88 Oxford St, Paddington", crew: "Crew Bravo", status: "Scheduled", progress: 0, start: "2026-06-26", end: "2026-06-30", value: 12400, billingReady: false },
  { id: "QP-1044", name: "Northside Medical Fitout", client: "Northside Health", address: "5 Pacific Hwy, Chatswood", crew: "Crew Charlie", status: "In Progress", progress: 35, start: "2026-06-20", end: "2026-07-10", value: 86200, billingReady: false },
  { id: "QP-1045", name: "Wattle Primary School", client: "Dept of Education", address: "210 Wattle Rd, Ryde", crew: "Crew Delta", status: "On Hold", progress: 18, start: "2026-06-15", end: "2026-07-15", value: 64000, billingReady: false },
  { id: "QP-1039", name: "Eastview Apartments", client: "Eastview Strata", address: "44 Eastview Ave, Coogee", crew: "Crew Alpha", status: "Completed", progress: 100, start: "2026-05-28", end: "2026-06-22", value: 102300, billingReady: true },
  { id: "QP-1040", name: "Harbour Office Tower L12", client: "Harbour REIT", address: "1 George St, Sydney", crew: "Crew Echo", status: "Billing", progress: 100, start: "2026-05-30", end: "2026-06-20", value: 158900, billingReady: true },
];

export interface Crew {
  id: string;
  name: string;
  lead: string;
  size: number;
  utilization: number;
  currentJob: string | null;
  nextAvailable: string;
}

export const crews: Crew[] = [
  { id: "alpha", name: "Crew Alpha", lead: "Jordan Mills", size: 5, utilization: 92, currentJob: "Marina Heights Repaint", nextAvailable: "Jul 03" },
  { id: "bravo", name: "Crew Bravo", lead: "Priya Shah", size: 4, utilization: 70, currentJob: "Cafe Lumen Interior", nextAvailable: "Jul 01" },
  { id: "charlie", name: "Crew Charlie", lead: "Marco Diaz", size: 6, utilization: 88, currentJob: "Northside Medical Fitout", nextAvailable: "Jul 11" },
  { id: "delta", name: "Crew Delta", lead: "Anna Kovac", size: 4, utilization: 45, currentJob: "Wattle Primary School", nextAvailable: "Jun 28" },
  { id: "echo", name: "Crew Echo", lead: "Tom Becker", size: 5, utilization: 30, currentJob: null, nextAvailable: "Today" },
];

export interface Staff {
  id: string;
  name: string;
  role: string;
  crew: string;
  status: "On Job" | "Available" | "Leave" | "Sick";
  licence: string;
}

export const staff: Staff[] = [
  { id: "S-01", name: "Jordan Mills", role: "Crew Lead", crew: "Alpha", status: "On Job", licence: "Class A" },
  { id: "S-02", name: "Priya Shah", role: "Crew Lead", crew: "Bravo", status: "On Job", licence: "Class A" },
  { id: "S-03", name: "Marco Diaz", role: "Crew Lead", crew: "Charlie", status: "On Job", licence: "Class A" },
  { id: "S-04", name: "Anna Kovac", role: "Crew Lead", crew: "Delta", status: "On Job", licence: "Class A" },
  { id: "S-05", name: "Tom Becker", role: "Crew Lead", crew: "Echo", status: "Available", licence: "Class A" },
  { id: "S-06", name: "Lila Nguyen", role: "Painter", crew: "Alpha", status: "On Job", licence: "Class B" },
  { id: "S-07", name: "Ben Carter", role: "Painter", crew: "Bravo", status: "Leave", licence: "Class B" },
  { id: "S-08", name: "Henry Liu", role: "Apprentice", crew: "Charlie", status: "On Job", licence: "Trainee" },
  { id: "S-09", name: "Sara Okafor", role: "Painter", crew: "Delta", status: "Sick", licence: "Class B" },
  { id: "S-10", name: "Ravi Khan", role: "Painter", crew: "Echo", status: "Available", licence: "Class B" },
];

export const conflicts = [
  { id: "C-1", message: "Crew Alpha double-booked Jul 02 (Marina Heights overlap with quoted job Q-0118).", severity: "critical" as const },
  { id: "C-2", message: "Crew Delta below minimum staffing — 2 painters on leave/sick.", severity: "warning" as const },
  { id: "C-3", message: "2 completed jobs awaiting invoicing for >5 days.", severity: "warning" as const },
];
