/**
 * Browser Supabase data layer.
 *
 * All ops tables currently have permissive RLS (public ALL) so we read and
 * write straight from the browser client. If/when RLS is tightened, swap the
 * functions in this file for `createServerFn` handlers without changing
 * components — they all consume `*QueryOptions`.
 */
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { log } from "@/lib/log";

/* ---------- row helpers ---------- */

export type JobRow = {
  id: string;
  job_code: string;
  client_name: string;
  job_name: string;
  location: string | null;
  client_contact: string | null;
  start_date: string | null;
  target_finish_date: string | null;
  estimated_hours: number;
  hours_worked: number;
  completion_percentage: number;
  status: string;
  billing_status: string;
  assigned_crew_id: string | null;
  supervisor_id: string | null;
  notes: string | null;
  source_deal_id?: string | null;
  contact_id?: string | null;
  // Phase 2.1 — Financial Capacity Engine
  contract_value?: number | null;
  forecast_revenue?: number | null;
  billing_method?: string | null;
  retention_pct?: number | null;
  revenue_category?: string | null;
  business_unit?: string | null;
  division?: string | null;
  region?: string | null;
  priority?: string | null;
  job_type?: string | null;
  estimated_labour_hours?: number | null;
  estimated_duration_days?: number | null;
  estimated_productivity?: number | null;
};

export type CrewRow = {
  id: string;
  name: string;
  leader_id: string | null;
  crew_type: string | null;
  weekly_capacity_hours: number;
  status: string;
  notes: string | null;
  color: string | null;
};

export type StaffRow = {
  id: string;
  full_name: string;
  role: string;
  crew_id: string | null;
  skills: string[] | null;
  normal_hours_per_week: number;
  contact_number: string | null;
  email: string | null;
  status: string;
};

export type ScheduleRow = {
  id: string;
  job_id: string;
  crew_id: string | null;
  scheduled_date: string;
  end_date: string;
  start_time: string | null;
  end_time: string | null;
  planned_hours: number;
  actual_hours: number | null;
  status: string;
  notes: string | null;
  color: string | null;
};



/* ---------- Jobs = deals in the Jobs Pipeline ----------
 *
 * There is no standalone `jobs` table anymore. A "job" is a deal that has
 * moved into the Jobs Pipeline. We keep the JobRow shape so every consumer
 * (calendar, list, detail, my-assignments) stays unchanged.
 */
export const JOBS_PIPELINE_ID = "4d3420c3-57a2-4ebb-a7a2-cc0fd2617234";

type DealWithStage = Record<string, unknown> & {
  id: string;
  pipeline_stage: { name: string } | null;
};

function dealToJob(row: DealWithStage): JobRow {
  const d = row as unknown as Record<string, unknown>;
  const str = (k: string) => (d[k] == null ? null : String(d[k]));
  const num = (k: string) => (d[k] == null ? null : Number(d[k]));
  const stageName = (row.pipeline_stage?.name ?? "").replace(/^\d+\.\s*/, "") || "Ready to Schedule";
  return {
    id: String(d.id),
    job_code: str("quote_id") ?? `D-${String(d.id).slice(0, 8)}`,
    client_name: str("client_name") ?? "—",
    job_name:
      (str("extent_of_work") ?? "").slice(0, 80) ||
      (str("description") ?? "").slice(0, 80) ||
      `${str("client_name") ?? "Project"}`,
    location: str("property_address"),
    client_contact: str("contact_person") ?? str("phone") ?? str("email"),
    start_date: str("start_date") ?? str("appointment_date"),
    target_finish_date: str("target_finish_date"),
    estimated_hours: Number(d.target_hours ?? 0),
    hours_worked: Number(d.hours_worked ?? d.actual_hours ?? 0),
    completion_percentage: Number(d.completion_percentage ?? 0),
    status: stageName,
    billing_status: str("billing_status") ?? "Not Ready",
    assigned_crew_id: str("assigned_crew_id"),
    supervisor_id: str("supervisor_id"),
    notes: str("job_notes") ?? str("quote_notes") ?? str("description"),
    source_deal_id: String(d.id),
    contact_id: str("contact_id"),
    contract_value: num("contract_value") ?? num("expected_value"),
    forecast_revenue: num("forecast_revenue"),
    billing_method: str("billing_method"),
    retention_pct: num("retention_pct"),
    revenue_category: str("revenue_category"),
    business_unit: str("business_unit"),
    division: str("division"),
    region: str("region"),
    priority: str("priority"),
    job_type: str("job_type"),
    estimated_labour_hours: num("estimated_labour_hours"),
    estimated_duration_days: num("estimated_duration_days"),
    estimated_productivity: num("estimated_productivity"),
  };
}

const DEAL_JOB_SELECT = "*, pipeline_stage:pipeline_stages!deals_pipeline_stage_id_fkey(name)";

export const jobsQuery = queryOptions({
  queryKey: ["jobs"],
  queryFn: async (): Promise<JobRow[]> => {
    log.info("db:jobs:list");
    const { data, error } = await supabase
      .from("deals")
      .select(DEAL_JOB_SELECT)
      .eq("pipeline_id", JOBS_PIPELINE_ID)
      .order("start_date", { ascending: false, nullsFirst: false });
    if (error) {
      log.error("db:jobs:list", error);
      throw error;
    }
    return (data ?? []).map((r) => dealToJob(r as DealWithStage));
  },
});


export const crewsQuery = queryOptions({
  queryKey: ["crews"],
  queryFn: async (): Promise<CrewRow[]> => {
    log.info("db:crews:list");
    const { data, error } = await supabase.from("crews").select("*").order("name");
    if (error) {
      log.error("db:crews:list", error);
      throw error;
    }
    return (data ?? []) as CrewRow[];
  },
});

export const staffQuery = queryOptions({
  queryKey: ["staff"],
  queryFn: async (): Promise<StaffRow[]> => {
    log.info("db:staff:list");
    const { data, error } = await supabase.from("staff").select("*").order("full_name");
    if (error) {
      log.error("db:staff:list", error);
      throw error;
    }
    return (data ?? []) as StaffRow[];
  },
});

/* ---------- Phase 2.1: revenue targets & app settings ---------- */

export type RevenueTargetRow = {
  id: string;
  scope: "company" | "crew" | "division" | "region" | "business_unit";
  scope_ref: string | null;
  period: "month" | "week" | "day";
  period_start: string;
  target_amount: number;
  notes: string | null;
};

export type AppSettingsRow = {
  id: string;
  revenue_allocation_method: "start_month" | "prorated_dates" | "prorated_progress";
  revenue_recognition_method: "on_completion" | "progress_percent" | "milestone";
  traffic_light_green_pct: number;
  traffic_light_amber_pct: number;
  capacity_near_pct: number;
  capacity_full_pct: number;
  financial_year_start_month: number;
  progress_billing_enabled: boolean;
};

export const revenueTargetsQuery = queryOptions({
  queryKey: ["revenue_targets"],
  queryFn: async (): Promise<RevenueTargetRow[]> => {
    const { data, error } = await supabase
      .from("revenue_targets" as never)
      .select("*")
      .order("period_start", { ascending: false });
    if (error) { log.error("db:revenue_targets:list", error); throw error; }
    return (data ?? []) as RevenueTargetRow[];
  },
});

export const appSettingsQuery = queryOptions({
  queryKey: ["app_settings"],
  queryFn: async (): Promise<AppSettingsRow> => {
    const { data, error } = await supabase
      .from("app_settings" as never)
      .select("*")
      .limit(1)
      .maybeSingle();
    if (error) { log.error("db:app_settings:get", error); throw error; }
    return (data ?? {
      revenue_allocation_method: "prorated_progress",
      revenue_recognition_method: "progress_percent",
      traffic_light_green_pct: 95,
      traffic_light_amber_pct: 80,
      capacity_near_pct: 70,
      capacity_full_pct: 90,
      financial_year_start_month: 7,
      progress_billing_enabled: true,
    }) as AppSettingsRow;
  },
});

/* ---------- Phase 2.2: mutations for targets & settings ---------- */

export async function upsertAppSettings(patch: Partial<AppSettingsRow>): Promise<void> {
  const { data: existing } = await supabase.from("app_settings" as never).select("id").limit(1).maybeSingle();
  const id = (existing as { id?: string } | null)?.id;
  if (id) {
    const { error } = await supabase.from("app_settings" as never).update(patch as never).eq("id", id);
    if (error) throw error;
  } else {
    const { error } = await supabase.from("app_settings" as never).insert(patch as never);
    if (error) throw error;
  }
}

export async function createRevenueTarget(input: Omit<RevenueTargetRow, "id">): Promise<RevenueTargetRow> {
  const { data, error } = await supabase.from("revenue_targets" as never).insert(input as never).select().single();
  if (error) throw error;
  return data as RevenueTargetRow;
}
export async function updateRevenueTarget(id: string, patch: Partial<RevenueTargetRow>): Promise<void> {
  const { error } = await supabase.from("revenue_targets" as never).update(patch as never).eq("id", id);
  if (error) throw error;
}
export async function deleteRevenueTarget(id: string): Promise<void> {
  const { error } = await supabase.from("revenue_targets" as never).delete().eq("id", id);
  if (error) throw error;
}

export async function updateJobContractValue(
  id: string,
  patch: Partial<Pick<JobRow, "contract_value" | "billing_method" | "retention_pct" | "revenue_category" | "division" | "region" | "business_unit">>,
): Promise<void> {
  const { error } = await supabase.from("deals").update(patch as never).eq("id", id);
  if (error) throw error;
}

export const schedulesQuery = queryOptions({
  queryKey: ["schedules"],
  queryFn: async (): Promise<ScheduleRow[]> => {
    log.info("db:schedules:list");
    const { data, error } = await supabase
      .from("schedules")
      .select("*")
      .order("scheduled_date");
    if (error) {
      log.error("db:schedules:list", error);
      throw error;
    }
    return (data ?? []) as ScheduleRow[];
  },
});

export function jobByIdQuery(jobId: string) {
  return queryOptions({
    queryKey: ["jobs", jobId],
    queryFn: async (): Promise<JobRow | null> => {
      log.info("db:jobs:get", { jobId });
      // Accept UUID (deal id) or quote_id (e.g. "QP-1042") lookups.
      const looksLikeUuid = /^[0-9a-f-]{36}$/i.test(jobId);
      const col = looksLikeUuid ? "id" : "quote_id";
      const { data, error } = await supabase
        .from("deals")
        .select(DEAL_JOB_SELECT)
        .eq("pipeline_id", JOBS_PIPELINE_ID)
        .eq(col, jobId)
        .maybeSingle();
      if (error) {
        log.error("db:jobs:get", error);
        throw error;
      }
      return data ? dealToJob(data as DealWithStage) : null;
    },
  });
}

/* ---------- mutations ---------- */
// createJob is intentionally removed: jobs are created by moving a deal
// into the Jobs Pipeline via convertDealToJob / moveDealToPipeline.


export async function createCrew(input: {
  name: string;
  crewType: string;
  weeklyCapacity: number;
  notes?: string;
}): Promise<CrewRow> {
  log.info("mutate:createCrew", input);
  const { data, error } = await supabase
    .from("crews")
    .insert({
      name: input.name,
      crew_type: input.crewType,
      weekly_capacity_hours: input.weeklyCapacity,
      notes: input.notes ?? null,
    })
    .select()
    .single();
  if (error) {
    log.error("mutate:createCrew", error);
    throw error;
  }
  return data as CrewRow;
}

export async function updateCrew(id: string, patch: Partial<{ name: string; color: string | null; weekly_capacity_hours: number; status: string; notes: string | null }>): Promise<void> {
  log.info("mutate:updateCrew", { id, patch });
  const { error } = await supabase.from("crews").update(patch as never).eq("id", id);
  if (error) { log.error("mutate:updateCrew", error); throw error; }
}




export async function createStaff(input: {
  fullName: string;
  role: string;
  crewId?: string | null;
  skills?: string[];
  weeklyHours: number;
  phone: string;
  email: string;
}): Promise<StaffRow> {
  log.info("mutate:createStaff", input);
  const { data, error } = await supabase
    .from("staff")
    .insert({
      full_name: input.fullName,
      role: input.role,
      crew_id: input.crewId ?? null,
      skills: input.skills ?? [],
      normal_hours_per_week: input.weeklyHours,
      contact_number: input.phone,
      email: input.email,
    })
    .select()
    .single();
  if (error) {
    log.error("mutate:createStaff", error);
    throw error;
  }
  return data as StaffRow;
}

export async function logProgress(input: {
  jobId: string;
  completion: number;
  hoursWorked: number;
  blocker?: string;
  notes?: string;
}) {
  log.info("mutate:logProgress", input);
  // Normalize free-text blocker to one of the enum values, defaulting to "None".
  const blockerMap: Record<string, "None" | "Weather" | "Material Delay" | "Client Delay" | "Staff Shortage" | "Access" | "Other"> = {
    none: "None",
    weather: "Weather",
    "materials delay": "Material Delay",
    "material delay": "Material Delay",
    "client access": "Access",
    access: "Access",
    "client delay": "Client Delay",
    "scope change": "Other",
    safety: "Other",
    "staff shortage": "Staff Shortage",
    other: "Other",
  };
  const blockerEnum = blockerMap[(input.blocker ?? "none").toLowerCase()] ?? "None";
  const { error: insErr } = await supabase.from("job_progress_updates").insert({
    job_id: input.jobId,
    progress_percentage: input.completion,
    hours_worked: input.hoursWorked,
    blocker_type: blockerEnum,
    update_note: input.notes ?? null,
  });
  if (insErr) {
    log.error("mutate:logProgress insert", insErr);
    throw insErr;
  }
  // Also bump deal (job) aggregate columns so list views reflect the latest update.
  const { error: updErr } = await supabase
    .from("deals")
    .update({
      completion_percentage: input.completion,
      hours_worked: input.hoursWorked,
    } as never)
    .eq("id", input.jobId);
  if (updErr) log.warn("mutate:logProgress deals update", updErr);
}

/* ---------- schedule mutations (used by Capacity Calendar) ---------- */

export async function createSchedule(input: {
  jobId: string;
  crewId: string | null;
  date: string;
  endDate?: string | null;
  startTime?: string | null;
  endTime?: string | null;
  plannedHours: number;
  notes?: string | null;
}): Promise<ScheduleRow> {
  log.info("mutate:createSchedule", input);
  const { data, error } = await supabase
    .from("schedules")
    .insert({
      job_id: input.jobId,
      crew_id: input.crewId,
      scheduled_date: input.date,
      end_date: input.endDate ?? input.date,
      start_time: input.startTime ?? null,
      end_time: input.endTime ?? null,
      planned_hours: input.plannedHours,
      notes: input.notes ?? null,
    } as never)
    .select()
    .single();
  if (error) {
    log.error("mutate:createSchedule", error);
    throw error;
  }
  return data as ScheduleRow;
}

export async function updateSchedule(
  id: string,
  patch: Partial<{
    scheduled_date: string;
    end_date: string;
    crew_id: string | null;
    planned_hours: number;
    notes: string | null;
    status: string;
    color: string | null;
  }>,

): Promise<void> {
  log.info("mutate:updateSchedule", { id, patch });
  const { error } = await supabase.from("schedules").update(patch as never).eq("id", id);
  if (error) {
    log.error("mutate:updateSchedule", error);
    throw error;
  }
}


export async function deleteSchedule(id: string): Promise<void> {
  log.info("mutate:deleteSchedule", { id });
  const { error } = await supabase.from("schedules").delete().eq("id", id);
  if (error) {
    log.error("mutate:deleteSchedule", error);
    throw error;
  }
}

export function crewByIdQuery(crewId: string) {
  return queryOptions({
    queryKey: ["crews", crewId],
    queryFn: async (): Promise<CrewRow | null> => {
      const looksLikeUuid = /^[0-9a-f-]{36}$/i.test(crewId);
      if (!looksLikeUuid) return null;
      const { data, error } = await supabase.from("crews").select("*").eq("id", crewId).maybeSingle();
      if (error) throw error;
      return (data ?? null) as CrewRow | null;
    },
  });
}

/* ---------- CRM / Sales Pipeline ---------- */

export const DEAL_STAGES = [
  "Lead Received",
  "Contact Qualified",
  "Site Visit Booked",
  "Site Visit Completed",
  "Quote Review",
  "Quote Sent",
] as const;
export type DealStage = (typeof DEAL_STAGES)[number];

export const DEAL_PRIORITIES = ["Low", "Normal", "High", "Urgent"] as const;
export type DealPriority = (typeof DEAL_PRIORITIES)[number];

export type DealRow = {
  id: string;
  quote_id: string;
  client_name: string;
  property_address: string | null;
  contact_person: string | null;
  phone: string | null;
  email: string | null;
  owner: string | null;
  client_ranking: string | null;
  category: string | null;
  quote_type: string | null;
  referral_source: string | null;
  extent_of_work: string | null;
  description: string | null;
  appointment_date: string | null;
  appointment_time: string | null;
  estimator: string | null;
  site_visit_status: string | null;
  site_visit_notes: string | null;
  quote_status: string | null;
  quote_sent_date: string | null;
  expected_value: number | null;
  target_hours: number | null;
  actual_hours: number | null;
  quote_notes: string | null;
  google_maps_link: string | null;
  google_drive_link: string | null;
  stage: DealStage;
  pipeline_id: string | null;
  pipeline_stage_id: string | null;
  priority: DealPriority;
  last_activity_at: string | null;
  next_activity_at: string | null;
  converted_job_id: string | null;
  contact_id?: string | null;
  created_at: string;
  updated_at: string;
};

const DEALS = "deals" as never;
const DEAL_HISTORY = "deal_stage_history" as never;

export const dealsQuery = queryOptions({
  queryKey: ["deals"],
  queryFn: async (): Promise<DealRow[]> => {
    log.info("db:deals:list");
    const { data, error } = await supabase
      .from(DEALS)
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) {
      log.error("db:deals:list", error);
      throw error;
    }
    return (data ?? []) as DealRow[];
  },
});

export function dealByIdQuery(dealId: string) {
  return queryOptions({
    queryKey: ["deals", dealId],
    queryFn: async (): Promise<DealRow | null> => {
      const { data, error } = await supabase
        .from(DEALS)
        .select("*")
        .eq("id", dealId)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as DealRow | null;
    },
  });
}

export async function createDeal(input: Partial<DealRow> & { client_name: string }): Promise<DealRow> {
  log.info("mutate:createDeal", input);
  const quote_id = input.quote_id ?? `Q-${Math.floor(10000 + Math.random() * 90000)}`;
  const payload = { ...input, quote_id, last_activity_at: new Date().toISOString() };
  const { data, error } = await supabase.from(DEALS).insert(payload as never).select().single();
  if (error) {
    log.error("mutate:createDeal", error);
    throw error;
  }
  return data as DealRow;
}

export async function updateDeal(id: string, patch: Partial<DealRow>): Promise<void> {
  log.info("mutate:updateDeal", { id, patch });
  const { error } = await supabase
    .from(DEALS)
    .update({ ...patch, last_activity_at: new Date().toISOString() } as never)
    .eq("id", id);
  if (error) {
    log.error("mutate:updateDeal", error);
    throw error;
  }
}

export async function moveDealStage(
  id: string,
  fromStage: DealStage | null,
  toStage: DealStage,
): Promise<void> {
  log.info("mutate:moveDealStage", { id, fromStage, toStage });
  const { error } = await supabase
    .from(DEALS)
    .update({ stage: toStage, last_activity_at: new Date().toISOString() } as never)
    .eq("id", id);
  if (error) throw error;
  await supabase
    .from(DEAL_HISTORY)
    .insert({ deal_id: id, from_stage: fromStage, to_stage: toStage } as never);
}

export async function deleteDeal(id: string): Promise<void> {
  log.info("mutate:deleteDeal", { id });
  const { error } = await supabase.from(DEALS).delete().eq("id", id);
  if (error) throw error;
}

/**
 * "Convert Deal to Job" now = move the deal into the Jobs Pipeline at the
 * "Ready to Schedule" stage. Returns the same deal as a JobRow.
 */
const JOBS_PIPELINE_FIRST_STAGE = "56a48f23-3a24-4f82-abec-c26bb84634cf"; // "2. Ready to Schedule"

export async function convertDealToJob(deal: DealRow): Promise<JobRow> {
  log.info("mutate:convertDealToJob", { id: deal.id });
  const { error } = await supabase
    .from(DEALS)
    .update({
      pipeline_id: JOBS_PIPELINE_ID,
      pipeline_stage_id: JOBS_PIPELINE_FIRST_STAGE,
      quote_status: "Accepted",
      start_date: deal.appointment_date,
      last_activity_at: new Date().toISOString(),
    } as never)
    .eq("id", deal.id);
  if (error) {
    log.error("mutate:convertDealToJob", error);
    throw error;
  }
  const { data: refreshed, error: refetchErr } = await supabase
    .from("deals")
    .select(DEAL_JOB_SELECT)
    .eq("id", deal.id)
    .maybeSingle();
  if (refetchErr) throw refetchErr;
  return dealToJob(refreshed as DealWithStage);
}


export function staffByIdQuery(staffId: string) {
  return queryOptions({
    queryKey: ["staff", staffId],
    queryFn: async (): Promise<StaffRow | null> => {
      const looksLikeUuid = /^[0-9a-f-]{36}$/i.test(staffId);
      if (!looksLikeUuid) return null;
      const { data, error } = await supabase.from("staff").select("*").eq("id", staffId).maybeSingle();
      if (error) throw error;
      return (data ?? null) as StaffRow | null;
    },
  });
}

/* ============================================================ */
/* Contacts (auto-created from Deals & Jobs)                    */
/* ============================================================ */

export type ContactRow = {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  company: string | null;
  ranking: string | null;
  source: string | null;
  notes: string | null;
  total_deals: number;
  total_jobs: number;
  lifetime_value: number;
  created_at: string;
  updated_at: string;
};

export const contactsQuery = queryOptions({
  queryKey: ["contacts"],
  queryFn: async (): Promise<ContactRow[]> => {
    const { data, error } = await supabase
      .from("contacts" as never)
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) {
      log.warn("contacts.list failed", { error: error.message });
      return [];
    }
    return (data ?? []) as ContactRow[];
  },
});

export function contactByIdQuery(contactId: string) {
  return queryOptions({
    queryKey: ["contact", contactId],
    queryFn: async (): Promise<ContactRow | null> => {
      const looksLikeUuid = /^[0-9a-f-]{36}$/i.test(contactId);
      if (!looksLikeUuid) return null;
      const { data, error } = await supabase
        .from("contacts" as never)
        .select("*")
        .eq("id", contactId)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as ContactRow | null;
    },
  });
}

export function dealsByContactQuery(contactId: string) {
  return queryOptions({
    queryKey: ["deals", "byContact", contactId],
    queryFn: async (): Promise<DealRow[]> => {
      const { data, error } = await supabase
        .from("deals")
        .select("*")
        .eq("contact_id" as never, contactId)
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as DealRow[];
    },
  });
}

export function jobsByContactQuery(contactId: string) {
  return queryOptions({
    queryKey: ["jobs", "byContact", contactId],
    queryFn: async (): Promise<JobRow[]> => {
      const { data, error } = await supabase
        .from("deals")
        .select(DEAL_JOB_SELECT)
        .eq("pipeline_id", JOBS_PIPELINE_ID)
        .eq("contact_id" as never, contactId)
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((r) => dealToJob(r as DealWithStage));
    },
  });
}

export async function updateContact(id: string, patch: Partial<ContactRow>): Promise<void> {
  const { error } = await supabase.from("contacts" as never).update(patch as never).eq("id", id);
  if (error) throw error;
}

export async function deleteContact(id: string): Promise<void> {
  const { error } = await supabase.from("contacts" as never).delete().eq("id", id);
  if (error) throw error;
}

export async function createContact(input: Partial<ContactRow> & { name: string }): Promise<ContactRow> {
  const { data, error } = await supabase.from("contacts" as never).insert(input as never).select("*").single();
  if (error) throw error;
  return data as ContactRow;
}

/* ============================================================ */
/* Dynamic Pipelines (Sales / Jobs / Custom)                    */
/* ============================================================ */

export type PipelineRow = {
  id: string;
  name: string;
  kind: string; // 'sales' | 'jobs' | 'custom'
  position: number;
  color: string | null;
  description: string | null;
  auto_schedule: boolean;
  created_at: string;
  updated_at: string;
};

export type PipelineStageRow = {
  id: string;
  pipeline_id: string;
  name: string;
  position: number;
  color: string | null;
  is_won: boolean;
  is_lost: boolean;
};

const PIPELINES = "pipelines" as never;
const PIPELINE_STAGES = "pipeline_stages" as never;

export const pipelinesQuery = queryOptions({
  queryKey: ["pipelines"],
  queryFn: async (): Promise<PipelineRow[]> => {
    const { data, error } = await supabase
      .from(PIPELINES)
      .select("*")
      .order("position", { ascending: true });
    if (error) throw error;
    return (data ?? []) as PipelineRow[];
  },
});

export const pipelineStagesQuery = queryOptions({
  queryKey: ["pipeline_stages"],
  queryFn: async (): Promise<PipelineStageRow[]> => {
    const { data, error } = await supabase
      .from(PIPELINE_STAGES)
      .select("*")
      .order("position", { ascending: true });
    if (error) throw error;
    return (data ?? []) as PipelineStageRow[];
  },
});

export async function createPipeline(input: { name: string; auto_schedule?: boolean; color?: string }): Promise<PipelineRow> {
  const { data, error } = await supabase
    .from(PIPELINES)
    .insert({ name: input.name, auto_schedule: input.auto_schedule ?? false, color: input.color ?? null, kind: "custom" } as never)
    .select()
    .single();
  if (error) throw error;
  return data as PipelineRow;
}

export async function updatePipeline(id: string, patch: Partial<PipelineRow>): Promise<void> {
  const { error } = await supabase.from(PIPELINES).update(patch as never).eq("id", id);
  if (error) throw error;
}

export async function deletePipeline(id: string): Promise<void> {
  // Explicitly clear child references first so we get a clean error if RLS blocks it,
  // rather than a silent 0-row delete.
  const { error: sErr } = await supabase.from(PIPELINE_STAGES).delete().eq("pipeline_id", id);
  if (sErr) throw sErr;
  const { error, count } = await supabase
    .from(PIPELINES)
    .delete({ count: "exact" })
    .eq("id", id);
  if (error) throw error;
  if (!count) throw new Error("Pipeline was not deleted. You may not have permission (sign in required).");
}

export async function createStage(input: { pipeline_id: string; name: string; position: number; color?: string }): Promise<PipelineStageRow> {
  const { data, error } = await supabase
    .from(PIPELINE_STAGES)
    .insert({ pipeline_id: input.pipeline_id, name: input.name, position: input.position, color: input.color ?? null } as never)
    .select()
    .single();
  if (error) throw error;
  return data as PipelineStageRow;
}

export async function updateStage(id: string, patch: Partial<PipelineStageRow>): Promise<void> {
  const { error } = await supabase.from(PIPELINE_STAGES).update(patch as never).eq("id", id);
  if (error) throw error;
}

export async function deleteStage(id: string): Promise<void> {
  const { error } = await supabase.from(PIPELINE_STAGES).delete().eq("id", id);
  if (error) throw error;
}

export async function reorderStages(updates: { id: string; position: number }[]): Promise<void> {
  for (const u of updates) {
    await updateStage(u.id, { position: u.position });
  }
}

/**
 * Move a deal to a new (pipeline, stage). If the deal moves into a pipeline
 * with auto_schedule=true and has no linked job yet, create a Job + a default
 * schedule block (uses appointment_date or today, target_hours, no crew).
 */
export async function moveDealToStage(input: {
  deal: DealRow;
  pipelineId: string;
  stageId: string;
  pipeline: PipelineRow;
}): Promise<void> {
  const { deal, pipelineId, stageId, pipeline } = input;
  const enteringNewPipeline = deal.pipeline_id !== pipelineId;

  const { error } = await supabase
    .from(DEALS)
    .update({
      pipeline_id: pipelineId,
      pipeline_stage_id: stageId,
      last_activity_at: new Date().toISOString(),
    } as never)
    .eq("id", deal.id);
  if (error) throw error;

  if (enteringNewPipeline && pipeline.auto_schedule && !deal.converted_job_id) {
    const job = await convertDealToJob(deal);
    const date = deal.appointment_date ?? new Date().toISOString().slice(0, 10);
    const hours = Number(deal.target_hours ?? 8);
    try {
      await createSchedule({
        jobId: job.id,
        crewId: null,
        date,
        endDate: date,
        plannedHours: hours,
        notes: `Auto-created from deal ${deal.quote_id} entering ${pipeline.name}`,
      });
    } catch (e) {
      log.warn("auto-schedule failed", e);
    }
  }
}

/* ---------- Phase 2.3 — Contractors ---------- */

export type ContractorRow = {
  id: string;
  company_id: string | null;
  name: string;
  email: string | null;
  phone: string | null;
  trade: string | null;
  skills: string[] | null;
  hourly_cost: number | null;
  hourly_bill_rate: number | null;
  is_active: boolean;
};

export type JobContractorAssignmentRow = {
  id: string;
  job_id: string;
  contractor_id: string;
  allocated_hours: number | null;
  hours_worked: number | null;
  hourly_rate: number | null;
  status: string;
  start_date: string | null;
  end_date: string | null;
  notes: string | null;
};

export const contractorsQuery = queryOptions({
  queryKey: ["contractors"],
  queryFn: async (): Promise<ContractorRow[]> => {
    const { data, error } = await supabase.from("contractors" as never).select("*").order("name");
    if (error) throw error;
    return (data ?? []) as unknown as ContractorRow[];
  },
  staleTime: 30_000,
});

export function jobContractorAssignmentsQuery(jobId: string) {
  return queryOptions({
    queryKey: ["job_contractor_assignments", jobId],
    queryFn: async (): Promise<JobContractorAssignmentRow[]> => {
      const { data, error } = await supabase
        .from("job_contractor_assignments" as never)
        .select("*")
        .eq("job_id", jobId);
      if (error) throw error;
      return (data ?? []) as unknown as JobContractorAssignmentRow[];
    },
  });
}

export const allContractorAssignmentsQuery = queryOptions({
  queryKey: ["job_contractor_assignments", "all"],
  queryFn: async (): Promise<JobContractorAssignmentRow[]> => {
    const { data, error } = await supabase.from("job_contractor_assignments" as never).select("*");
    if (error) throw error;
    return (data ?? []) as unknown as JobContractorAssignmentRow[];
  },
  staleTime: 30_000,
});

export async function createContractorAssignment(input: {
  job_id: string;
  contractor_id: string;
  allocated_hours?: number;
  hourly_rate?: number;
  start_date?: string | null;
  end_date?: string | null;
  notes?: string | null;
}): Promise<void> {
  const { error } = await supabase.from("job_contractor_assignments" as never).insert({
    job_id: input.job_id,
    contractor_id: input.contractor_id,
    allocated_hours: input.allocated_hours ?? 0,
    hourly_rate: input.hourly_rate ?? null,
    start_date: input.start_date ?? null,
    end_date: input.end_date ?? null,
    notes: input.notes ?? null,
    status: "scheduled",
  } as never);
  if (error) throw error;
}

export async function updateContractorAssignment(
  id: string,
  patch: Partial<Pick<JobContractorAssignmentRow, "allocated_hours" | "hours_worked" | "hourly_rate" | "status" | "start_date" | "end_date" | "notes">>,
): Promise<void> {
  const { error } = await supabase.from("job_contractor_assignments" as never).update(patch as never).eq("id", id);
  if (error) throw error;
}

export async function deleteContractorAssignment(id: string): Promise<void> {
  const { error } = await supabase.from("job_contractor_assignments" as never).delete().eq("id", id);
  if (error) throw error;
}

/* ---------- contractor self-view ---------- */

export type MyAssignmentRow = JobContractorAssignmentRow & {
  job: Pick<JobRow, "id" | "job_code" | "job_name" | "client_name" | "location" | "status" | "start_date" | "target_finish_date"> | null;
};

/**
 * Returns assignments for the currently signed-in contractor.
 * Match strategy: contractors.user_id = auth.uid(); fallback to email match.
 */
export const myAssignmentsQuery = queryOptions({
  queryKey: ["my_assignments"],
  queryFn: async (): Promise<{ contractor: ContractorRow | null; assignments: MyAssignmentRow[] }> => {
    const { data: userRes } = await supabase.auth.getUser();
    const user = userRes.user;
    if (!user) return { contractor: null, assignments: [] };

    let contractor: ContractorRow | null = null;
    const byUser = await supabase.from("contractors" as never).select("*").eq("user_id", user.id).maybeSingle();
    if (!byUser.error && byUser.data) contractor = byUser.data as unknown as ContractorRow;
    if (!contractor && user.email) {
      const byEmail = await supabase.from("contractors" as never).select("*").ilike("email", user.email).maybeSingle();
      if (!byEmail.error && byEmail.data) contractor = byEmail.data as unknown as ContractorRow;
    }
    if (!contractor) return { contractor: null, assignments: [] };

    const { data, error } = await supabase
      .from("job_contractor_assignments" as never)
      .select(
        "*, job:deals!job_contractor_assignments_job_id_fkey(id, quote_id, extent_of_work, description, client_name, property_address, start_date, target_finish_date, pipeline_stage:pipeline_stages!deals_pipeline_stage_id_fkey(name))",
      )
      .eq("contractor_id", contractor.id)
      .order("start_date", { ascending: false, nullsFirst: false });
    if (error) throw error;
    const rows = (data ?? []) as unknown as Array<
      JobContractorAssignmentRow & { job: (DealWithStage & { quote_id?: string; extent_of_work?: string; description?: string; property_address?: string }) | null }
    >;
    const assignments: MyAssignmentRow[] = rows.map((r) => {
      const j = r.job as unknown as {
        id: string;
        quote_id?: string | null;
        extent_of_work?: string | null;
        description?: string | null;
        client_name?: string | null;
        property_address?: string | null;
        start_date?: string | null;
        target_finish_date?: string | null;
        pipeline_stage?: { name?: string | null } | null;
      } | null;
      return {
        ...r,
        job: j
          ? {
              id: String(j.id),
              job_code: j.quote_id ? String(j.quote_id) : `D-${String(j.id).slice(0, 8)}`,
              job_name:
                String(j.extent_of_work ?? "").slice(0, 80) ||
                String(j.description ?? "").slice(0, 80) ||
                String(j.client_name ?? "Project"),
              client_name: String(j.client_name ?? "—"),
              location: j.property_address ?? null,
              status: String(j.pipeline_stage?.name ?? "").replace(/^\d+\.\s*/, "") || "Ready to Schedule",
              start_date: j.start_date ?? null,
              target_finish_date: j.target_finish_date ?? null,
            }
          : null,
      };
    });
    return { contractor, assignments };



  },
  staleTime: 30_000,
});

/* ============================================================ */
/* Job detail: milestones, notes, blockers, on-site crew         */
/* ============================================================ */

export type JobMilestoneRow = {
  id: string;
  job_id: string;         // deal id
  milestone_name: string;
  is_completed: boolean;
  completed_at: string | null;
  sort_order: number | null;
};

export type JobNoteRow = {
  id: string;
  deal_id: string;
  author_id: string | null;
  author_name: string | null;
  body: string;
  created_at: string;
};

export type JobBlockerRow = {
  id: string;
  deal_id: string;
  kind: string;
  label: string;
  body: string | null;
  tone: "warning" | "critical";
  resolved_at: string | null;
  created_at: string;
};

export function jobMilestonesQuery(dealId: string) {
  return queryOptions({
    queryKey: ["job_milestones", dealId],
    queryFn: async (): Promise<JobMilestoneRow[]> => {
      const { data, error } = await supabase
        .from("job_milestones")
        .select("*")
        .eq("job_id", dealId)
        .order("sort_order", { ascending: true, nullsFirst: false })
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as JobMilestoneRow[];
    },
  });
}

export async function toggleJobMilestone(id: string, done: boolean): Promise<void> {
  const { error } = await supabase
    .from("job_milestones")
    .update({ is_completed: done, completed_at: done ? new Date().toISOString() : null } as never)
    .eq("id", id);
  if (error) throw error;
}

export async function addJobMilestone(dealId: string, name: string): Promise<void> {
  const { error } = await supabase
    .from("job_milestones")
    .insert({ job_id: dealId, milestone_name: name, is_completed: false } as never);
  if (error) throw error;
}

export function jobNotesQuery(dealId: string) {
  return queryOptions({
    queryKey: ["job_notes", dealId],
    queryFn: async (): Promise<JobNoteRow[]> => {
      const { data, error } = await supabase
        .from("job_notes" as never)
        .select("*")
        .eq("deal_id", dealId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as JobNoteRow[];
    },
  });
}

export async function addJobNote(dealId: string, body: string): Promise<void> {
  const { data: userRes } = await supabase.auth.getUser();
  const u = userRes.user;
  const { error } = await supabase.from("job_notes" as never).insert({
    deal_id: dealId,
    author_id: u?.id ?? null,
    author_name: u?.user_metadata?.full_name ?? u?.email ?? "Unknown",
    body,
  } as never);
  if (error) throw error;
}

export function jobBlockersQuery(dealId: string) {
  return queryOptions({
    queryKey: ["job_blockers", dealId],
    queryFn: async (): Promise<JobBlockerRow[]> => {
      const { data, error } = await supabase
        .from("job_blockers" as never)
        .select("*")
        .eq("deal_id", dealId)
        .order("resolved_at", { ascending: true, nullsFirst: true })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as JobBlockerRow[];
    },
  });
}

export async function addJobBlocker(input: {
  dealId: string;
  kind: string;
  label: string;
  body?: string;
  tone?: "warning" | "critical";
}): Promise<void> {
  const { error } = await supabase.from("job_blockers" as never).insert({
    deal_id: input.dealId,
    kind: input.kind,
    label: input.label,
    body: input.body ?? null,
    tone: input.tone ?? "warning",
  } as never);
  if (error) throw error;
}

export async function resolveJobBlocker(id: string): Promise<void> {
  const { error } = await supabase
    .from("job_blockers" as never)
    .update({ resolved_at: new Date().toISOString() } as never)
    .eq("id", id);
  if (error) throw error;
}

export function jobOnsiteCrewQuery(crewId: string | null) {
  return queryOptions({
    queryKey: ["job_onsite_crew", crewId ?? "none"],
    queryFn: async (): Promise<StaffRow[]> => {
      if (!crewId) return [];
      const { data, error } = await supabase
        .from("staff")
        .select("*")
        .eq("crew_id", crewId)
        .order("full_name");
      if (error) throw error;
      return (data ?? []) as StaffRow[];
    },
  });
}

export function jobProgressUpdatesQuery(dealId: string) {
  return queryOptions({
    queryKey: ["job_progress_updates", dealId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_progress_updates")
        .select("*")
        .eq("job_id", dealId)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data ?? [];
    },
  });
}

