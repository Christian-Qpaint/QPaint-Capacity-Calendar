// Phase 2.1 — Financial Capacity Engine
// Pure functions that convert scheduled jobs into revenue KPIs.
// Additive: coexists with src/lib/capacity.ts (hours-based).

export type RevenueAllocationMethod = "start_month" | "prorated_dates" | "prorated_progress";
export type TrafficLight = "green" | "amber" | "red";

export interface JobLike {
  id: string;
  contract_value?: number | null;
  completion_percent?: number | null;
  start_date?: string | null;
  target_finish_date?: string | null;
  status?: string | null;
  crew_id?: string | null;
  business_unit?: string | null;
  division?: string | null;
  region?: string | null;
}

export interface RevenuePeriod {
  /** First day of the month, YYYY-MM-01 */
  monthKey: string;
  target: number;
  booked: number;        // contract value allocated to this month
  recognized: number;    // contract_value * completion% for jobs in this month
  forecast: number;      // booked − recognized (still to earn) + recognized
  remaining: number;     // target − forecast
  achievementPct: number;
  status: TrafficLight;
}

const money = (n: number | null | undefined) => Math.max(0, Number(n ?? 0));
const pct = (n: number | null | undefined) => Math.min(100, Math.max(0, Number(n ?? 0)));

export function monthKeyOf(d: Date | string): string {
  const dt = typeof d === "string" ? new Date(d) : d;
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, "0")}-01`;
}

/** Split a job's contract value into month buckets according to the chosen method. */
export function allocateJobRevenue(
  job: JobLike,
  method: RevenueAllocationMethod,
): Record<string, { booked: number; recognized: number }> {
  const value = money(job.contract_value);
  if (value === 0 || !job.start_date) return {};

  const start = new Date(job.start_date);
  const end = job.target_finish_date ? new Date(job.target_finish_date) : start;
  const completion = pct(job.completion_percent);

  if (method === "start_month" || end <= start) {
    const key = monthKeyOf(start);
    return { [key]: { booked: value, recognized: (value * completion) / 100 } };
  }

  // Build day → month distribution
  const totalDays = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / 86400000) + 1);
  const perDay = value / totalDays;
  const out: Record<string, { booked: number; recognized: number }> = {};

  for (let i = 0; i < totalDays; i++) {
    const d = new Date(start.getTime() + i * 86400000);
    const k = monthKeyOf(d);
    if (!out[k]) out[k] = { booked: 0, recognized: 0 };
    out[k].booked += perDay;
  }

  // prorated_progress: recognized = completion% * booked per month
  // prorated_dates:    recognized = booked (treat scheduled = expected)
  Object.keys(out).forEach((k) => {
    out[k].recognized =
      method === "prorated_progress"
        ? (out[k].booked * completion) / 100
        : out[k].booked;
  });

  return out;
}

export interface AggregateInput {
  jobs: JobLike[];
  method: RevenueAllocationMethod;
  targetsByMonth: Record<string, number>;
  green: number; // e.g. 95
  amber: number; // e.g. 80
  /** Filter to jobs matching this predicate (e.g. by crew, division). */
  filter?: (j: JobLike) => boolean;
}

export function aggregateMonths(input: AggregateInput): Record<string, RevenuePeriod> {
  const buckets: Record<string, { booked: number; recognized: number }> = {};
  for (const job of input.jobs) {
    if (input.filter && !input.filter(job)) continue;
    const split = allocateJobRevenue(job, input.method);
    for (const [k, v] of Object.entries(split)) {
      if (!buckets[k]) buckets[k] = { booked: 0, recognized: 0 };
      buckets[k].booked += v.booked;
      buckets[k].recognized += v.recognized;
    }
  }

  const keys = new Set([...Object.keys(buckets), ...Object.keys(input.targetsByMonth)]);
  const out: Record<string, RevenuePeriod> = {};
  for (const k of keys) {
    const b = buckets[k] ?? { booked: 0, recognized: 0 };
    const target = input.targetsByMonth[k] ?? 0;
    const forecast = b.booked; // conservative: booked is our forecast
    const achievementPct = target > 0 ? Math.round((forecast / target) * 100) : 0;
    out[k] = {
      monthKey: k,
      target,
      booked: Math.round(b.booked),
      recognized: Math.round(b.recognized),
      forecast: Math.round(forecast),
      remaining: Math.round(target - forecast),
      achievementPct,
      status: trafficLight(achievementPct, input.green, input.amber),
    };
  }
  return out;
}

export function trafficLight(pctVal: number, green: number, amber: number): TrafficLight {
  if (pctVal >= green) return "green";
  if (pctVal >= amber) return "amber";
  return "red";
}

export function trafficLightTone(tl: TrafficLight) {
  switch (tl) {
    case "green": return { chip: "bg-success/15 text-success border-success/30", bar: "bg-success" };
    case "amber": return { chip: "bg-warning/15 text-warning-foreground border-warning/30", bar: "bg-warning" };
    default:      return { chip: "bg-critical/15 text-critical border-critical/30", bar: "bg-critical" };
  }
}

/** Jobs whose contract value has not been scheduled yet (no start_date or status = draft/quoted). */
export function unscheduledRevenue(jobs: JobLike[]): { count: number; value: number } {
  const rows = jobs.filter((j) => !j.start_date || j.status === "not_started" || j.status === "draft");
  return {
    count: rows.length,
    value: Math.round(rows.reduce((s, j) => s + money(j.contract_value), 0)),
  };
}

export function formatMoney(n: number): string {
  if (Math.abs(n) >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (Math.abs(n) >= 1_000) return `$${(n / 1_000).toFixed(0)}k`;
  return `$${Math.round(n).toLocaleString()}`;
}

// ---------- Phase 2.5 — Profitability ----------

export interface ContractorAssignmentLike {
  job_id: string;
  allocated_hours?: number | null;
  hours_worked?: number | null;
  hourly_rate?: number | null;
}

export interface JobProfitability {
  jobId: string;
  contractValue: number;
  contractorCost: number;
  margin: number;
  marginPct: number;
  status: TrafficLight;
}

/** Sum contractor cost for one job. Uses hours_worked when > 0, else allocated_hours. */
export function jobContractorCost(
  jobId: string,
  assignments: ContractorAssignmentLike[],
): number {
  return assignments
    .filter((a) => a.job_id === jobId)
    .reduce((sum, a) => {
      const hrs = Number(a.hours_worked ?? 0) > 0
        ? Number(a.hours_worked)
        : Number(a.allocated_hours ?? 0);
      const rate = Number(a.hourly_rate ?? 0);
      return sum + hrs * rate;
    }, 0);
}

export function computeProfitability(
  job: JobLike,
  assignments: ContractorAssignmentLike[],
  green = 30,   // margin% healthy threshold
  amber = 15,   // margin% caution threshold
): JobProfitability {
  const contractValue = money(job.contract_value);
  const contractorCost = jobContractorCost(job.id, assignments);
  const margin = contractValue - contractorCost;
  const marginPct = contractValue > 0 ? (margin / contractValue) * 100 : 0;
  const status: TrafficLight =
    marginPct >= green ? "green" : marginPct >= amber ? "amber" : "red";
  return {
    jobId: job.id,
    contractValue: Math.round(contractValue),
    contractorCost: Math.round(contractorCost),
    margin: Math.round(margin),
    marginPct: Math.round(marginPct),
    status,
  };
}

