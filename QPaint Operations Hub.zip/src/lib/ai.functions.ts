/**
 * AI Assistant server function — calls Lovable AI Gateway with a
 * **live database snapshot** so answers reference real deals, jobs, crews
 * and schedules instead of stale numbers from the client.
 */
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

const askSchema = z.object({
  question: z.string().min(1).max(2000),
});

function serverSupabase() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Supabase env missing");
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

function startOfWeek(d = new Date()) {
  const x = new Date(d);
  const day = x.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  x.setDate(x.getDate() + diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

async function buildSnapshot() {
  const sb = serverSupabase();
  const today = new Date();
  const weekStart = startOfWeek(today);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);

  const iso = (d: Date) => d.toISOString().slice(0, 10);

  const [
    { data: jobs },
    { data: deals },
    { data: pipelines },
    { data: stages },
    { data: crews },
    { data: staff },
    { data: schedules },
  ] = await Promise.all([
    sb.from("jobs").select("id,job_code,client_name,job_name,status,billing_status,completion_percentage,estimated_hours,hours_worked,start_date,target_finish_date,assigned_crew_id"),
    sb.from("deals").select("id,quote_id,client_name,expected_value,priority,pipeline_id,pipeline_stage_id,appointment_date"),
    sb.from("pipelines").select("id,name,auto_schedule"),
    sb.from("pipeline_stages").select("id,name,pipeline_id,position,is_won"),
    sb.from("crews").select("id,name,weekly_capacity_hours,status"),
    sb.from("staff").select("id,full_name,role,status,crew_id"),
    sb.from("schedules").select("id,job_id,crew_id,scheduled_date,end_date,planned_hours,status").gte("scheduled_date", iso(weekStart)).lt("scheduled_date", iso(weekEnd)),
  ]);

  // capacity per crew this week
  const bookedByCrew: Record<string, number> = {};
  (schedules ?? []).forEach((s) => {
    if (!s.crew_id) return;
    bookedByCrew[s.crew_id] = (bookedByCrew[s.crew_id] ?? 0) + Number(s.planned_hours ?? 0);
  });
  const crewSummary = (crews ?? []).map((c) => {
    const booked = bookedByCrew[c.id] ?? 0;
    const cap = Number(c.weekly_capacity_hours ?? 0);
    const pct = cap > 0 ? Math.round((booked / cap) * 100) : 0;
    return { name: c.name, capacity: cap, booked, utilizationPct: pct, status: c.status };
  });

  // deals by pipeline → stage counts + value
  const stageById = Object.fromEntries((stages ?? []).map((s) => [s.id, s]));
  const pipelineSummary = (pipelines ?? []).map((p) => {
    const ps = (stages ?? []).filter((s) => s.pipeline_id === p.id).sort((a, b) => a.position - b.position);
    const stageRows = ps.map((s) => {
      const ds = (deals ?? []).filter((d) => d.pipeline_stage_id === s.id);
      return {
        stage: s.name,
        count: ds.length,
        value: ds.reduce((sum, d) => sum + Number(d.expected_value ?? 0), 0),
      };
    });
    return { pipeline: p.name, autoSchedule: p.auto_schedule, stages: stageRows };
  });

  const activeJobs = (jobs ?? []).filter((j) => j.status !== "Completed" && j.status !== "Invoiced");
  const readyForInvoice = (jobs ?? []).filter((j) => j.billing_status === "Ready for Invoice");
  const delayed = (jobs ?? []).filter((j) => j.status === "Delayed" || j.status === "On Hold");

  return {
    today: iso(today),
    weekStart: iso(weekStart),
    counts: {
      jobs: jobs?.length ?? 0,
      activeJobs: activeJobs.length,
      delayed: delayed.length,
      readyForInvoice: readyForInvoice.length,
      deals: deals?.length ?? 0,
      crews: crews?.length ?? 0,
      staff: staff?.length ?? 0,
      schedulesThisWeek: schedules?.length ?? 0,
    },
    pipelines: pipelineSummary,
    crewsThisWeek: crewSummary,
    activeJobs: activeJobs.slice(0, 20).map((j) => ({
      code: j.job_code, client: j.client_name, name: j.job_name,
      status: j.status, billing: j.billing_status,
      pct: j.completion_percentage, hours: `${j.hours_worked}/${j.estimated_hours}`,
      start: j.start_date, target: j.target_finish_date,
    })),
    readyForInvoice: readyForInvoice.map((j) => ({ code: j.job_code, client: j.client_name, name: j.job_name })),
    delayed: delayed.map((j) => ({ code: j.job_code, client: j.client_name, status: j.status, pct: j.completion_percentage })),
    topDeals: (deals ?? [])
      .sort((a, b) => Number(b.expected_value ?? 0) - Number(a.expected_value ?? 0))
      .slice(0, 10)
      .map((d) => ({
        quote: d.quote_id, client: d.client_name,
        value: Number(d.expected_value ?? 0), priority: d.priority,
        stage: d.pipeline_stage_id ? stageById[d.pipeline_stage_id]?.name : null,
      })),
  };
}

export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((data: z.infer<typeof askSchema>) => askSchema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) {
      console.error("[ai:ask] LOVABLE_API_KEY missing");
      return { reply: "AI is not configured yet." };
    }

    let snapshot: Awaited<ReturnType<typeof buildSnapshot>> | null = null;
    try {
      snapshot = await buildSnapshot();
    } catch (err) {
      console.error("[ai:ask] snapshot failed", err);
    }

    const sys = [
      "You are the QPaint Operations Assistant for an internal painting-company capacity tool.",
      "Always ground answers in the JSON snapshot below — it is the live database state.",
      "Reference real job codes (e.g. QP-1042), client names, crew names, deal quote IDs, and stage names from the snapshot.",
      "Be concise: 1–4 short paragraphs or a tight bulleted list. Use markdown.",
      "Topics: deals, pipelines, jobs, crews, staff, capacity, progress %, blockers, billing readiness.",
      "If the snapshot doesn't contain the data needed, say so honestly instead of guessing.",
      snapshot ? `\nLIVE SNAPSHOT (JSON):\n${JSON.stringify(snapshot)}` : "\n(Snapshot unavailable.)",
    ].join("\n");

    console.info("[ai:ask]", { qLen: data.question.length, snapshot: !!snapshot });

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: sys },
            { role: "user", content: data.question },
          ],
        }),
      });
      if (!res.ok) {
        const text = await res.text();
        console.error("[ai:ask] gateway", res.status, text);
        if (res.status === 429) return { reply: "Rate limited — try again in a moment." };
        if (res.status === 402) return { reply: "AI credits exhausted. Top up to continue." };
        return { reply: "Assistant is temporarily unavailable." };
      }
      const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const reply = json.choices?.[0]?.message?.content?.trim() || "(no reply)";
      return { reply };
    } catch (err) {
      console.error("[ai:ask] exception", err);
      return { reply: "Assistant call failed — check server logs." };
    }
  });
