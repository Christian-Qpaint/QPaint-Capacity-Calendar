import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, CheckCircle2, Gauge } from "lucide-react";
import {
  calculateDailyCapacity,
  capacityTone,
  type CapacityStatus,
  type DailyCapacityInput,
} from "@/lib/capacity";
import { cn } from "@/lib/utils";

interface Props extends DailyCapacityInput {
  /** Show numbers ("booked / available · util%"). */
  showLabels?: boolean;
  /** Compact bar height ("h-1.5" by default). */
  size?: "sm" | "md";
  className?: string;
}

/**
 * Reusable capacity indicator: progress bar + status badge.
 * Pulls all logic from `src/lib/capacity.ts`.
 */
export function CapacityIndicator({
  showLabels = true,
  size = "sm",
  className,
  ...input
}: Props) {
  const cap = calculateDailyCapacity(input);
  const tone = capacityTone(cap.status);
  const pct = Math.min(100, cap.utilizationPct);

  return (
    <div className={cn("space-y-1", className)}>
      {showLabels && (
        <div className="flex items-center justify-between text-xs">
          <span className="tabular-nums text-muted-foreground">
            {cap.bookedHours}h / {cap.availableHours}h
          </span>
          <CapacityBadge status={cap.status} utilization={cap.utilizationPct} />
        </div>
      )}
      <div className="relative">
        <Progress value={pct} className={size === "md" ? "h-2" : "h-1.5"} />
        <div
          className={cn(
            "absolute inset-y-0 left-0 rounded-full",
            tone.bar,
            size === "md" ? "h-2" : "h-1.5",
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function CapacityBadge({
  status,
  utilization,
}: {
  status: CapacityStatus;
  utilization?: number;
}) {
  const tone = capacityTone(status);
  const Icon =
    status === "Overbooked" ? AlertTriangle : status === "Available" ? CheckCircle2 : Gauge;
  return (
    <Badge variant="outline" className={cn("gap-1 text-[10px]", tone.chip)}>
      <Icon className="h-3 w-3" />
      {status}
      {typeof utilization === "number" && (
        <span className="tabular-nums">· {utilization}%</span>
      )}
    </Badge>
  );
}
