import { useState, type ReactNode } from "react";
import { useForm, type UseFormReturn, type FieldValues, type DefaultValues, type Path } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";

import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

/* ---------------- shared option lists (mock) ---------------- */

export const CREWS = ["Crew Alpha", "Crew Bravo", "Crew Charlie", "Crew Delta", "Crew Echo"];
export const SUPERVISORS = ["Ava Henderson", "Marcus Lee", "Priya Shah", "Jordan Reyes", "Sam Okafor"];
export const JOBS_LIST = [
  "QP-1042 · Marina Heights Repaint",
  "QP-1043 · Cafe Lumen Interior",
  "QP-1044 · Northside Medical Fitout",
  "QP-1045 · Wattle Primary School",
  "QP-1047 · Riverside Dental Repaint",
];
export const STAFF_LIST = [
  "Ava Henderson", "Marcus Lee", "Priya Shah", "Jordan Reyes",
  "Sam Okafor", "Lena Wong", "Diego Alvarez", "Noah Smith",
];
export const CREW_TYPES = ["Residential", "Commercial", "Industrial", "Specialty", "Touch-up"];
export const STAFF_ROLES = ["Painter", "Crew Leader", "Apprentice", "Supervisor", "Contractor"];
export const BLOCKER_TYPES = ["None", "Weather", "Materials delay", "Client access", "Scope change", "Safety", "Other"];
export const LEAVE_REASONS = ["Annual leave", "Sick", "Public holiday", "Training", "Personal", "Unpaid"];
export const MILESTONES = ["Prep complete", "Primer applied", "First coat", "Second coat", "Detail/cut-in", "Final clean", "Handover"];

/* ---------------- small field helpers ---------------- */

function Field({
  label, error, required, children, hint,
}: { label: string; error?: string; required?: boolean; hint?: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label} {required && <span className="text-critical">*</span>}
      </Label>
      {children}
      {hint && !error && <p className="text-[11px] text-muted-foreground">{hint}</p>}
      {error && <p className="text-[11px] text-critical">{error}</p>}
    </div>
  );
}

function SelectField<T extends FieldValues>({
  form, name, options, placeholder,
}: { form: UseFormReturn<T>; name: Path<T>; options: readonly string[]; placeholder?: string }) {
  const value = form.watch(name) as unknown as string | undefined;
  return (
    <Select value={value ?? ""} onValueChange={(v) => form.setValue(name, v as never, { shouldValidate: true })}>
      <SelectTrigger className="h-9"><SelectValue placeholder={placeholder ?? "Select…"} /></SelectTrigger>
      <SelectContent>{options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
    </Select>
  );
}

/* ---------------- generic modal shell ---------------- */

interface ShellProps<T extends FieldValues> {
  trigger: ReactNode;
  title: string;
  description?: string;
  submitLabel?: string;
  form: UseFormReturn<T>;
  /** Optional async persistence handler. If it throws, the modal stays open and shows an error toast. */
  onSave?: (values: T) => Promise<void> | void;
  children: (form: UseFormReturn<T>) => ReactNode;
  size?: "md" | "lg";
}

function ModalShell<T extends FieldValues>({
  trigger, title, description, submitLabel = "Save", form, onSave, children, size = "md",
}: ShellProps<T>) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const handle = form.handleSubmit(async (values) => {
    setSaving(true);
    try {
      if (onSave) await onSave(values);
      toast.success(`${title} saved`);
      form.reset();
      setOpen(false);
    } catch (err) {
      console.error(`[modal:${title}] save failed`, err);
      toast.error((err as Error)?.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  });

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) form.reset(); }}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className={size === "lg" ? "sm:max-w-2xl" : "sm:max-w-lg"}>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <form onSubmit={handle} className="space-y-4 pt-1">
          {children(form)}
          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancel</Button>
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : submitLabel}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function useZodForm<S extends z.ZodTypeAny>(schema: S, defaults: DefaultValues<z.infer<S>>) {
  return useForm<z.infer<S>>({
    resolver: zodResolver(schema),
    defaultValues: defaults,
    mode: "onTouched",
  });
}

/* ====================================================================
   1. Add New Job
==================================================================== */

const jobSchema = z.object({
  clientName: z.string().trim().min(1, "Client name required").max(120),
  jobName: z.string().trim().min(1, "Job name required").max(120),
  location: z.string().trim().min(1, "Location required").max(200),
  contact: z.string().trim().min(1, "Contact required").max(120),
  startDate: z.string().min(1, "Start date required"),
  targetFinishDate: z.string().min(1, "Target finish required"),
  estimatedHours: z.coerce.number().min(1, "Must be > 0").max(10000),
  assignedCrew: z.string().min(1, "Crew required"),
  supervisor: z.string().min(1, "Supervisor required"),
  notes: z.string().max(1000).optional(),
}).refine(v => new Date(v.targetFinishDate) >= new Date(v.startDate), {
  path: ["targetFinishDate"], message: "Finish must be on or after start",
});

export function AddJobModal({ trigger, onSave }: { trigger: ReactNode; onSave?: (v: any) => Promise<void> | void }) {
  const form = useZodForm(jobSchema, {
    clientName: "", jobName: "", location: "", contact: "",
    startDate: "", targetFinishDate: "", estimatedHours: 0,
    assignedCrew: "", supervisor: "", notes: "",
  });
  const e = form.formState.errors;
  return (
    <ModalShell onSave={onSave} trigger={trigger} title="Add new job" description="Create a new painting project."
      submitLabel="Create job" form={form} size="lg">
      {(f) => (
        <>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Client name" required error={e.clientName?.message}>
              <Input {...f.register("clientName")} placeholder="e.g. Marina Heights HOA" />
            </Field>
            <Field label="Job name" required error={e.jobName?.message}>
              <Input {...f.register("jobName")} placeholder="e.g. Lobby repaint" />
            </Field>
            <Field label="Location" required error={e.location?.message}>
              <Input {...f.register("location")} placeholder="Street, suburb" />
            </Field>
            <Field label="Client contact" required error={e.contact?.message}>
              <Input {...f.register("contact")} placeholder="Name · phone or email" />
            </Field>
            <Field label="Start date" required error={e.startDate?.message}>
              <Input type="date" {...f.register("startDate")} />
            </Field>
            <Field label="Target finish date" required error={e.targetFinishDate?.message}>
              <Input type="date" {...f.register("targetFinishDate")} />
            </Field>
            <Field label="Estimated hours" required error={e.estimatedHours?.message}>
              <Input type="number" min={1} step={1} {...f.register("estimatedHours")} />
            </Field>
            <Field label="Assigned crew" required error={e.assignedCrew?.message}>
              <SelectField form={f} name="assignedCrew" options={CREWS} />
            </Field>
            <Field label="Supervisor" required error={e.supervisor?.message}>
              <SelectField form={f} name="supervisor" options={SUPERVISORS} />
            </Field>
          </div>
          <Field label="Notes">
            <Textarea rows={3} {...f.register("notes")} placeholder="Scope notes, access info, special requirements…" />
          </Field>
        </>
      )}
    </ModalShell>
  );
}

/* ====================================================================
   2. Update Job Progress
==================================================================== */

const progressSchema = z.object({
  job: z.string().min(1, "Job required"),
  completion: z.coerce.number().min(0).max(100),
  hoursWorked: z.coerce.number().min(0).max(24, "Max 24 per day"),
  milestone: z.string().optional(),
  blocker: z.string().optional(),
  notes: z.string().max(1000).optional(),
  readyForReview: z.boolean().optional(),
});

export function UpdateProgressModal({ trigger, defaultJob, onSave }: { trigger: ReactNode; defaultJob?: string; onSave?: (v: any) => Promise<void> | void }) {
  const form = useZodForm(progressSchema, {
    job: defaultJob ?? "", completion: 0, hoursWorked: 0,
    milestone: "", blocker: "None", notes: "", readyForReview: false,
  });
  const e = form.formState.errors;
  return (
    <ModalShell onSave={onSave} trigger={trigger} title="Update job progress" description="Log today's progress against a job."
      submitLabel="Log update" form={form} size="lg">
      {(f) => (
        <>
          <Field label="Job" required error={e.job?.message}>
            <SelectField form={f} name="job" options={JOBS_LIST} />
          </Field>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="New completion %" required error={e.completion?.message}>
              <Input type="number" min={0} max={100} step={1} {...f.register("completion")} />
            </Field>
            <Field label="Hours worked today" required error={e.hoursWorked?.message}>
              <Input type="number" min={0} max={24} step={0.5} {...f.register("hoursWorked")} />
            </Field>
            <Field label="Milestone completed">
              <SelectField form={f} name="milestone" options={MILESTONES} placeholder="None" />
            </Field>
            <Field label="Blocker type">
              <SelectField form={f} name="blocker" options={BLOCKER_TYPES} />
            </Field>
          </div>
          <Field label="Notes">
            <Textarea rows={3} {...f.register("notes")} placeholder="What was done, issues encountered…" />
          </Field>
          <label className="flex items-center gap-2 text-sm">
            <Checkbox
              checked={Boolean(f.watch("readyForReview"))}
              onCheckedChange={(c) => f.setValue("readyForReview", Boolean(c))}
            />
            Ready for admin review
          </label>
        </>
      )}
    </ModalShell>
  );
}

/* ====================================================================
   3. Add Crew
==================================================================== */

const crewSchema = z.object({
  name: z.string().trim().min(1, "Crew name required").max(80),
  leader: z.string().min(1, "Leader required"),
  type: z.string().min(1, "Type required"),
  weeklyCapacity: z.coerce.number().min(1, "Must be > 0").max(1000),
  skills: z.string().max(300).optional(),
  notes: z.string().max(500).optional(),
});

export function AddCrewModal({ trigger, onSave }: { trigger: ReactNode; onSave?: (v: any) => Promise<void> | void }) {
  const form = useZodForm(crewSchema, {
    name: "", leader: "", type: "", weeklyCapacity: 160, skills: "", notes: "",
  });
  const e = form.formState.errors;
  return (
    <ModalShell onSave={onSave} trigger={trigger} title="Add crew" description="Create a new crew profile."
      submitLabel="Create crew" form={form}>
      {(f) => (
        <>
          <Field label="Crew name" required error={e.name?.message}>
            <Input {...f.register("name")} placeholder="e.g. Crew Foxtrot" />
          </Field>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Crew leader" required error={e.leader?.message}>
              <SelectField form={f} name="leader" options={STAFF_LIST} />
            </Field>
            <Field label="Crew type" required error={e.type?.message}>
              <SelectField form={f} name="type" options={CREW_TYPES} />
            </Field>
            <Field label="Weekly capacity (hrs)" required error={e.weeklyCapacity?.message}>
              <Input type="number" min={1} step={1} {...f.register("weeklyCapacity")} />
            </Field>
          </div>
          <Field label="Skills" hint="Comma-separated">
            <Input {...f.register("skills")} placeholder="Exterior, Heritage, Spray finish" />
          </Field>
          <Field label="Notes">
            <Textarea rows={2} {...f.register("notes")} />
          </Field>
        </>
      )}
    </ModalShell>
  );
}

/* ====================================================================
   4. Add Staff Member
==================================================================== */

const staffSchema = z.object({
  fullName: z.string().trim().min(1, "Name required").max(120),
  role: z.string().min(1, "Role required"),
  crew: z.string().min(1, "Crew required"),
  skills: z.string().max(300).optional(),
  weeklyHours: z.coerce.number().min(1, "Must be > 0").max(80),
  phone: z.string().trim().min(1, "Contact required").max(40),
  email: z.string().trim().email("Invalid email").max(120),
});

export function AddStaffModal({ trigger, onSave }: { trigger: ReactNode; onSave?: (v: any) => Promise<void> | void }) {
  const form = useZodForm(staffSchema, {
    fullName: "", role: "", crew: "", skills: "", weeklyHours: 38, phone: "", email: "",
  });
  const e = form.formState.errors;
  return (
    <ModalShell onSave={onSave} trigger={trigger} title="Add staff member" description="Register a new painter or supervisor."
      submitLabel="Add staff" form={form} size="lg">
      {(f) => (
        <>
          <Field label="Full name" required error={e.fullName?.message}>
            <Input {...f.register("fullName")} placeholder="First Last" />
          </Field>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Role" required error={e.role?.message}>
              <SelectField form={f} name="role" options={STAFF_ROLES} />
            </Field>
            <Field label="Crew" required error={e.crew?.message}>
              <SelectField form={f} name="crew" options={CREWS} />
            </Field>
            <Field label="Normal hours / week" required error={e.weeklyHours?.message}>
              <Input type="number" min={1} max={80} step={1} {...f.register("weeklyHours")} />
            </Field>
            <Field label="Phone" required error={e.phone?.message}>
              <Input {...f.register("phone")} placeholder="04xx xxx xxx" />
            </Field>
          </div>
          <Field label="Email" required error={e.email?.message}>
            <Input type="email" {...f.register("email")} placeholder="name@qpaint.com" />
          </Field>
          <Field label="Skills" hint="Comma-separated">
            <Input {...f.register("skills")} placeholder="Interior, Spray, Heritage" />
          </Field>
        </>
      )}
    </ModalShell>
  );
}

/* ====================================================================
   5. Add Leave / Absence
==================================================================== */

const leaveSchema = z.object({
  staff: z.string().min(1, "Staff required"),
  startDate: z.string().min(1, "Start required"),
  endDate: z.string().min(1, "End required"),
  reason: z.string().min(1, "Reason required"),
  hoursImpact: z.coerce.number().min(0).max(200),
  notes: z.string().max(500).optional(),
}).refine(v => new Date(v.endDate) >= new Date(v.startDate), {
  path: ["endDate"], message: "End must be on or after start",
});

export function AddLeaveModal({ trigger, defaultStaff, onSave }: { trigger: ReactNode; defaultStaff?: string; onSave?: (v: any) => Promise<void> | void }) {
  const form = useZodForm(leaveSchema, {
    staff: defaultStaff ?? "", startDate: "", endDate: "",
    reason: "", hoursImpact: 8, notes: "",
  });
  const e = form.formState.errors;
  return (
    <ModalShell onSave={onSave} trigger={trigger} title="Add leave / absence" description="Record planned or unplanned time off."
      submitLabel="Save leave" form={form}>
      {(f) => (
        <>
          <Field label="Staff member" required error={e.staff?.message}>
            <SelectField form={f} name="staff" options={STAFF_LIST} />
          </Field>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Start date" required error={e.startDate?.message}>
              <Input type="date" {...f.register("startDate")} />
            </Field>
            <Field label="End date" required error={e.endDate?.message}>
              <Input type="date" {...f.register("endDate")} />
            </Field>
            <Field label="Reason" required error={e.reason?.message}>
              <SelectField form={f} name="reason" options={LEAVE_REASONS} />
            </Field>
            <Field label="Available hours impact" required error={e.hoursImpact?.message}
              hint="Hours removed from capacity per day">
              <Input type="number" min={0} max={200} step={0.5} {...f.register("hoursImpact")} />
            </Field>
          </div>
          <Field label="Notes">
            <Textarea rows={2} {...f.register("notes")} />
          </Field>
        </>
      )}
    </ModalShell>
  );
}

/* ====================================================================
   6. Add Schedule Item
==================================================================== */

export type JobOption = { value: string; label: string; estimatedHours?: number | null };

const scheduleSchema = z.object({
  job: z.string().min(1, "Job required"),
  crew: z.string().min(1, "Crew required"),
  startDate: z.string().min(1, "Start date required"),
  endDate: z.string().min(1, "End date required"),
  startTime: z.string().min(1, "Start time required"),
  endTime: z.string().min(1, "End time required"),
  plannedHours: z.coerce.number().min(0.5, "Must be > 0").max(10000),
  notes: z.string().max(500).optional(),
}).refine(v => new Date(v.endDate) >= new Date(v.startDate), {
  path: ["endDate"], message: "End date must be on or after start date",
}).refine(v => v.endDate !== v.startDate || v.endTime > v.startTime, {
  path: ["endTime"], message: "End time must be after start time",
});

export function AddScheduleModal({
  trigger, defaultDate, jobOptions, crewOptions, onSave,
}: {
  trigger: ReactNode;
  defaultDate?: string;
  jobOptions?: JobOption[];
  crewOptions?: string[];
  onSave?: (v: any) => Promise<void> | void;
}) {
  const form = useZodForm(scheduleSchema, {
    job: "", crew: "",
    startDate: defaultDate ?? "", endDate: defaultDate ?? "",
    startTime: "07:30", endTime: "15:30", plannedHours: 8, notes: "",
  });
  const e = form.formState.errors;

  const jobs = jobOptions ?? JOBS_LIST.map((s) => ({ value: s, label: s, estimatedHours: undefined }));
  const crews = crewOptions ?? Array.from(CREWS);
  const jobsEmpty = jobs.length === 0;

  return (
    <ModalShell onSave={onSave} trigger={trigger} title="Add schedule item"
      description="Allocate a crew to a job across a date range."
      submitLabel="Add to schedule" form={form} size="lg">
      {(f) => {
        const jobValue = (f.watch("job") as string) ?? "";
        return (
          <>
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label="Job" required error={e.job?.message}
                hint={jobsEmpty ? "No jobs in the CRM Jobs Pipeline yet." : undefined}>
                <Select
                  value={jobValue}
                  onValueChange={(v) => {
                    f.setValue("job", v as never, { shouldValidate: true });
                    const opt = jobs.find((j) => j.value === v);
                    if (opt?.estimatedHours && opt.estimatedHours > 0) {
                      f.setValue("plannedHours", opt.estimatedHours as never, { shouldValidate: true });
                    }
                  }}
                  disabled={jobsEmpty}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder={jobsEmpty ? "No jobs available" : "Select job…"} />
                  </SelectTrigger>
                  <SelectContent>
                    {jobs.map((j) => (
                      <SelectItem key={j.value} value={j.value}>{j.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Crew" required error={e.crew?.message}>
                <SelectField form={f} name="crew" options={crews} />
              </Field>
              <Field label="Start date" required error={e.startDate?.message}>
                <Input type="date" {...f.register("startDate")} />
              </Field>
              <Field label="End date" required error={e.endDate?.message}>
                <Input type="date" {...f.register("endDate")} />
              </Field>
              <Field label="Start time" required error={e.startTime?.message}>
                <Input type="time" {...f.register("startTime")} />
              </Field>
              <Field label="End time" required error={e.endTime?.message}>
                <Input type="time" {...f.register("endTime")} />
              </Field>
              <Field label="Planned hours" required error={e.plannedHours?.message}
                hint="Auto-filled from the job's quoted hours — override if needed.">
                <Input type="number" min={0.5} step={0.5} {...f.register("plannedHours")} />
              </Field>
            </div>
            <Field label="Notes">
              <Textarea rows={2} {...f.register("notes")} placeholder="Access details, prep notes…" />
            </Field>
          </>
        );
      }}
    </ModalShell>
  );
}
