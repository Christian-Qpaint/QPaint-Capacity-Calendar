import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  LayoutDashboard,
  Briefcase,
  CalendarDays,
  Users,
  UserCog,
  BarChart3,
  Sparkles,
  Settings,
  PaintRoller,
  LogIn,
  LogOut,
  Target,
  Contact,
  HardHat,
  ClipboardList,


} from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { log } from "@/lib/log";
import { toast } from "sonner";
import { useMyRoles, type AppRole } from "@/lib/roles";

type NavItem = {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  exact?: boolean;
  group: "Operations" | "Sales" | "People" | "Insights" | "Setup";
  allow?: AppRole[]; // omitted = visible to everyone signed in
};

const nav: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, exact: true, group: "Operations" },
  { to: "/my-assignments", label: "My Assignments", icon: ClipboardList, group: "Operations", allow: ["contractor"] },

  { to: "/jobs", label: "Jobs", icon: Briefcase, group: "Operations", allow: ["owner", "ops_manager", "crew_leader"] },
  { to: "/capacity", label: "Capacity Calendar", icon: CalendarDays, group: "Operations", allow: ["owner", "ops_manager", "crew_leader"] },
  { to: "/crm", label: "CRM / Sales Pipeline", icon: Target, group: "Sales", allow: ["owner", "ops_manager"] },
  { to: "/contacts", label: "Contacts", icon: Contact, group: "Sales", allow: ["owner", "ops_manager"] },
  { to: "/crews", label: "Crews", icon: Users, group: "People", allow: ["owner", "ops_manager"] },
  { to: "/staff", label: "Staff", icon: UserCog, group: "People", allow: ["owner", "ops_manager"] },
  { to: "/contractors", label: "Contractors", icon: HardHat, group: "People", allow: ["owner", "ops_manager"] },
  { to: "/reports", label: "Reports", icon: BarChart3, group: "Insights", allow: ["owner", "ops_manager"] },
  { to: "/ai-assistant", label: "AI Assistant", icon: Sparkles, group: "Insights", allow: ["owner", "ops_manager", "crew_leader"] },
  { to: "/settings", label: "Settings", icon: Settings, group: "Setup" }, // always visible so users can self-assign role
];

const GROUPS: Array<"Operations" | "Sales" | "People" | "Insights" | "Setup"> = ["Operations", "Sales", "People", "Insights", "Setup"];

interface Props {
  variant?: "fixed" | "drawer";
  onNavigate?: () => void;
  collapsed?: boolean;
  onToggleCollapsed?: () => void;
}

export function AppSidebar({ variant = "fixed", onNavigate, collapsed = false }: Props) {
  const isCollapsed = variant === "fixed" && collapsed;
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const router = useRouter();
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const { data: myRoles } = useMyRoles();
  const roleSet = new Set<AppRole>(myRoles ?? []);
  const hasAnyRole = roleSet.size > 0;
  const canSee = (item: NavItem) => {
    if (!item.allow) return true;
    if (!hasAnyRole) return true; // pre-bootstrap: show everything
    return item.allow.some((r) => roleSet.has(r));
  };

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (mounted) setUserEmail(data.user?.email ?? null);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") {
        setUserEmail(session?.user?.email ?? null);
      }
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  async function handleSignOut() {
    log.info("auth:signout");
    await supabase.auth.signOut();
    toast.success("Signed out");
    router.navigate({ to: "/auth" });
  }

  const Shell = ({ children }: { children: React.ReactNode }) =>
    variant === "drawer" ? (
      <div className="flex h-full w-full flex-col">{children}</div>
    ) : (
      <aside className={cn(
        "hidden md:flex shrink-0 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border transition-[width] duration-200",
        isCollapsed ? "md:w-16" : "md:w-64",
      )}>
        {children}
      </aside>
    );

  return (
    <Shell>
      <div className={cn("flex items-center gap-2.5 h-16 border-b border-sidebar-border", isCollapsed ? "px-3 justify-center" : "px-5")}>
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-accent text-accent-foreground shadow-sm">
          <PaintRoller className="h-5 w-5" />
        </div>
        {!isCollapsed && (
          <div className="leading-tight">
            <div className="font-display font-bold tracking-tight text-[15px]">QPaint</div>
            <div className="text-[11px] text-sidebar-foreground/60 -mt-0.5">Capacity OS</div>
          </div>
        )}
      </div>

      <nav className={cn("flex-1 overflow-y-auto py-4 space-y-5", isCollapsed ? "px-2" : "px-3")}>
        {GROUPS.map((group) => {
          const items = nav.filter((i) => i.group === group && canSee(i));
          if (items.length === 0) return null;
          return (
            <div key={group} className="space-y-1">
              {!isCollapsed && (
                <div className="px-3 text-[10px] font-semibold uppercase tracking-[0.12em] text-sidebar-foreground/40">
                  {group}
                </div>
              )}
              {items.map((item) => {
                const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
                const Icon = item.icon;
                return (
                  <Link
                    key={item.to}
                    to={item.to as never}
                    onClick={onNavigate}
                    title={isCollapsed ? item.label : undefined}
                    className={cn(
                      "group relative flex items-center rounded-lg text-sm font-medium transition-colors",
                      isCollapsed ? "justify-center px-2 py-2" : "gap-3 px-3 py-2",
                      active
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
                    )}
                  >
                    <span
                      className={cn(
                        "absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-r bg-accent transition-opacity",
                        active ? "opacity-100" : "opacity-0 group-hover:opacity-40",
                      )}
                    />
                    <Icon
                      className={cn(
                        "h-4 w-4 shrink-0 transition-colors",
                        active ? "text-accent" : "text-sidebar-foreground/60 group-hover:text-sidebar-foreground",
                      )}
                    />
                    {!isCollapsed && <span className="truncate">{item.label}</span>}
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>


      <div className={cn("border-t border-sidebar-border text-[11px] text-sidebar-foreground/70 space-y-2", isCollapsed ? "p-2" : "p-3")}>
        {isCollapsed ? (
          userEmail ? (
            <button
              onClick={handleSignOut}
              className="flex w-full items-center justify-center rounded-md p-2 hover:bg-sidebar-accent/60"
              aria-label="Sign out"
              title={`Sign out (${userEmail})`}
            >
              <LogOut className="h-4 w-4" />
            </button>
          ) : (
            <Link
              to="/auth"
              onClick={onNavigate}
              className="flex w-full items-center justify-center rounded-md p-2 hover:bg-sidebar-accent/60"
              title="Sign in"
            >
              <LogIn className="h-4 w-4" />
            </Link>
          )
        ) : (
          <>
            {userEmail ? (
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-medium text-sidebar-foreground truncate">{userEmail}</div>
                  <div className="text-[10px] text-sidebar-foreground/50">Signed in</div>
                </div>
                <button
                  onClick={handleSignOut}
                  className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] hover:bg-sidebar-accent/60"
                  aria-label="Sign out"
                >
                  <LogOut className="h-3.5 w-3.5" /> Sign out
                </button>
              </div>
            ) : (
              <Link
                to="/auth"
                onClick={onNavigate}
                className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-sidebar-accent/60"
              >
                <LogIn className="h-4 w-4" />
                <span>Sign in</span>
              </Link>
            )}
            <div className="flex items-center justify-between pt-1 border-t border-sidebar-border/60 text-sidebar-foreground/55">
              <span>QPaint Ops · v0.1</span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
                Live
              </span>
            </div>
          </>
        )}
      </div>

    </Shell>
  );
}
