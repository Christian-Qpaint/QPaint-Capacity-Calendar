import { Bell, Menu, Search, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useMyRoles, pickPrimaryRole, ROLE_LABELS } from "@/lib/roles";

interface Props {
  title?: string;
  onMenuClick?: () => void;
  onToggleSidebar?: () => void;
  sidebarCollapsed?: boolean;
}

function initialsFrom(source: string): string {
  const clean = source.trim();
  if (!clean) return "?";
  const parts = clean.split(/[\s._-]+/).filter(Boolean);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return clean.slice(0, 2).toUpperCase();
}

export function AppHeader({ title, onMenuClick, onToggleSidebar, sidebarCollapsed }: Props) {
  const [email, setEmail] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState<string | null>(null);
  const { data: roles } = useMyRoles();

  useEffect(() => {
    let mounted = true;
    const apply = (user: { email?: string | null; user_metadata?: Record<string, unknown> } | null) => {
      if (!mounted) return;
      setEmail(user?.email ?? null);
      const meta = user?.user_metadata as { full_name?: string; name?: string } | undefined;
      setDisplayName(meta?.full_name ?? meta?.name ?? null);
    };
    supabase.auth.getUser().then(({ data }) => apply(data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => apply(session?.user ?? null));
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const name = displayName ?? (email ? email.split("@")[0] : "Guest");
  const roleLabel = roles && roles.length > 0 ? ROLE_LABELS[pickPrimaryRole(roles)] : email ? "Signed in" : "Not signed in";
  const initials = initialsFrom(displayName ?? email ?? "G");

  return (
    <header className="sticky top-0 z-20 h-16 bg-card/90 backdrop-blur border-b border-border flex items-center gap-3 px-4 sm:px-6">
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden -ml-1"
        aria-label="Open menu"
        onClick={onMenuClick}
      >
        <Menu className="h-5 w-5" />
      </Button>

      {onToggleSidebar && (
        <Button
          variant="ghost"
          size="icon"
          className="hidden md:inline-flex -ml-1"
          aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          onClick={onToggleSidebar}
        >
          {sidebarCollapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
        </Button>
      )}

      <div className="min-w-0 flex-1">
        <h1 className="text-base sm:text-[17px] font-display font-semibold tracking-tight truncate">
          {title ?? "QPaint"}
        </h1>
        <p className="text-[11px] sm:text-xs text-muted-foreground truncate -mt-0.5">
          Capacity Management System
        </p>
      </div>

      <div className="relative hidden lg:block w-72">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search jobs, crews, staff…" className="pl-9 h-9" />
      </div>

      <Button variant="ghost" size="icon" aria-label="Notifications" className="relative">
        <Bell className="h-4 w-4" />
        <span className="absolute top-2 right-2 h-1.5 w-1.5 rounded-full bg-accent ring-2 ring-card" />
      </Button>

      <div className="flex items-center gap-3 pl-3 border-l border-border">
        <div className="text-right hidden sm:block leading-tight max-w-[180px]">
          <div className="text-sm font-medium truncate">{name}</div>
          <div className="text-[11px] text-muted-foreground -mt-0.5 truncate">{roleLabel}</div>
        </div>
        <div className="h-9 w-9 rounded-full bg-primary text-primary-foreground grid place-items-center text-sm font-semibold ring-2 ring-background shadow-sm">
          {initials}
        </div>
      </div>

    </header>
  );
}
