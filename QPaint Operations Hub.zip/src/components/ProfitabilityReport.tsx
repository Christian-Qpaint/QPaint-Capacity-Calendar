import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { jobsQuery, allContractorAssignmentsQuery } from "@/lib/db";
import {
  computeProfitability, formatMoney, trafficLightTone,
} from "@/lib/revenue";
import { DollarSign, TrendingUp, TrendingDown, ExternalLink } from "lucide-react";

export function ProfitabilityReport() {
  const { data: jobs = [] } = useQuery(jobsQuery);
  const { data: assignments = [] } = useQuery(allContractorAssignmentsQuery);

  const rows = useMemo(() => {
    return jobs
      .filter((j) => Number(j.contract_value ?? 0) > 0)
      .map((j) => ({
        job: j,
        p: computeProfitability(j, assignments),
      }))
      .sort((a, b) => b.p.contractValue - a.p.contractValue);
  }, [jobs, assignments]);

  const totals = rows.reduce(
    (acc, r) => {
      acc.value += r.p.contractValue;
      acc.cost += r.p.contractorCost;
      acc.margin += r.p.margin;
      return acc;
    },
    { value: 0, cost: 0, margin: 0 },
  );
  const totalMarginPct = totals.value > 0 ? Math.round((totals.margin / totals.value) * 100) : 0;

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-primary" />
            Profitability report
          </CardTitle>
          <p className="mt-1 text-xs text-muted-foreground">
            Contract value minus contractor cost (allocated or worked hours × rate).
            Green ≥ 30% margin · Amber ≥ 15% · Red below.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="outline" className="gap-1.5 text-xs">
            <span className="opacity-70">Booked</span>
            <span className="font-semibold tabular-nums">{formatMoney(totals.value)}</span>
          </Badge>
          <Badge variant="outline" className="gap-1.5 text-xs">
            <span className="opacity-70">Contractor cost</span>
            <span className="font-semibold tabular-nums">{formatMoney(totals.cost)}</span>
          </Badge>
          <Badge
            variant="outline"
            className={`gap-1.5 text-xs ${
              totalMarginPct >= 30
                ? "border-success/40 text-success"
                : totalMarginPct >= 15
                ? "border-warning/40 text-warning-foreground"
                : "border-critical/40 text-critical"
            }`}
          >
            {totalMarginPct >= 15 ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            <span className="font-semibold tabular-nums">
              {formatMoney(totals.margin)} · {totalMarginPct}%
            </span>
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {rows.length === 0 ? (
          <div className="rounded-md border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            No jobs with a contract value yet. Set a contract value on a job to see profitability.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job</TableHead>
                <TableHead>Client</TableHead>
                <TableHead className="text-right">Contract</TableHead>
                <TableHead className="text-right">Contractor cost</TableHead>
                <TableHead className="text-right">Margin</TableHead>
                <TableHead className="text-right">Margin %</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map(({ job, p }) => {
                const tone = trafficLightTone(p.status);
                return (
                  <TableRow key={job.id}>
                    <TableCell>
                      <div className="font-medium">{job.job_name}</div>
                      <div className="font-mono text-xs text-muted-foreground">{job.job_code}</div>
                    </TableCell>
                    <TableCell className="text-sm">{job.client_name}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatMoney(p.contractValue)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {formatMoney(p.contractorCost)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums font-medium">
                      {formatMoney(p.margin)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="outline" className={`text-xs ${tone.chip}`}>
                        {p.marginPct}%
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button asChild size="sm" variant="ghost">
                        <Link to="/jobs/$jobId" params={{ jobId: job.id }}>
                          Open <ExternalLink className="ml-1 h-3 w-3" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
