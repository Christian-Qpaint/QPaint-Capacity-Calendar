import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import {
  syncPdMeta,
  syncPdContactsChunk,
  syncPdDealsChunk,
  syncPdFinalize,
} from "@/lib/pipedrive-sync.functions";

type Mode = "deals" | "contacts";

/**
 * Pipedrive sync trigger. `mode="deals"` syncs pipelines/stages + deals only.
 * `mode="contacts"` syncs contacts only. Two buttons so admins can refresh
 * one side without waiting on the other.
 */
export function PipedriveSyncButton({
  mode,
  onDone,
  label,
}: {
  mode: Mode;
  onDone: () => void;
  label?: string;
}) {
  const runMeta = useServerFn(syncPdMeta);
  const runContacts = useServerFn(syncPdContactsChunk);
  const runDeals = useServerFn(syncPdDealsChunk);
  const runFinalize = useServerFn(syncPdFinalize);

  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState("");
  const [lastRun, setLastRun] = useState<number | null>(null);

  useEffect(() => {
    supabase
      .from("sync_state")
      .select("last_run_at")
      .eq("source", "pipedrive")
      .maybeSingle()
      .then(({ data }) => {
        if (data?.last_run_at) setLastRun(new Date(data.last_run_at).getTime());
      });
  }, []);

  async function doSync() {
    if (busy) return;
    setBusy(true);
    setProgress(3);
    const totals = { pipelines: 0, stages: 0, contacts: 0, deals: 0 };
    try {
      if (mode === "deals") {
        setPhase("Pipelines…");
        const meta = await runMeta();
        totals.pipelines = meta.pipelines;
        totals.stages = meta.stages;
        onDone();
        setProgress(20);

        let start: number | null = 0;
        let seen = 0;
        const est = Math.max(meta.dealsHint, 1);
        setPhase("Deals…");
        while (start !== null) {
          const r = await runDeals({ data: { start } });
          seen += r.processed;
          totals.deals = seen;
          const frac = r.done ? 1 : Math.min(0.95, seen / (est * 2));
          setProgress(20 + Math.round(frac * 75));
          setPhase(`Deals · ${seen}`);
          onDone();
          start = r.nextStart;
        }
      } else {
        // contacts mode — also refresh pipeline meta cheaply so we get the
        // dealsHint for progress and any newly added pipelines.
        setPhase("Preparing…");
        await runMeta();
        setProgress(15);

        let start: number | null = 0;
        let seen = 0;
        setPhase("Contacts…");
        while (start !== null) {
          const r = await runContacts({ data: { start } });
          seen += r.processed;
          totals.contacts = seen;
          const frac = r.done ? 1 : Math.min(0.95, seen / 500);
          setProgress(15 + Math.round(frac * 80));
          setPhase(`Contacts · ${seen}`);
          onDone();
          start = r.nextStart;
        }
      }

      await runFinalize({ data: totals });
      setProgress(100);
      setPhase("Done");
      setLastRun(Date.now());
      toast.success(
        mode === "deals"
          ? `Synced ${totals.deals} deals`
          : `Synced ${totals.contacts} contacts`,
      );
      onDone();
    } catch (e) {
      toast.error(`Sync failed: ${(e as Error).message}`);
    } finally {
      setTimeout(() => {
        setBusy(false);
        setProgress(0);
        setPhase("");
      }, 600);
    }
  }

  const title = lastRun ? `Last sync ${new Date(lastRun).toLocaleTimeString()}` : "Sync now";
  const defaultLabel = mode === "deals" ? "Sync Deals" : "Sync Contacts";

  return (
    <Button
      variant="outline"
      size="sm"
      className="relative overflow-hidden gap-1.5 min-w-[10rem]"
      disabled={busy}
      onClick={doSync}
      title={title}
    >
      {busy && (
        <span
          className="absolute inset-y-0 left-0 bg-primary/15 transition-[width] duration-300 ease-out"
          style={{ width: `${progress}%` }}
          aria-hidden
        />
      )}
      <RefreshCw className={cn("h-4 w-4 relative", busy && "animate-spin")} />
      <span className="relative">
        {busy ? `${phase || "Syncing"} ${progress}%` : (label ?? defaultLabel)}
      </span>
    </Button>
  );
}
