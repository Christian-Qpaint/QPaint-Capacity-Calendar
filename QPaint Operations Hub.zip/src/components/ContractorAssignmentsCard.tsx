import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { HardHat, Plus, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  contractorsQuery,
  jobContractorAssignmentsQuery,
  createContractorAssignment,
  deleteContractorAssignment,
} from "@/lib/db";

export function ContractorAssignmentsCard({ jobId }: { jobId: string }) {
  const qc = useQueryClient();
  const contractors = useQuery(contractorsQuery);
  const assignments = useQuery(jobContractorAssignmentsQuery(jobId));

  const [contractorId, setContractorId] = useState<string>("");
  const [hours, setHours] = useState<string>("8");
  const [rate, setRate] = useState<string>("");

  const create = useMutation({
    mutationFn: createContractorAssignment,
    onSuccess: () => {
      toast.success("Contractor assigned");
      qc.invalidateQueries({ queryKey: ["job_contractor_assignments"] });
      setContractorId("");
      setHours("8");
      setRate("");
    },
    onError: (e: Error) => toast.error(`Assign failed: ${e.message}`),
  });

  const remove = useMutation({
    mutationFn: deleteContractorAssignment,
    onSuccess: () => {
      toast.success("Assignment removed");
      qc.invalidateQueries({ queryKey: ["job_contractor_assignments"] });
    },
    onError: (e: Error) => toast.error(`Remove failed: ${e.message}`),
  });

  const rows = assignments.data ?? [];
  const totalAllocated = rows.reduce((s, r) => s + Number(r.allocated_hours ?? 0), 0);
  const totalCost = rows.reduce((s, r) => s + Number(r.allocated_hours ?? 0) * Number(r.hourly_rate ?? 0), 0);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <HardHat className="h-4 w-4 text-accent-foreground" />
          <CardTitle>Contractor assignments</CardTitle>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline">{totalAllocated}h allocated</Badge>
          {totalCost > 0 && <Badge variant="secondary">${totalCost.toLocaleString()}</Badge>}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {assignments.isLoading ? (
          <Skeleton className="h-20" />
        ) : rows.length === 0 ? (
          <div className="text-sm text-muted-foreground">No contractors assigned yet.</div>
        ) : (
          <div className="space-y-2">
            {rows.map((r) => {
              const c = contractors.data?.find((x) => x.id === r.contractor_id);
              return (
                <div key={r.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
                  <div className="min-w-0">
                    <div className="font-medium text-sm truncate">{c?.name ?? "Contractor"}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {c?.trade ?? "—"} · {r.allocated_hours ?? 0}h allocated
                      {r.hourly_rate ? ` · $${r.hourly_rate}/hr` : ""}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={r.status === "completed" ? "success" : "outline"}>{r.status}</Badge>
                    <Button size="icon" variant="ghost" onClick={() => remove.mutate(r.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="grid gap-3 sm:grid-cols-[1fr_100px_100px_auto] items-end border-t border-border pt-4">
          <div>
            <Label className="text-xs">Contractor</Label>
            <Select value={contractorId} onValueChange={setContractorId}>
              <SelectTrigger><SelectValue placeholder="Select contractor" /></SelectTrigger>
              <SelectContent>
                {(contractors.data ?? []).filter((c) => c.is_active).map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name} {c.trade ? `· ${c.trade}` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Hours</Label>
            <Input type="number" min={0} step={0.5} value={hours} onChange={(e) => setHours(e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">Rate $/hr</Label>
            <Input type="number" min={0} step={1} value={rate} onChange={(e) => setRate(e.target.value)} placeholder="opt" />
          </div>
          <Button
            disabled={!contractorId || create.isPending}
            onClick={() =>
              create.mutate({
                job_id: jobId,
                contractor_id: contractorId,
                allocated_hours: Number(hours) || 0,
                hourly_rate: rate ? Number(rate) : undefined,
              })
            }
          >
            <Plus className="h-4 w-4" /> Assign
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
