import { useSuspenseQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { jobsQuery, appSettingsQuery, revenueTargetsQuery } from "@/lib/db";
import {
  aggregateMonths,
  monthKeyOf,
  unscheduledRevenue,
  trafficLightTone,
  formatMoney,
  type JobLike,
} from "@/lib/revenue";
import { DollarSign, Target, TrendingUp, Wallet, Gauge, Inbox } from "lucide-react";

/**
 * Phase 2.1 — Executive Revenue KPI strip.
 * Additive: renders above existing dashboard content, doesn't replace anything.
 */
export function ExecutiveRevenueStrip() {
  const jobs = useSuspenseQuery(jobsQuery).data;
  const settings = useSuspenseQuery(appSettingsQuery).data;
  const targets = useSuspenseQuery(revenueTargetsQuery).data;

  const thisMonthKey = monthKeyOf(new Date());
  const targetsByMonth: Record<string, number> = {};
  for (const t of targets) {
    if (t.scope === "company" && t.period === "month") {
      const key = t.period_start.slice(0, 10);
      targetsByMonth[key] = (targetsByMonth[key] ?? 0) + Number(t.target_amount);
    }
  }

  const jobLikes: JobLike[] = jobs.map((j) => ({
    id: j.id,
    contract_value: j.contract_value ?? 0,
    completion_percent: j.completion_percentage,
    start_date: j.start_date,
    target_finish_date: j.target_finish_date,
    status: j.status,
    crew_id: j.assigned_crew_id,
  }));

  const months = aggregateMonths({
    jobs: jobLikes,
    method: settings.revenue_allocation_method,
    targetsByMonth,
    green: Number(settings.traffic_light_green_pct),
    amber: Number(settings.traffic_light_amber_pct),
  });

  const current = months[thisMonthKey] ?? {
    monthKey: thisMonthKey, target: targetsByMonth[thisMonthKey] ?? 0,
    booked: 0, recognized: 0, forecast: 0, remaining: 0, achievementPct: 0, status: "red" as const,
  };
  const unscheduled = unscheduledRevenue(jobLikes);
  const tone = trafficLightTone(current.status);

  const monthLabel = new Date(thisMonthKey).toLocaleDateString(undefined, { month: "long", year: "numeric" });

  const cards = [
    { label: "Monthly target", value: formatMoney(current.target), hint: monthLabel, icon: Target, tone: "bg-primary/10 text-primary" },
    { label: "Booked revenue", value: formatMoney(current.booked), hint: `${jobs.length} active jobs`, icon: Wallet, tone: "bg-accent/20 text-accent-foreground" },
    { label: "Recognised", value: formatMoney(current.recognized), hint: "Progress × contract value", icon: TrendingUp, tone: "bg-success/15 text-success" },
    { label: "Remaining to target", value: formatMoney(Math.max(0, current.remaining)), hint: current.remaining < 0 ? "Above target" : "Still to book", icon: DollarSign, tone: current.remaining <= 0 ? "bg-success/15 text-success" : "bg-warning/20 text-warning-foreground" },
    { label: "Achievement", value: `${current.achievementPct}%`, hint: `${current.status.toUpperCase()} · vs monthly goal`, icon: Gauge, tone: tone.chip },
    { label: "Unscheduled revenue", value: formatMoney(unscheduled.value), hint: `${unscheduled.count} jobs waiting`, icon: Inbox, tone: "bg-critical/10 text-critical" },
  ];

  return (
    <section className="space-y-3">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Financial capacity — {monthLabel}</h2>
          <p className="text-sm text-muted-foreground">
            Allocation: <span className="font-medium text-foreground">{settings.revenue_allocation_method.replace(/_/g, " ")}</span>
          </p>
        </div>
        <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full border ${tone.chip}`}>
          {current.status === "green" ? "On target" : current.status === "amber" ? "Watch" : "Behind target"}
        </span>
      </div>

      {/* progress bar */}
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className={`h-full ${tone.bar} transition-all`} style={{ width: `${Math.min(100, current.achievementPct)}%` }} />
      </div>

      <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 xl:grid-cols-6">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <Card key={c.label}>
              <CardContent className="p-4 flex items-start gap-3">
                <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-lg ${c.tone}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground truncate">{c.label}</div>
                  <div className="text-xl font-bold tabular-nums mt-0.5">{c.value}</div>
                  <div className="text-[11px] text-muted-foreground truncate">{c.hint}</div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
