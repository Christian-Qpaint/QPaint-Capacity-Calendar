import { Badge } from "@/components/ui/badge";
import { AlertOctagon, AlertTriangle, CheckCircle2, Eye } from "lucide-react";
import {
  evaluateJobRisk,
  riskTone,
  type JobRiskInput,
  type JobRiskResult,
} from "@/lib/capacity";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface Props extends JobRiskInput {
  className?: string;
  /** Show the reasons in a tooltip on hover. */
  showReasons?: boolean;
}

const ICONS: Record<JobRiskResult["risk"], typeof CheckCircle2> = {
  "On Track": CheckCircle2,
  Watch: Eye,
  "At Risk": AlertTriangle,
  Critical: AlertOctagon,
};

export function JobRiskBadge({ className, showReasons = true, ...input }: Props) {
  const result = evaluateJobRisk(input);
  const Icon = ICONS[result.risk];
  const tone = riskTone(result.risk);

  const badge = (
    <Badge variant="outline" className={cn("gap-1", tone, className)}>
      <Icon className="h-3 w-3" />
      {result.risk}
    </Badge>
  );

  if (!showReasons || result.reasons.length === 0) return badge;

  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span>{badge}</span>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs">
          <div className="text-xs font-semibold mb-1">Why?</div>
          <ul className="space-y-0.5 text-xs">
            {result.reasons.map((r, i) => (
              <li key={i}>• {r}</li>
            ))}
            <li className="text-muted-foreground pt-1">
              Planned {result.plannedPct}% · Δ {result.delta > 0 ? "+" : ""}
              {result.delta}%
            </li>
          </ul>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
