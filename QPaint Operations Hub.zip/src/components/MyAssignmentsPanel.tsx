import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Briefcase, Clock, DollarSign, HardHat, MapPin } from "lucide-react";
import { myAssignmentsQuery, type MyAssignmentRow } from "@/lib/db";
import { cn } from "@/lib/utils";

function money(n: number | null | undefined) {
  return `$${Math.round(Number(n ?? 0)).toLocaleString()}`;
}

function statusTone(s: string): string {
  const k = s.toLowerCase();
  if (k.includes("complete") || k === "paid") return "bg-success/15 text-success border-success/30";
  if (k.includes("progress") || k === "in_progress") return "bg-primary/15 text-primary border-primary/30";
  if (k.includes("hold") || k.includes("delay")) return "bg-warning/15 text-warning border-warning/30";
  return "bg-muted text-muted-foreground border-border";
}

function summarize(rows: MyAssignmentRow[]) {
  let allocated = 0, worked = 0, earnings = 0;
  for (const a of rows) {
    allocated += Number(a.allocated_hours ?? 0);
    worked += Number(a.hours_worked ?? 0);
    earnings += Number(a.hours_worked ?? 0) * Number(a.hourly_rate ?? 0);
  }
  return { allocated, worked, earnings, active: rows.filter(r => (r.status ?? "").toLowerCase() !== "completed").length };
}

interface Props { compact?: boolean; }

export function MyAssignmentsPanel({ compact = false }: Props) {
  const { data, isLoading } = useQuery(myAssignmentsQuery);

  if (isLoading) {
    return (
      <Card>
        <CardHeader><CardTitle>My assignments</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-24 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!data?.contractor) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My assignments</CardTitle>
          <p className="text-xs text-muted-foreground mt-1">Signed in but not linked to a contractor profile.</p>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
            Ask an operations manager to link your account on the <Link to="/contractors" className="underline">Contractors</Link> page,
            or make sure the email on file matches your sign-in email.
          </div>
        </CardContent>
      </Card>
    );
  }

  const { contractor, assignments } = data;
  const s = summarize(assignments);
  const rows = compact ? assignments.slice(0, 5) : assignments;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <HardHat className="h-3.5 w-3.5" /> Contractor
            </div>
            <CardTitle className="mt-1">{contractor.name}</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              {contractor.trade ?? "Trade unspecified"}
              {contractor.hourly_bill_rate ? ` · Bill rate ${money(contractor.hourly_bill_rate)}/h` : ""}
            </p>
          </div>
          <Badge variant="outline" className="gap-1.5">
            <span className={cn("h-2 w-2 rounded-full", contractor.is_active ? "bg-success" : "bg-muted-foreground")} />
            {contractor.is_active ? "Active" : "Inactive"}
          </Badge>
        </CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Stat icon={Briefcase} label="Active jobs" value={String(s.active)} />
          <Stat icon={Clock} label="Hours allocated" value={`${s.allocated.toFixed(0)}h`} />
          <Stat icon={Clock} label="Hours worked" value={`${s.worked.toFixed(0)}h`} />
          <Stat icon={DollarSign} label="Earnings to date" value={money(s.earnings)} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Assignments</CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            {assignments.length === 0 ? "No assignments yet." : `${assignments.length} total${compact && assignments.length > rows.length ? ` · showing ${rows.length}` : ""}.`}
          </p>
        </CardHeader>
        <CardContent className="p-0">
          {assignments.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground">
              You'll see jobs here once an ops manager schedules you.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job</TableHead>
                  <TableHead>Dates</TableHead>
                  <TableHead className="w-48">Hours</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((a) => {
                  const alloc = Number(a.allocated_hours ?? 0);
                  const worked = Number(a.hours_worked ?? 0);
                  const pct = alloc > 0 ? Math.min(100, Math.round((worked / alloc) * 100)) : 0;
                  return (
                    <TableRow key={a.id} className="hover:bg-muted/30">
                      <TableCell>
                        {a.job ? (
                          <Link to="/jobs/$jobId" params={{ jobId: a.job.id }} className="block">
                            <div className="font-medium hover:underline">{a.job.job_name}</div>
                            <div className="text-xs text-muted-foreground flex items-center gap-1">
                              <span className="font-mono">{a.job.job_code}</span> · {a.job.client_name}
                              {a.job.location && (<><span>·</span><MapPin className="h-3 w-3" /><span className="truncate max-w-[180px]">{a.job.location}</span></>)}
                            </div>
                          </Link>
                        ) : (
                          <span className="text-xs text-muted-foreground">Job unavailable</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {a.start_date ?? "—"}<br />{a.end_date ?? "open"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={pct} className="h-1.5 flex-1" />
                          <span className="text-xs tabular-nums text-muted-foreground whitespace-nowrap">{worked.toFixed(0)}/{alloc.toFixed(0)}h</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm tabular-nums">{a.hourly_rate ? `${money(a.hourly_rate)}/h` : "—"}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn("capitalize", statusTone(a.status ?? ""))}>{(a.status ?? "scheduled").replace(/_/g, " ")}</Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Briefcase; label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-muted/20 p-3">
      <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className="mt-1 font-display text-lg font-semibold tabular-nums">{value}</div>
    </div>
  );
}
