import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ShieldAlert, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMyRoles, ROLE_LABELS, type AppRole } from "@/lib/roles";

interface Props {
  roles: AppRole[];
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * Client-side role gate for page content. RLS remains the source of truth;
 * this only hides UI and prevents accidental access.
 */
export function RequireRole({ roles, children, fallback }: Props) {
  const { data, isLoading } = useMyRoles();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }

  const mine = data ?? [];
  const ok = mine.some((r) => roles.includes(r));
  if (ok) return <>{children}</>;

  if (fallback) return <>{fallback}</>;

  return (
    <div className="mx-auto max-w-lg">
      <Card>
        <CardContent className="p-8 text-center space-y-4">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-muted">
            <ShieldAlert className="h-6 w-6 text-muted-foreground" />
          </div>
          <div>
            <h2 className="font-display text-lg font-semibold">Restricted area</h2>
            <p className="text-sm text-muted-foreground mt-1">
              This page is limited to {roles.map((r) => ROLE_LABELS[r]).join(", ")}.
              {mine.length > 0 && (
                <> Your role: {mine.map((r) => ROLE_LABELS[r]).join(", ")}.</>
              )}
            </p>
          </div>
          <div className="flex justify-center gap-2">
            <Button asChild variant="outline" size="sm">
              <Link to="/">Back to dashboard</Link>
            </Button>
            <Button asChild size="sm">
              <Link to="/settings">Request access</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/** Convenience: allowed roles per feature area. Keep in sync with sidebar. */
export const ACCESS = {
  settings: ["owner"] as AppRole[],
  reports: ["owner", "admin", "ops_manager"] as AppRole[],
  crm: ["owner", "admin", "ops_manager"] as AppRole[],
  contacts: ["owner", "admin", "ops_manager"] as AppRole[],
  people: ["owner", "admin", "ops_manager"] as AppRole[],
  operations: ["owner", "admin", "ops_manager", "crew_leader"] as AppRole[],
  ai: ["owner", "admin", "ops_manager", "crew_leader"] as AppRole[],
};
