import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useConfirm } from "@/components/confirm-dialog";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

import {
  dealByIdQuery, dealsQuery, jobsQuery,
  updateDeal, moveDealStage, convertDealToJob, deleteDeal,
  DEAL_STAGES, DEAL_PRIORITIES,
  type DealRow, type DealStage, type DealPriority, type JobRow,
} from "@/lib/db";
import { mockSeedDeals } from "@/lib/mock-deals";

import {
  ArrowLeft, ArrowRight, Briefcase, Calendar, ChevronRight, DollarSign,
  ExternalLink, FileText, Mail, MapPin, Phone, Trash2, User, Hash,
  CheckCircle2, Clock,
} from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/crm_/$dealId")({
  component: DealDetailPage,
});

/* --------- shared tokens (kept in sync with /crm) --------- */

const STAGE_TONE: Record<DealStage, string> = {
  "Lead Received": "bg-slate-100 text-slate-700 border-slate-200",
  "Contact Qualified": "bg-blue-50 text-blue-700 border-blue-200",
  "Site Visit Booked": "bg-indigo-50 text-indigo-700 border-indigo-200",
  "Site Visit Completed": "bg-violet-50 text-violet-700 border-violet-200",
  "Quote Review": "bg-amber-50 text-amber-700 border-amber-200",
  "Quote Sent": "bg-emerald-50 text-emerald-700 border-emerald-200",
};
const PRIORITY_TONE: Record<DealPriority, string> = {
  Low: "bg-slate-100 text-slate-600",
  Normal: "bg-sky-100 text-sky-700",
  High: "bg-amber-100 text-amber-700",
  Urgent: "bg-rose-100 text-rose-700",
};

const fmtMoney = (n?: number | null) =>
  n == null ? "—" : n.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 });

/* ====================================================================== */

function DealDetailPage() {
  const { dealId } = Route.useParams();
  const router = useRouter();
  const qc = useQueryClient();
  const confirm = useConfirm();

  // Try direct query, but also fall back to the list cache (covers demo deals).
  const { data: liveDeal } = useQuery({ ...dealByIdQuery(dealId), retry: 0 });
  const { data: allDeals } = useQuery(dealsQuery);
  const { data: jobs } = useQuery(jobsQuery);

  const deal: DealRow | null = useMemo(() => {
    if (liveDeal) return liveDeal;
    const live = (allDeals ?? []).find((d) => d.id === dealId);
    if (live) return live;
    if (dealId.startsWith("mock-")) {
      return mockSeedDeals().find((d) => d.id === dealId) ?? null;
    }
    return null;
  }, [liveDeal, allDeals, dealId]);
  const usingMock = !!deal && deal.id.startsWith("mock-");

  // Linked jobs (this deal → job via source_deal_id, plus an explicit converted_job_id).
  const linkedJobs: JobRow[] = useMemo(() => {
    if (!deal || !jobs) return [];
    return jobs.filter(
      (j) => j.source_deal_id === deal.id || j.id === deal.converted_job_id,
    );
  }, [deal, jobs]);

  if (!deal) {
    return (
      <div className="mx-auto max-w-xl py-16 text-center">
        <p className="text-sm text-muted-foreground">Deal not found.</p>
        <Link to="/crm" className="mt-4 inline-flex items-center gap-1 text-sm text-primary hover:underline">
          <ArrowLeft className="h-4 w-4" /> Back to pipeline
        </Link>
      </div>
    );
  }

  async function patch(p: Partial<DealRow>) {
    if (usingMock) { toast.info("Demo data — sign in to persist."); return; }
    try {
      await updateDeal(deal!.id, p);
      toast.success("Saved");
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["deals", deal!.id] });
    } catch { toast.error("Could not save"); }
  }

  async function changeStage(toStage: DealStage) {
    if (toStage === deal!.stage) return;
    if (usingMock) { toast.info("Demo data — stage change not persisted."); return; }
    try {
      await moveDealStage(deal!.id, deal!.stage, toStage);
      toast.success(`Moved → ${toStage}`);
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["deals", deal!.id] });
    } catch { toast.error("Could not change stage"); }
  }

  async function convert() {
    if (usingMock) { toast.info("Sign in to persist — this is demo data."); return; }
    try {
      const job = await convertDealToJob(deal!);
      toast.success(`Converted → ${job.job_code}`);
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["deals", deal!.id] });
      qc.invalidateQueries({ queryKey: ["jobs"] });
    } catch { toast.error("Conversion failed"); }
  }

  async function remove() {
    if (usingMock) { router.navigate({ to: "/crm" }); return; }
    if (!(await confirm({ title: `Delete ${deal!.quote_id}?`, description: "This removes the deal from your local database only. Pipedrive is not affected.", confirmLabel: "Delete", destructive: true }))) return;
    try {
      await deleteDeal(deal!.id);
      toast.success("Deal deleted");
      qc.invalidateQueries({ queryKey: ["deals"] });
      router.navigate({ to: "/crm" });
    } catch { toast.error("Could not delete"); }
  }

  const readyForConvert = deal.stage === "Quote Sent" && !deal.converted_job_id && linkedJobs.length === 0;

  return (
    <div className="space-y-6">
      {/* breadcrumb */}
      <div className="flex items-center gap-1 text-xs text-muted-foreground">
        <Link to="/crm" className="inline-flex items-center gap-1 hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> Pipeline
        </Link>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="text-foreground">{deal.quote_id}</span>
      </div>

      {/* header */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-xs font-semibold text-primary">{deal.quote_id}</span>
            <span className={cn("rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase", STAGE_TONE[deal.stage])}>
              {deal.stage}
            </span>
            <span className={cn("rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase", PRIORITY_TONE[deal.priority])}>
              {deal.priority}
            </span>
            {usingMock && <Badge variant="outline" className="text-[10px]">demo</Badge>}
            {deal.converted_job_id && (
              <Badge variant="secondary" className="gap-1 text-[10px]">
                <CheckCircle2 className="h-3 w-3" /> Converted
              </Badge>
            )}
          </div>
          <h1 className="font-display text-3xl font-bold tracking-tight">{deal.client_name}</h1>
          {deal.property_address && (
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" /> {deal.property_address}
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Select value={deal.stage} onValueChange={(v) => changeStage(v as DealStage)}>
            <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {DEAL_STAGES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={deal.priority} onValueChange={(v) => patch({ priority: v as DealPriority })}>
            <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {DEAL_PRIORITIES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
          {readyForConvert && (
            <Button onClick={convert} className="gap-1.5">
              <ArrowRight className="h-4 w-4" /> Convert to Job
            </Button>
          )}
          <Button variant="outline" className="gap-1.5">
            <FileText className="h-4 w-4" /> Quote PDF
          </Button>
          <Button variant="ghost" size="icon" onClick={remove} title="Delete deal">
            <Trash2 className="h-4 w-4 text-rose-600" />
          </Button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Kpi icon={<DollarSign className="h-4 w-4" />} label="Expected value" value={fmtMoney(deal.expected_value)} />
        <Kpi icon={<Clock className="h-4 w-4" />} label="Target hours" value={deal.target_hours != null ? `${deal.target_hours} h` : "—"} />
        <Kpi icon={<User className="h-4 w-4" />} label="Owner" value={deal.owner ?? "Unassigned"} />
        <Kpi icon={<Briefcase className="h-4 w-4" />} label="Linked jobs" value={String(linkedJobs.length)} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* main column */}
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Deal details</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="overview">
                <TabsList className="w-full justify-start overflow-x-auto">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="visit">Site Visit</TabsTrigger>
                  <TabsTrigger value="quote">Quote</TabsTrigger>
                  <TabsTrigger value="notes">Notes</TabsTrigger>
                  <TabsTrigger value="history">History</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-4 grid grid-cols-1 gap-y-3 md:grid-cols-2 md:gap-x-6">
                  <KV
                    k="Client"
                    v={
                      deal.contact_id ? (
                        <Link
                          to="/contacts/$contactId"
                          params={{ contactId: deal.contact_id }}
                          className="text-primary hover:underline"
                        >
                          {deal.client_name}
                        </Link>
                      ) : (
                        deal.client_name
                      )
                    }
                    icon={<User className="h-3.5 w-3.5" />}
                  />
                  <KV k="Contact person" v={deal.contact_person} />
                  <KV k="Phone" v={deal.phone} icon={<Phone className="h-3.5 w-3.5" />} />
                  <KV k="Email" v={deal.email} icon={<Mail className="h-3.5 w-3.5" />} />
                  <KV k="Address" v={deal.property_address} icon={<MapPin className="h-3.5 w-3.5" />} />
                  <KV k="Category" v={deal.category} />
                  <KV k="Quote type" v={deal.quote_type} />
                  <KV k="Client ranking" v={deal.client_ranking} />
                  <KV k="Referral source" v={deal.referral_source} />
                  <KV k="Owner" v={deal.owner} />
                  <KV k="Google Maps"
                    v={deal.google_maps_link ? <a className="text-primary hover:underline" href={deal.google_maps_link} target="_blank" rel="noreferrer">Open map</a> : "—"} />
                  <KV k="Google Drive"
                    v={deal.google_drive_link ? <a className="text-primary hover:underline" href={deal.google_drive_link} target="_blank" rel="noreferrer">Open folder</a> : "—"} />
                  <KV k="Extent of work" v={deal.extent_of_work} multiline className="md:col-span-2" />
                  <KV k="Description" v={deal.description} multiline className="md:col-span-2" />
                </TabsContent>

                <TabsContent value="visit" className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                  <KV k="Appointment date" v={deal.appointment_date} icon={<Calendar className="h-3.5 w-3.5" />} />
                  <KV k="Appointment time" v={deal.appointment_time} />
                  <KV k="Estimator" v={deal.estimator} />
                  <KV k="Visit status" v={deal.site_visit_status} />
                  <KV k="Visit notes" v={deal.site_visit_notes} multiline className="md:col-span-2" />
                </TabsContent>

                <TabsContent value="quote" className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                  <KV k="Quote status" v={deal.quote_status} />
                  <KV k="Quote sent date" v={deal.quote_sent_date} />
                  <KV k="Expected value" v={fmtMoney(deal.expected_value)} />
                  <KV k="Target hours" v={deal.target_hours != null ? `${deal.target_hours} h` : "—"} />
                  <KV k="Actual hours" v={deal.actual_hours != null ? `${deal.actual_hours} h` : "—"} />
                  <KV k="Quote notes" v={deal.quote_notes} multiline className="md:col-span-2" />
                </TabsContent>

                <TabsContent value="notes" className="mt-4 space-y-2">
                  <Textarea
                    rows={5}
                    placeholder="Add a quick note for this deal…"
                    defaultValue={deal.quote_notes ?? ""}
                    onBlur={(e) => {
                      if (e.target.value !== (deal.quote_notes ?? "")) patch({ quote_notes: e.target.value });
                    }}
                  />
                  <p className="text-[11px] text-muted-foreground">Notes auto-save on blur.</p>
                </TabsContent>

                <TabsContent value="history" className="mt-4 space-y-2 text-sm">
                  <HistoryRow stage={deal.stage} when={deal.updated_at} label="Last activity" />
                  <HistoryRow stage="Lead Received" when={deal.created_at} label="Deal created" />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* linked jobs / capacity link */}
          <LinkedJobsCard deal={deal} jobs={linkedJobs} />
        </div>

        {/* side column */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Pipeline</CardTitle></CardHeader>
            <CardContent>
              <ol className="space-y-1.5">
                {DEAL_STAGES.map((s, idx) => {
                  const active = s === deal.stage;
                  const passed = DEAL_STAGES.indexOf(deal.stage) > idx;
                  return (
                    <li key={s} className="flex items-center gap-2 text-sm">
                      <span className={cn(
                        "flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold",
                        active ? "bg-primary text-primary-foreground" :
                        passed ? "bg-emerald-500 text-white" :
                        "bg-muted text-muted-foreground",
                      )}>
                        {passed ? <CheckCircle2 className="h-3 w-3" /> : idx + 1}
                      </span>
                      <button
                        onClick={() => changeStage(s)}
                        className={cn("flex-1 text-left hover:text-primary", active && "font-semibold")}
                      >
                        {s}
                      </button>
                    </li>
                  );
                })}
              </ol>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-base">Quick info</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <SideRow icon={<Hash className="h-3.5 w-3.5" />} label="Quote ID" value={deal.quote_id} />
              <SideRow icon={<Calendar className="h-3.5 w-3.5" />} label="Created" value={new Date(deal.created_at).toLocaleDateString()} />
              <SideRow icon={<Calendar className="h-3.5 w-3.5" />} label="Updated" value={new Date(deal.updated_at).toLocaleDateString()} />
              <SideRow icon={<User className="h-3.5 w-3.5" />} label="Estimator" value={deal.estimator ?? "—"} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ----------------- linked-jobs card ----------------- */

function LinkedJobsCard({ deal, jobs }: { deal: DealRow; jobs: JobRow[] }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-base">Linked jobs &amp; capacity</CardTitle>
        <Link to="/capacity" className="inline-flex items-center gap-1 text-xs text-primary hover:underline">
          Open capacity calendar <ExternalLink className="h-3 w-3" />
        </Link>
      </CardHeader>
      <CardContent>
        {jobs.length === 0 ? (
          <div className="rounded-md border border-dashed bg-muted/20 p-6 text-center">
            <p className="text-sm text-muted-foreground">
              No jobs linked yet. {deal.stage === "Quote Sent"
                ? "Use “Convert to Job” to push this deal into operations."
                : "Move this deal to “Quote Sent” to enable conversion."}
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Hours</TableHead>
                <TableHead className="text-right">% Complete</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {jobs.map((j) => (
                <TableRow key={j.id}>
                  <TableCell>
                    <Link to="/jobs/$jobId" params={{ jobId: j.job_code }} className="font-medium text-primary hover:underline">
                      {j.job_code}
                    </Link>
                    <div className="text-xs text-muted-foreground">{j.job_name}</div>
                  </TableCell>
                  <TableCell><Badge variant="outline">{j.status}</Badge></TableCell>
                  <TableCell className="text-right tabular-nums">{j.hours_worked}/{j.estimated_hours} h</TableCell>
                  <TableCell className="text-right tabular-nums">{j.completion_percentage}%</TableCell>
                  <TableCell className="text-right">
                    <Link to="/capacity" className="text-xs text-primary hover:underline">View on calendar</Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}

/* ----------------- small primitives ----------------- */

function Kpi({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="font-medium uppercase tracking-wide">{label}</span>
          <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/10 text-primary">{icon}</span>
        </div>
        <div className="mt-2 font-display text-2xl font-bold tabular-nums">{value}</div>
      </CardContent>
    </Card>
  );
}

function KV({
  k, v, icon, multiline, className,
}: { k: string; v: React.ReactNode; icon?: React.ReactNode; multiline?: boolean; className?: string }) {
  return (
    <div className={cn("grid gap-1", multiline ? "" : "grid-cols-[140px_1fr] items-start", className)}>
      <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{k}</div>
      <div className="flex items-start gap-1.5 text-sm">
        {icon && <span className="mt-0.5 text-muted-foreground">{icon}</span>}
        <span className="break-words">{v || <span className="text-muted-foreground">—</span>}</span>
      </div>
    </div>
  );
}

function HistoryRow({ stage, when, label }: { stage: DealStage; when: string | null; label: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border bg-card p-2.5">
      <div className="flex items-center gap-2">
        <span className={cn("rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase", STAGE_TONE[stage])}>{stage}</span>
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <span className="text-[11px] text-muted-foreground">{when ? new Date(when).toLocaleString() : "—"}</span>
    </div>
  );
}

function SideRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="flex items-center gap-1.5 text-xs text-muted-foreground">{icon} {label}</span>
      <span className="text-sm font-medium">{value}</span>
    </div>
  );
}
