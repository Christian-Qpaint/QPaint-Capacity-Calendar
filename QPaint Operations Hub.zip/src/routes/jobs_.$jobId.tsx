import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeft, CalendarDays, CheckCircle2, ClipboardCheck, Clock, DollarSign,
  MapPin, Pencil, Phone, Plus, RefreshCw, User, Users, X,
} from "lucide-react";
import { JobRiskBadge } from "@/components/JobRiskBadge";
import { jobRemainingHours } from "@/lib/capacity";
import { UpdateProgressModal } from "@/components/modals";
import { ContractorAssignmentsCard } from "@/components/ContractorAssignmentsCard";
import {
  jobByIdQuery, crewsQuery, staffQuery,
  jobMilestonesQuery, jobNotesQuery, jobBlockersQuery, jobOnsiteCrewQuery,
  jobProgressUpdatesQuery,
  addJobMilestone, toggleJobMilestone,
  addJobNote,
  addJobBlocker, resolveJobBlocker,
  logProgress,
} from "@/lib/db";

export const Route = createFileRoute("/jobs_/$jobId")({
  head: ({ params }) => ({
    meta: [
      { title: `Job ${params.jobId} · QPaint` },
      { name: "description", content: "Complete operational record for this painting job: progress, crew, blockers and billing." },
    ],
  }),
  component: JobDetailPage,
});

const blockerTones = {
  warning: "border-warning/40 bg-warning/10 text-warning-foreground",
  critical: "border-critical/40 bg-critical/10 text-critical",
} as const;

function fmtWhen(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

function JobDetailPage() {
  const { jobId } = Route.useParams();
  const qc = useQueryClient();
  const jobQ = useQuery(jobByIdQuery(jobId));
  const crewsQ = useQuery(crewsQuery);
  const staffQ = useQuery(staffQuery);

  const dealId = jobQ.data?.id ?? null;
  const milestonesQ = useQuery({ ...jobMilestonesQuery(dealId ?? ""), enabled: !!dealId });
  const notesQ = useQuery({ ...jobNotesQuery(dealId ?? ""), enabled: !!dealId });
  const blockersQ = useQuery({ ...jobBlockersQuery(dealId ?? ""), enabled: !!dealId });
  const onsiteQ = useQuery({ ...jobOnsiteCrewQuery(jobQ.data?.assigned_crew_id ?? null), enabled: !!dealId });
  const progressQ = useQuery({ ...jobProgressUpdatesQuery(dealId ?? ""), enabled: !!dealId });

  const [pctInput, setPctInput] = useState<string>("");
  const [noteBody, setNoteBody] = useState("");
  const [newMilestone, setNewMilestone] = useState("");
  const [newBlockerLabel, setNewBlockerLabel] = useState("");
  const [newBlockerKind, setNewBlockerKind] = useState("weather");

  const invalidateJob = () => {
    qc.invalidateQueries({ queryKey: ["jobs"] });
    qc.invalidateQueries({ queryKey: ["jobs", jobId] });
    if (dealId) {
      qc.invalidateQueries({ queryKey: ["job_milestones", dealId] });
      qc.invalidateQueries({ queryKey: ["job_notes", dealId] });
      qc.invalidateQueries({ queryKey: ["job_blockers", dealId] });
      qc.invalidateQueries({ queryKey: ["job_progress_updates", dealId] });
    }
  };

  const milestoneToggle = useMutation({
    mutationFn: ({ id, done }: { id: string; done: boolean }) => toggleJobMilestone(id, done),
    onSuccess: invalidateJob,
  });
  const milestoneAdd = useMutation({
    mutationFn: (name: string) => addJobMilestone(dealId!, name),
    onSuccess: () => { setNewMilestone(""); invalidateJob(); },
  });
  const noteAdd = useMutation({
    mutationFn: (body: string) => addJobNote(dealId!, body),
    onSuccess: () => { setNoteBody(""); invalidateJob(); },
  });
  const blockerAdd = useMutation({
    mutationFn: () => addJobBlocker({ dealId: dealId!, kind: newBlockerKind, label: newBlockerLabel }),
    onSuccess: () => { setNewBlockerLabel(""); invalidateJob(); },
  });
  const blockerResolve = useMutation({
    mutationFn: (id: string) => resolveJobBlocker(id),
    onSuccess: invalidateJob,
  });
  const progressLog = useMutation({
    mutationFn: (pct: number) => logProgress({
      jobId: dealId!,
      completion: pct,
      hoursWorked: Number(jobQ.data?.hours_worked ?? 0),
      blocker: "none",
      notes: undefined,
    }),
    onSuccess: () => { setPctInput(""); invalidateJob(); },
  });

  if (jobQ.isLoading) {
    return <div className="p-6 text-sm text-muted-foreground">Loading job…</div>;
  }
  if (!jobQ.data) {
    return (
      <div className="p-6 space-y-3">
        <Link to="/jobs" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to jobs
        </Link>
        <div className="text-lg font-semibold">Job not found</div>
        <p className="text-sm text-muted-foreground">
          No job matches <span className="font-mono">{jobId}</span>. Jobs are deals in the Jobs Pipeline —
          check the <Link to="/crm" className="underline">CRM</Link>.
        </p>
      </div>
    );
  }

  const j = jobQ.data;
  const crewName = crewsQ.data?.find((c) => c.id === j.assigned_crew_id)?.name ?? "Unassigned";
  const supervisorName = staffQ.data?.find((s) => s.id === j.supervisor_id)?.full_name ?? "—";
  const displayPct = Math.round(j.completion_percentage ?? 0);
  const estHours = Number(j.estimated_hours ?? 0);
  const workedHours = Number(j.hours_worked ?? 0);
  const remaining = jobRemainingHours(estHours, workedHours);
  const contractValue = Number(j.contract_value ?? 0);

  const milestones = milestonesQ.data ?? [];
  const notes = notesQ.data ?? [];
  const blockers = blockersQ.data ?? [];
  const onsite = onsiteQ.data ?? [];
  const activeBlockers = blockers.filter((b) => !b.resolved_at);
  const doneCount = milestones.filter((m) => m.is_completed).length;

  return (
    <div className="space-y-6">
      <Link to="/jobs" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to jobs
      </Link>

      {/* Header */}
      <Card>
        <CardContent className="p-6 space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="font-mono">{j.job_code}</span>
                <span>·</span>
                <span>{j.client_name}</span>
              </div>
              <h1 className="text-2xl font-bold mt-1">{j.job_name}</h1>
              {j.location && (
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground mt-1">
                  <MapPin className="h-3.5 w-3.5" /> {j.location}
                </div>
              )}
              <div className="flex flex-wrap items-center gap-2 mt-3">
                <span className="text-[11px] font-medium px-2 py-0.5 rounded-full border bg-accent/20 text-accent-foreground border-accent/40">
                  {j.status}
                </span>
                <span className="text-[11px] font-medium px-2 py-0.5 rounded-full border bg-muted text-muted-foreground border-border">
                  Billing: {j.billing_status}
                </span>
                <JobRiskBadge
                  completionPct={displayPct}
                  startDate={j.start_date ?? new Date().toISOString().slice(0, 10)}
                  targetFinishDate={j.target_finish_date ?? new Date(Date.now() + 30 * 86400_000).toISOString().slice(0, 10)}
                  hasCrewAssigned={Boolean(j.assigned_crew_id)}
                  hasBlocker={activeBlockers.length > 0}
                  crewOverbooked={false}
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button asChild variant="outline" size="sm" className="gap-1.5">
                <Link to="/crm_/$dealId" params={{ dealId: j.id }}><Pencil className="h-4 w-4" /> Edit in CRM</Link>
              </Button>
              <UpdateProgressModal
                defaultJob={`${j.job_code} · ${j.job_name}`}
                trigger={<Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="h-4 w-4" /> Update progress</Button>}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
              <span>Overall completion</span>
              <span className="font-semibold text-foreground">{displayPct}%</span>
            </div>
            <Progress value={displayPct} className="h-2.5" />
          </div>
        </CardContent>
      </Card>

      {/* Info + Progress */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card>
          <CardHeader><CardTitle>Job information</CardTitle></CardHeader>
          <CardContent className="space-y-4 text-sm">
            <InfoRow label="Job ID" value={<span className="font-mono">{j.job_code}</span>} />
            <InfoRow
              label="Client contact"
              value={
                j.client_contact ? (
                  <div className="flex items-center gap-1.5 text-sm">
                    <Phone className="h-3 w-3 text-muted-foreground" /> {j.client_contact}
                  </div>
                ) : <span className="text-muted-foreground">—</span>
              }
            />
            <InfoRow label="Address" value={j.location ?? <span className="text-muted-foreground">—</span>} />
            <Separator />
            <InfoRow label="Start date" value={j.start_date ?? <span className="text-muted-foreground">—</span>} />
            <InfoRow label="Target finish" value={j.target_finish_date ?? <span className="text-muted-foreground">—</span>} />
            <Separator />
            <InfoRow label="Estimated hours" value={`${estHours} h`} />
            <InfoRow label="Hours worked" value={`${workedHours} h`} />
            <InfoRow
              label="Remaining"
              value={<span className={remaining < 0 ? "text-critical font-semibold" : "font-semibold"}>{remaining} h</span>}
            />
            {contractValue > 0 && (
              <>
                <Separator />
                <InfoRow label="Contract value" value={<span className="font-semibold">${contractValue.toLocaleString()}</span>} icon={DollarSign} />
              </>
            )}
            <Separator />
            <InfoRow label="Assigned crew" value={crewName} icon={Users} />
            <InfoRow label="Supervisor" value={supervisorName} icon={User} />
          </CardContent>
        </Card>

        {/* Progress tracking */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Progress tracking</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              {doneCount} of {milestones.length} milestones complete
            </p>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
                <span>Completion</span>
                <span>{displayPct}%</span>
              </div>
              <Progress value={displayPct} className="h-2" />
              <div className="mt-3 flex items-end gap-2 max-w-xs">
                <div className="flex-1 space-y-1.5">
                  <Label htmlFor="pct" className="text-xs">Set completion %</Label>
                  <Input
                    id="pct" type="number" min={0} max={100}
                    placeholder={String(displayPct)}
                    value={pctInput}
                    onChange={(e) => setPctInput(e.target.value)}
                  />
                </div>
                <Button
                  size="sm"
                  disabled={progressLog.isPending || !pctInput}
                  onClick={() => progressLog.mutate(Math.max(0, Math.min(100, Number(pctInput))))}
                >
                  Save
                </Button>
              </div>
            </div>

            <Separator />

            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Milestones</div>
              </div>
              {milestones.length === 0 ? (
                <p className="text-sm text-muted-foreground italic">No milestones yet. Add one below.</p>
              ) : (
                <div className="grid sm:grid-cols-2 gap-2">
                  {milestones.map((m) => (
                    <label
                      key={m.id}
                      htmlFor={m.id}
                      className={`flex items-center gap-3 rounded-lg border border-border px-3 py-2.5 cursor-pointer hover:bg-muted/40 ${m.is_completed ? "bg-success/5" : ""}`}
                    >
                      <Checkbox
                        id={m.id}
                        checked={m.is_completed}
                        onCheckedChange={(v) => milestoneToggle.mutate({ id: m.id, done: Boolean(v) })}
                      />
                      <div className="min-w-0 flex-1">
                        <div className={`text-sm font-medium ${m.is_completed ? "line-through text-muted-foreground" : ""}`}>
                          {m.milestone_name}
                        </div>
                        {m.completed_at && (
                          <div className="text-xs text-muted-foreground">Completed {fmtWhen(m.completed_at)}</div>
                        )}
                      </div>
                    </label>
                  ))}
                </div>
              )}
              <div className="flex gap-2 mt-3">
                <Input
                  placeholder="Add a milestone…"
                  value={newMilestone}
                  onChange={(e) => setNewMilestone(e.target.value)}
                />
                <Button
                  size="sm"
                  disabled={!newMilestone.trim() || milestoneAdd.isPending}
                  onClick={() => milestoneAdd.mutate(newMilestone.trim())}
                >
                  <Plus className="h-4 w-4" /> Add
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress log + on-site crew */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><CalendarDays className="h-4 w-4" /> Progress log</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">Latest progress updates logged for this job.</p>
          </CardHeader>
          <CardContent>
            {(progressQ.data ?? []).length === 0 ? (
              <p className="text-sm text-muted-foreground italic">No progress updates yet.</p>
            ) : (
              <ol className="relative border-l border-border ml-2 space-y-5">
                {(progressQ.data ?? []).map((e: Record<string, unknown>) => (
                  <li key={String(e.id)} className="ml-5">
                    <span className="absolute -left-[7px] mt-1.5 h-3 w-3 rounded-full ring-4 ring-card bg-accent" />
                    <div className="flex items-baseline gap-2">
                      <span className="text-xs font-mono text-muted-foreground">
                        {fmtWhen(String(e.created_at))}
                      </span>
                      <span className="font-medium text-sm">
                        {String(e.progress_percentage ?? 0)}% · {String(e.hours_worked ?? 0)}h logged
                      </span>
                    </div>
                    {e.update_note ? (
                      <p className="text-sm text-muted-foreground mt-0.5">{String(e.update_note)}</p>
                    ) : null}
                  </li>
                ))}
              </ol>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Users className="h-4 w-4" /> On-site crew</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">{crewName} · {onsite.length} on team</p>
          </CardHeader>
          <CardContent className="space-y-2">
            {onsite.length === 0 ? (
              <p className="text-sm text-muted-foreground italic">
                {j.assigned_crew_id ? "No staff on this crew yet." : "No crew assigned yet."}
              </p>
            ) : onsite.map((m) => (
              <div key={m.id} className="flex items-center gap-3 rounded-lg border border-border p-2.5">
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground text-xs font-semibold">
                  {m.full_name.split(" ").map((n) => n[0]).slice(0, 2).join("")}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate">{m.full_name}</div>
                  <div className="text-xs text-muted-foreground">{m.role}</div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Contractor assignments (real) */}
      <ContractorAssignmentsCard jobId={j.id} />

      {/* Notes & blockers */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Notes & blockers</CardTitle></CardHeader>
          <CardContent className="space-y-5">
            {/* Blockers */}
            <div>
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                Active blockers ({activeBlockers.length})
              </div>
              {activeBlockers.length === 0 ? (
                <p className="text-sm text-muted-foreground italic">No active blockers.</p>
              ) : (
                <div className="grid sm:grid-cols-2 gap-2">
                  {activeBlockers.map((b) => (
                    <div key={b.id} className={`flex gap-3 rounded-lg border p-3 ${blockerTones[b.tone] ?? blockerTones.warning}`}>
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-semibold uppercase tracking-wide">{b.kind}</div>
                        <div className="text-sm font-medium">{b.label}</div>
                        {b.body && <div className="text-sm text-muted-foreground">{b.body}</div>}
                      </div>
                      <button
                        onClick={() => blockerResolve.mutate(b.id)}
                        className="shrink-0 text-muted-foreground hover:text-foreground"
                        title="Resolve"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex gap-2 mt-3">
                <select
                  value={newBlockerKind}
                  onChange={(e) => setNewBlockerKind(e.target.value)}
                  className="rounded-md border border-input bg-background px-2 text-sm"
                >
                  <option value="weather">Weather</option>
                  <option value="material">Material</option>
                  <option value="client">Client</option>
                  <option value="crew">Crew</option>
                  <option value="other">Other</option>
                </select>
                <Input
                  placeholder="Describe a blocker…"
                  value={newBlockerLabel}
                  onChange={(e) => setNewBlockerLabel(e.target.value)}
                />
                <Button
                  size="sm"
                  disabled={!newBlockerLabel.trim() || blockerAdd.isPending}
                  onClick={() => blockerAdd.mutate()}
                >Log</Button>
              </div>
            </div>

            <Separator />

            {/* Add a note */}
            <div>
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Add a note</div>
              <Textarea
                placeholder="Log a site update, blocker, or change…"
                rows={2}
                value={noteBody}
                onChange={(e) => setNoteBody(e.target.value)}
              />
              <div className="flex justify-end mt-2">
                <Button
                  size="sm"
                  disabled={!noteBody.trim() || noteAdd.isPending}
                  onClick={() => noteAdd.mutate(noteBody.trim())}
                >Post note</Button>
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Notes log</div>
              {notes.length === 0 ? (
                <p className="text-sm text-muted-foreground italic">No notes yet.</p>
              ) : (
                <ul className="space-y-3">
                  {notes.map((n) => (
                    <li key={n.id} className="rounded-lg border border-border p-3">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span className="font-medium text-foreground">{n.author_name ?? "Unknown"}</span>
                        <span>{fmtWhen(n.created_at)}</span>
                      </div>
                      <p className="text-sm">{n.body}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><ClipboardCheck className="h-4 w-4" /> Admin & billing</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="rounded-lg border border-border p-4">
              <div className="text-xs text-muted-foreground">Completion</div>
              <div className="text-2xl font-bold">{displayPct}%</div>
              <Progress value={displayPct} className="h-1.5 mt-2" />
            </div>

            <div className="rounded-lg border border-warning/30 bg-warning/10 p-3">
              <div className="text-xs font-semibold uppercase tracking-wide text-warning-foreground flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" /> Billing status
              </div>
              <p className="text-sm mt-1">{j.billing_status}</p>
            </div>

            <Button className="w-full gap-1.5"><CheckCircle2 className="h-4 w-4" /> Mark ready for invoice</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function InfoRow({ label, value, icon: Icon }: { label: string; value: React.ReactNode; icon?: typeof Users }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div className="text-xs text-muted-foreground inline-flex items-center gap-1.5 mt-0.5">
        {Icon && <Icon className="h-3.5 w-3.5" />} {label}
      </div>
      <div className="text-right">{value}</div>
    </div>
  );
}
