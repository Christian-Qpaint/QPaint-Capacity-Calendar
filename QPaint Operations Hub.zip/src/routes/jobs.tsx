import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useSuspenseQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Briefcase, CalendarRange, CheckCircle2, Clock, DollarSign,
  Eye, MoreHorizontal, Pencil, Plus, Search,
} from "lucide-react";
import { UpdateProgressModal } from "@/components/modals";
import { jobsQuery, crewsQuery, logProgress, type JobRow, type CrewRow } from "@/lib/db";
import { log } from "@/lib/log";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/jobs")({
  head: () => ({
    meta: [
      { title: "Jobs · QPaint Capacity OS" },
      { name: "description", content: "Manage all painting projects: status, crew assignment, hours, completion and billing." },
    ],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(jobsQuery);
    context.queryClient.ensureQueryData(crewsQuery);
  },
  component: () => (
    <RequireRole roles={ACCESS.operations}>
      <JobsPage />
    </RequireRole>
  ),
  pendingComponent: () => (
    <div className="p-8 text-sm text-muted-foreground">Loading jobs…</div>
  ),
  errorComponent: ({ error }) => (
    <div className="p-8 text-sm text-critical">Failed to load jobs: {error.message}</div>
  ),
});

/* ---------- visual tokens ---------- */
// Status / billing tones map to whatever the DB returns. We narrow to known
// values for color and fall back to a neutral muted look for anything else.

const statusTone: Record<string, string> = {
  "Not Started": "bg-muted text-muted-foreground border-border",
  "Scheduled": "bg-primary/10 text-primary border-primary/20",
  "In Progress": "bg-accent/20 text-accent-foreground border-accent/40",
  "Delayed": "bg-warning/20 text-warning-foreground border-warning/40",
  "On Hold": "bg-warning/20 text-warning-foreground border-warning/40",
  "Completed": "bg-success/15 text-success border-success/30",
  "Ready for Invoice": "bg-success/15 text-success border-success/30",
  "Invoiced": "bg-primary/10 text-primary border-primary/20",
};
const billingTone: Record<string, string> = {
  "Not Ready": "bg-muted text-muted-foreground border-border",
  "Ready": "bg-accent/20 text-accent-foreground border-accent/40",
  "Invoiced": "bg-primary/10 text-primary border-primary/20",
  "Paid": "bg-success/15 text-success border-success/30",
};

function Pill({ value, tones }: { value: string; tones: Record<string, string> }) {
  const cls = tones[value] ?? "bg-muted text-muted-foreground border-border";
  return <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full border whitespace-nowrap ${cls}`}>{value}</span>;
}

function Stat({
  icon: Icon, label, value, hint, tone,
}: { icon: typeof Briefcase; label: string; value: string; hint?: string; tone: "primary" | "accent" | "success" | "warning" }) {
  const toneCls = {
    primary: "bg-primary/10 text-primary",
    accent: "bg-accent/20 text-accent-foreground",
    success: "bg-success/15 text-success",
    warning: "bg-warning/20 text-warning-foreground",
  }[tone];
  return (
    <Card>
      <CardContent className="p-5 flex items-start gap-4">
        <div className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${toneCls}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
          <div className="text-2xl font-bold mt-0.5">{value}</div>
          {hint && <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>}
        </div>
      </CardContent>
    </Card>
  );
}

const ALL = "__all";
const STATUSES = ["Not Started", "Scheduled", "In Progress", "Delayed", "On Hold", "Completed", "Ready for Invoice", "Invoiced"];
const BILLING = ["Not Ready", "Ready", "Invoiced", "Paid"];
const COMPLETION = [
  { v: "any", label: "Any %" },
  { v: "0", label: "Not started (0%)" },
  { v: "lt50", label: "Under 50%" },
  { v: "50-99", label: "50–99%" },
  { v: "100", label: "Complete (100%)" },
];

function JobsPage() {
  const { data: jobs } = useSuspenseQuery(jobsQuery);
  const { data: crews } = useSuspenseQuery(crewsQuery);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const crewById = useMemo(() => Object.fromEntries(crews.map((c: CrewRow) => [c.id, c.name])), [crews]);
  const crewNameOptions = useMemo(() => [...crews.map((c) => c.name), "Unassigned"], [crews]);

  const [q, setQ] = useState("");
  const [status, setStatus] = useState(ALL);
  const [crew, setCrew] = useState(ALL);
  const [completion, setCompletion] = useState("any");
  const [billing, setBilling] = useState(ALL);

  const filtered = useMemo(() => {
    return jobs.filter((j) => {
      const crewName = j.assigned_crew_id ? crewById[j.assigned_crew_id] ?? "—" : "Unassigned";
      if (q && !`${j.job_code} ${j.job_name} ${j.client_name} ${j.location ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
      if (status !== ALL && j.status !== status) return false;
      if (crew !== ALL && crewName !== crew) return false;
      if (billing !== ALL && j.billing_status !== billing) return false;
      const p = Number(j.completion_percentage);
      if (completion === "0" && p !== 0) return false;
      if (completion === "lt50" && (p >= 50 || p === 0)) return false;
      if (completion === "50-99" && (p < 50 || p >= 100)) return false;
      if (completion === "100" && p !== 100) return false;
      return true;
    });
  }, [jobs, crewById, q, status, crew, completion, billing]);

  const active = filtered.filter((j) => !["Completed", "Invoiced"].includes(j.status)).length;
  const totalEst = filtered.reduce((s, j) => s + Number(j.estimated_hours), 0);
  const totalWorked = filtered.reduce((s, j) => s + Number(j.hours_worked), 0);
  const avg = filtered.length ? Math.round(filtered.reduce((s, j) => s + Number(j.completion_percentage), 0) / filtered.length) : 0;
  const ready = filtered.filter((j) => j.status === "Ready for Invoice" || j.billing_status === "Ready").length;
  const bookedRevenue = filtered.reduce((s, j) => s + Number(j.contract_value ?? 0), 0);
  const recognizedRevenue = filtered.reduce(
    (s, j) => s + (Number(j.contract_value ?? 0) * Number(j.completion_percentage ?? 0)) / 100, 0,
  );
  const fmtMoney = (n: number) => n >= 1_000_000 ? `$${(n/1_000_000).toFixed(2)}M` : n >= 1_000 ? `$${(n/1_000).toFixed(0)}k` : `$${Math.round(n).toLocaleString()}`;

  /* ---------- mutations ---------- */
  const progress = useMutation({
    mutationFn: logProgress,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["jobs"] }),
    onError: (e) => log.error("jobs:progress", e),
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">Jobs</h2>
          <p className="text-sm text-muted-foreground">
            Jobs are deals in the Jobs Pipeline. Move a deal into that pipeline from the{" "}
            <Link to="/crm" className="underline hover:text-foreground">CRM</Link> to add one.
          </p>
        </div>
        <Button asChild variant="outline" className="gap-1.5">
          <Link to="/crm"><Plus className="h-4 w-4" /> Add via CRM</Link>
        </Button>
      </div>


      {/* Summary stats */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-6">
        <Stat icon={Briefcase} label="Active jobs" value={String(active)} hint={`${filtered.length} total`} tone="primary" />
        <Stat icon={DollarSign} label="Booked revenue" value={fmtMoney(bookedRevenue)} hint={`Recognised ${fmtMoney(recognizedRevenue)}`} tone="success" />
        <Stat icon={Clock} label="Est. hours" value={totalEst.toLocaleString()} hint="All filtered" tone="accent" />
        <Stat icon={Clock} label="Worked hours" value={totalWorked.toLocaleString()} hint={`${Math.round((totalWorked / Math.max(totalEst, 1)) * 100)}% of estimate`} tone="warning" />
        <Stat icon={CheckCircle2} label="Avg completion" value={`${avg}%`} hint="Across filtered" tone="success" />
        <Stat icon={DollarSign} label="Ready to invoice" value={String(ready)} hint="Awaiting admin" tone="success" />
      </div>


      {/* Filter bar */}
      <Card>
        <CardContent className="p-4 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-56">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search job, client, location…" className="pl-9 h-9" />
          </div>

          <FilterSelect value={status} onChange={setStatus} placeholder="Status" options={STATUSES} />
          <FilterSelect value={crew} onChange={setCrew} placeholder="Crew" options={crewNameOptions} />
          <Select value={completion} onValueChange={setCompletion}>
            <SelectTrigger className="h-9 w-40"><SelectValue /></SelectTrigger>
            <SelectContent>{COMPLETION.map((r) => <SelectItem key={r.v} value={r.v}>{r.label}</SelectItem>)}</SelectContent>
          </Select>
          <FilterSelect value={billing} onChange={setBilling} placeholder="Billing" options={BILLING} />
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="font-semibold">Job code</TableHead>
                <TableHead className="font-semibold">Client</TableHead>
                <TableHead className="font-semibold">Job</TableHead>
                <TableHead className="font-semibold">Location</TableHead>
                <TableHead className="font-semibold">Start</TableHead>
                <TableHead className="font-semibold">Target finish</TableHead>
                <TableHead className="font-semibold">Crew</TableHead>
                <TableHead className="font-semibold text-right">Est. hrs</TableHead>
                <TableHead className="font-semibold text-right">Worked</TableHead>
                <TableHead className="font-semibold w-40">% Complete</TableHead>
                <TableHead className="font-semibold">Status</TableHead>
                <TableHead className="font-semibold text-right">Contract $</TableHead>
                <TableHead className="font-semibold">Billing</TableHead>
                <TableHead className="text-right font-semibold">Actions</TableHead>

              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((j: JobRow) => {
                const crewName = j.assigned_crew_id ? crewById[j.assigned_crew_id] ?? "—" : "Unassigned";
                const over = Number(j.hours_worked) > Number(j.estimated_hours);
                const unassigned = !j.assigned_crew_id;
                const pct = Number(j.completion_percentage);
                return (
                  <TableRow
                    key={j.id}
                    className="cursor-pointer hover:bg-muted/40"
                    onClick={(e) => {
                      if ((e.target as HTMLElement).closest("a,button,[role='menuitem']")) return;
                      navigate({ to: "/jobs/$jobId", params: { jobId: j.job_code } });
                    }}
                  >
                    <TableCell className="font-mono text-xs">
                      <Link to="/jobs/$jobId" params={{ jobId: j.job_code }} className="text-muted-foreground hover:text-foreground hover:underline">
                        {j.job_code}
                      </Link>
                    </TableCell>
                    <TableCell className="font-medium">{j.client_name}</TableCell>
                    <TableCell>
                      <Link to="/jobs/$jobId" params={{ jobId: j.job_code }} className="hover:underline">
                        {j.job_name}
                      </Link>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground max-w-52 truncate">{j.location}</TableCell>
                    <TableCell className="text-sm tabular-nums">{j.start_date ?? "—"}</TableCell>
                    <TableCell className="text-sm tabular-nums">{j.target_finish_date ?? "—"}</TableCell>
                    <TableCell>
                      {unassigned
                        ? <Badge variant="outline" className="border-critical/40 text-critical">Unassigned</Badge>
                        : j.assigned_crew_id
                          ? <Link to="/crews/$crewId" params={{ crewId: j.assigned_crew_id }} className="text-sm hover:underline">{crewName}</Link>
                          : <span className="text-sm">{crewName}</span>}
                    </TableCell>

                    <TableCell className="text-right tabular-nums">{j.estimated_hours}</TableCell>
                    <TableCell className={`text-right tabular-nums ${over ? "text-critical font-semibold" : ""}`}>{j.hours_worked}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={pct} className="h-1.5 flex-1" />
                        <span className="text-xs tabular-nums w-9 text-right">{pct}%</span>
                      </div>
                    </TableCell>
                    <TableCell><Pill value={j.status} tones={statusTone} /></TableCell>
                    <TableCell className="text-right tabular-nums font-medium">
                      {j.contract_value ? fmtMoney(Number(j.contract_value)) : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell><Pill value={j.billing_status} tones={billingTone} /></TableCell>

                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuItem asChild>
                            <Link to="/jobs/$jobId" params={{ jobId: j.job_code }}>
                              <Eye className="h-4 w-4 mr-2" /> View details
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem><Pencil className="h-4 w-4 mr-2" /> Edit</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem><CalendarRange className="h-4 w-4 mr-2" /> Reschedule</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                      <UpdateProgressModal
                        defaultJob={`${j.job_code} · ${j.job_name}`}
                        trigger={<Button variant="ghost" size="sm" className="h-8 px-2 text-xs">Log</Button>}
                        onSave={async (v) => {
                          await progress.mutateAsync({
                            jobId: j.id,
                            completion: Number(v.completion),
                            hoursWorked: Number(v.hoursWorked),
                            blocker: v.blocker,
                            notes: v.notes,
                          });
                        }}
                      />
                    </TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={14} className="text-center py-10 text-sm text-muted-foreground">
                    No jobs match the current filters.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function FilterSelect({
  value, onChange, placeholder, options,
}: { value: string; onChange: (v: string) => void; placeholder: string; options: readonly string[] }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="h-9 w-40">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL}>All {placeholder.toLowerCase()}</SelectItem>
        {options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
      </SelectContent>
    </Select>
  );
}
