import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

function client() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
}

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json",
};

export const Route = createFileRoute("/api/public/contacts/$contactId")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: cors }),
      GET: async ({ params }) => {
        const sb = client();
        const [contactRes, dealsRes, jobsRes] = await Promise.all([
          sb.from("contacts").select("*").eq("id", params.contactId).maybeSingle(),
          sb.from("deals").select("id,quote_id,stage,expected_value,description,updated_at").eq("contact_id", params.contactId),
          sb.from("jobs").select("id,job_code,job_name,status,completion_percentage,location,updated_at").eq("contact_id", params.contactId),
        ]);

        if (contactRes.error) {
          return new Response(JSON.stringify({ error: contactRes.error.message }), { status: 500, headers: cors });
        }
        if (!contactRes.data) {
          return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: cors });
        }
        return new Response(
          JSON.stringify({
            data: contactRes.data,
            deals: dealsRes.data ?? [],
            jobs: jobsRes.data ?? [],
          }),
          { status: 200, headers: cors },
        );
      },
    },
  },
});
