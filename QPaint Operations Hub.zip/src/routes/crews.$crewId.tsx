/**
 * Crew detail page — /crews/$crewId
 *
 * URL-addressable, API-style: a UUID hits the live `crews` table; any other
 * slug falls back to the in-app roster so existing demo links still resolve.
 */
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { ArrowLeft, Briefcase, MapPin, Users } from "lucide-react";
import { crewByIdQuery, jobsQuery, staffQuery, schedulesQuery } from "@/lib/db";

export const Route = createFileRoute("/crews/$crewId")({
  head: ({ params }) => ({
    meta: [
      { title: `Crew ${params.crewId} · QPaint` },
      { name: "description", content: "Crew profile: capacity, current jobs, members and schedule." },
    ],
  }),
  loader: ({ context, params }) => {
    context.queryClient.ensureQueryData(crewByIdQuery(params.crewId));
    context.queryClient.ensureQueryData(jobsQuery);
    context.queryClient.ensureQueryData(staffQuery);
    context.queryClient.ensureQueryData(schedulesQuery);
  },
  component: CrewDetailPage,
  errorComponent: ({ error }) => (
    <div className="p-8 text-sm text-critical">Failed to load crew: {error.message}</div>
  ),
});

function CrewDetailPage() {
  const { crewId } = Route.useParams();
  const router = useRouter();
  const { data: crew } = useSuspenseQuery(crewByIdQuery(crewId));
  const { data: jobs } = useSuspenseQuery(jobsQuery);
  const { data: staff } = useSuspenseQuery(staffQuery);
  const { data: schedules } = useSuspenseQuery(schedulesQuery);

  if (!crew) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" onClick={() => router.history.back()} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
        <Card>
          <CardContent className="p-10 text-center">
            <Users className="h-10 w-10 mx-auto text-muted-foreground/40 mb-3" />
            <div className="font-semibold">Crew not found</div>
            <p className="text-sm text-muted-foreground mt-1">
              No crew with id <span className="font-mono">{crewId}</span> exists in the database yet.
            </p>
            <Link to="/crews" className="inline-block mt-4">
              <Button variant="outline">Back to all crews</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const members = staff.filter((s) => s.crew_id === crew.id);
  const crewJobs = jobs.filter((j) => j.assigned_crew_id === crew.id);
  const crewSchedules = schedules.filter((s) => s.crew_id === crew.id);
  const booked = crewSchedules.reduce((s, x) => s + Number(x.planned_hours ?? 0), 0);
  const pct = crew.weekly_capacity_hours > 0 ? Math.round((booked / crew.weekly_capacity_hours) * 100) : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <Button variant="ghost" size="sm" onClick={() => router.history.back()} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
        <Link to="/capacity"><Button variant="outline" size="sm">Open in calendar</Button></Link>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle className="text-xl">{crew.name}</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">{crew.crew_type ?? "Crew"} · {members.length} members</p>
            </div>
            <Badge variant="outline" className="text-xs">{crew.status}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid sm:grid-cols-3 gap-3">
            <Stat label="Weekly capacity" value={`${crew.weekly_capacity_hours}h`} />
            <Stat label="Booked" value={`${booked}h`} />
            <Stat label="Utilization" value={`${pct}%`} tone={pct > 100 ? "critical" : pct >= 90 ? "warning" : "ok"} />
          </div>
          <div>
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>Load</span><span className="font-semibold">{pct}%</span>
            </div>
            <Progress value={Math.min(pct, 100)} className="h-2" />
          </div>
          {crew.notes && <p className="text-sm text-muted-foreground border-t border-border pt-3">{crew.notes}</p>}
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Members</CardTitle></CardHeader>
          <CardContent className="p-0">
            {members.length === 0 && <div className="p-6 text-sm text-muted-foreground">No members assigned.</div>}
            <Table>
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Role</TableHead><TableHead className="text-right">Hrs/wk</TableHead></TableRow></TableHeader>
              <TableBody>
                {members.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell>
                      <Link to="/staff/$staffId" params={{ staffId: m.id }} className="font-medium hover:underline">{m.full_name}</Link>
                    </TableCell>
                    <TableCell className="text-sm">{m.role}</TableCell>
                    <TableCell className="text-right tabular-nums">{m.normal_hours_per_week}h</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Assigned jobs</CardTitle></CardHeader>
          <CardContent className="p-0">
            {crewJobs.length === 0 && <div className="p-6 text-sm text-muted-foreground">No jobs currently assigned.</div>}
            <Table>
              <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Job</TableHead><TableHead className="text-right">Progress</TableHead></TableRow></TableHeader>
              <TableBody>
                {crewJobs.map((j) => (
                  <TableRow key={j.id}>
                    <TableCell className="font-mono text-xs">
                      <Link to="/jobs/$jobId" params={{ jobId: j.job_code }} className="hover:underline">{j.job_code}</Link>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium text-sm">{j.job_name}</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" /> {j.location ?? "—"}</div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-sm">{j.completion_percentage}%</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "ok" | "warning" | "critical" }) {
  const toneCls = tone === "critical" ? "text-critical" : tone === "warning" ? "text-warning-foreground" : "";
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground flex items-center gap-1.5"><Briefcase className="h-3 w-3" /> {label}</div>
      <div className={`text-xl font-bold mt-0.5 ${toneCls}`}>{value}</div>
    </div>
  );
}
