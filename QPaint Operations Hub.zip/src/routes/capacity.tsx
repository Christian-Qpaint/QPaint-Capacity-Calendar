/**
 * Capacity Calendar — Gantt-style crew board (Tom's Planner inspired)
 * ----------------------------------------------------------------------------
 * Each schedule is a multi-day bar that spans `scheduled_date → end_date`.
 *
 *  • Drag the body of a bar to MOVE it (date + crew change). Autosaves.
 *  • Drag the LEFT edge  → shortens/extends the start (scheduled_date).
 *  • Drag the RIGHT edge → shortens/extends the end (end_date).
 *  • Every commit shows a toast + a "Saved HH:MM:SS" flash in the header.
 *  • Optimistic React-Query cache updates, rollback on error.
 *
 * Views: Day | Week | Month. Month keeps a compact day-cell grid for overview.
 */
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  useMemo, useState, useRef, useCallback, useEffect,
  type DragEvent, type PointerEvent as ReactPointerEvent,
} from "react";
import { useSuspenseQuery, useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  AlertTriangle, CalendarPlus, ChevronLeft, ChevronRight, GripVertical, Save, Palette, Check,
} from "lucide-react";
import { AddScheduleModal } from "@/components/modals";
import {
  schedulesQuery, jobsQuery, crewsQuery,
  createSchedule, updateSchedule, updateCrew,
  allContractorAssignmentsQuery,
  type ScheduleRow, type JobRow, type CrewRow,
} from "@/lib/db";
import { log } from "@/lib/log";
import { RequireRole, ACCESS } from "@/components/RequireRole";

/* -------------------------- color palette -------------------------- */

const COLOR_KEYS = ["blue","violet","emerald","amber","rose","cyan","pink","slate","indigo","teal"] as const;
type ColorKey = typeof COLOR_KEYS[number];

const GRADIENTS: Record<ColorKey, { from: string; to: string; ring: string; label: string }> = {
  blue:    { from: "#60a5fa", to: "#1d4ed8", ring: "#3b82f6", label: "Blue" },
  violet:  { from: "#a78bfa", to: "#6d28d9", ring: "#8b5cf6", label: "Violet" },
  emerald: { from: "#34d399", to: "#047857", ring: "#10b981", label: "Emerald" },
  amber:   { from: "#fbbf24", to: "#b45309", ring: "#f59e0b", label: "Amber" },
  rose:    { from: "#fb7185", to: "#9f1239", ring: "#f43f5e", label: "Rose" },
  cyan:    { from: "#22d3ee", to: "#155e75", ring: "#06b6d4", label: "Cyan" },
  pink:    { from: "#f472b6", to: "#9d174d", ring: "#ec4899", label: "Pink" },
  slate:   { from: "#94a3b8", to: "#1e293b", ring: "#64748b", label: "Slate" },
  indigo:  { from: "#818cf8", to: "#3730a3", ring: "#6366f1", label: "Indigo" },
  teal:    { from: "#5eead4", to: "#115e59", ring: "#14b8a6", label: "Teal" },
};

function hashKey(seed: string): ColorKey {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return COLOR_KEYS[h % COLOR_KEYS.length];
}
function resolveColorKey(raw: string | null | undefined, seed: string): ColorKey {
  if (raw && (COLOR_KEYS as readonly string[]).includes(raw)) return raw as ColorKey;
  return hashKey(seed);
}
function gradientStyle(key: ColorKey): React.CSSProperties {
  const g = GRADIENTS[key];
  return { background: `linear-gradient(135deg, ${g.from}, ${g.to})`, borderColor: g.ring, color: "#fff" };
}

function ColorPicker({ value, onChange, allowInherit, inheritLabel, tone = "light" }: {
  value: string | null; onChange: (v: string | null) => void;
  allowInherit?: boolean; inheritLabel?: string;
  tone?: "light" | "dark";
}) {
  const triggerClass = tone === "dark"
    ? "grid h-5 w-5 place-items-center rounded-full ring-1 ring-white/50 bg-black/20 hover:ring-white shadow-sm cursor-pointer"
    : "grid h-6 w-6 place-items-center rounded-full ring-1 ring-border bg-background hover:ring-foreground shadow-sm cursor-pointer";
  const iconClass = tone === "dark" ? "h-3 w-3 text-white" : "h-3.5 w-3.5 text-foreground";
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
          draggable={false}
          className={triggerClass}
          title="Change color"
        >
          <Palette className={iconClass} />
        </button>
      </PopoverTrigger>

      <PopoverContent className="w-56 p-3" onClick={(e) => e.stopPropagation()}>
        <div className="text-xs font-semibold mb-2">Pick a color</div>
        <div className="grid grid-cols-5 gap-2">
          {COLOR_KEYS.map((k) => {
            const selected = value === k;
            return (
              <button key={k} type="button" onClick={() => onChange(k)}
                className="relative h-8 w-8 rounded-md ring-1 ring-border hover:scale-110 transition-transform"
                style={{ background: `linear-gradient(135deg, ${GRADIENTS[k].from}, ${GRADIENTS[k].to})` }}
                title={GRADIENTS[k].label}>
                {selected && <Check className="absolute inset-0 m-auto h-4 w-4 text-white drop-shadow" />}
              </button>
            );
          })}
        </div>
        {allowInherit && (
          <button type="button" onClick={() => onChange(null)}
            className="mt-3 w-full text-xs rounded-md border border-border px-2 py-1 hover:bg-muted">
            {inheritLabel ?? "Use default"}
          </button>
        )}
      </PopoverContent>
    </Popover>
  );
}


export const Route = createFileRoute("/capacity")({
  head: () => ({
    meta: [
      { title: "Capacity Calendar · QPaint" },
      { name: "description", content: "Plan crews, drag-to-reschedule and resize bars to extend/shorten jobs." },
    ],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(schedulesQuery);
    context.queryClient.ensureQueryData(jobsQuery);
    context.queryClient.ensureQueryData(crewsQuery);
  },
  component: () => (
    <RequireRole roles={ACCESS.operations}>
      <CapacityPage />
    </RequireRole>
  ),
  pendingComponent: () => <CalendarSkeleton />,
  errorComponent: ({ error }) => (
    <div className="p-8 text-sm text-critical">Failed to load calendar: {error.message}</div>
  ),
});

/* -------------------------- skeleton -------------------------- */

function CalendarSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-2">
          <div className="h-6 w-56 animate-pulse rounded bg-muted" />
          <div className="h-4 w-80 animate-pulse rounded bg-muted/70" />
        </div>
        <div className="h-9 w-40 animate-pulse rounded bg-muted" />
      </div>
      <div className="h-14 animate-pulse rounded-lg bg-muted/60" />
      <div className="rounded-lg border border-border overflow-hidden">
        <div className="grid" style={{ gridTemplateColumns: `200px repeat(7, 1fr)` }}>
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={`h-${i}`} className="h-10 border-b border-r border-border bg-muted/40" />
          ))}
          {Array.from({ length: 5 }).map((_, r) => (
            <div key={`r-${r}`} className="contents">
              <div className="h-16 border-b border-r border-border bg-muted/20 p-3">
                <div className="h-4 w-24 animate-pulse rounded bg-muted" />
                <div className="mt-2 h-3 w-16 animate-pulse rounded bg-muted/70" />
              </div>
              {Array.from({ length: 7 }).map((_, c) => (
                <div key={`c-${r}-${c}`} className="h-16 border-b border-r border-border p-2">
                  {((r + c) % 3 === 0) && (
                    <div className="h-10 w-full animate-pulse rounded-md bg-primary/15" />
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* -------------------------- date helpers -------------------------- */

const DAY_MS = 86_400_000;
const LABEL_COL = 200; // px reserved for the crew label column
function toISO(d: Date): string {
  // Use local date parts — toISOString() would shift dates for users in positive UTC offsets,
  // causing drag-drops to land one day earlier than the drop target.
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}
function parseISO(s: string): Date { const [y, m, dd] = s.split("-").map(Number); return new Date(y, m - 1, dd); }
function startOfWeek(d: Date): Date {
  const day = d.getDay();
  const offset = day === 0 ? -6 : 1 - day;
  const r = new Date(d); r.setDate(d.getDate() + offset); r.setHours(0, 0, 0, 0);
  return r;
}
function startOfMonth(d: Date): Date { return new Date(d.getFullYear(), d.getMonth(), 1); }
function addDays(d: Date, n: number): Date { return new Date(d.getTime() + n * DAY_MS); }
function diffDays(a: Date, b: Date): number { return Math.round((b.getTime() - a.getTime()) / DAY_MS); }
function shortDate(d: Date) { return d.toLocaleDateString(undefined, { month: "short", day: "numeric" }); }
function dayLabel(d: Date) { return d.toLocaleDateString(undefined, { weekday: "short" }); }

type View = "day" | "week" | "month";

function rangeForView(anchor: Date, view: View): Date[] {
  if (view === "day") return [new Date(anchor.getFullYear(), anchor.getMonth(), anchor.getDate())];
  if (view === "week") return Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(anchor), i));
  const first = startOfMonth(anchor);
  return Array.from({ length: 42 }, (_, i) => addDays(startOfWeek(first), i));
}
function navStep(anchor: Date, view: View, dir: 1 | -1): Date {
  if (view === "day") return addDays(anchor, dir);
  if (view === "week") return addDays(anchor, 7 * dir);
  return new Date(anchor.getFullYear(), anchor.getMonth() + dir, 1);
}
function headerLabel(anchor: Date, view: View) {
  if (view === "day") return anchor.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });
  if (view === "week") {
    const s = startOfWeek(anchor); const e = addDays(s, 6);
    return `${shortDate(s)} – ${shortDate(e)}`;
  }
  return anchor.toLocaleDateString(undefined, { month: "long", year: "numeric" });
}

/* -------------------------- page -------------------------- */

const ALL = "__all";

function CapacityPage() {
  const { data: schedules } = useSuspenseQuery(schedulesQuery);
  const { data: jobs } = useSuspenseQuery(jobsQuery);
  const { data: crews } = useSuspenseQuery(crewsQuery);
  const qc = useQueryClient();

  const [view, setView] = useState<View>("week");
  const [anchor, setAnchor] = useState<Date>(new Date());
  const [crewFilter, setCrewFilter] = useState<string>(ALL);
  const [statusFilter, setStatusFilter] = useState<string>(ALL);
  const [savedFlash, setSavedFlash] = useState<string | null>(null);

  const jobsById = useMemo(() => Object.fromEntries(jobs.map((j) => [j.id, j])), [jobs]);
  const days = useMemo(() => rangeForView(anchor, view), [anchor, view]);
  const visibleCrews = useMemo(
    () => crews.filter((c) => crewFilter === ALL || c.id === crewFilter),
    [crews, crewFilter],
  );

  const flashSaved = useCallback(() => setSavedFlash(new Date().toLocaleTimeString()), []);

  /* ---------- mutation: any patch to a schedule ---------- */
  const patchMutation = useMutation({
    mutationFn: (args: { id: string; patch: Partial<ScheduleRow> }) =>
      updateSchedule(args.id, args.patch as never),
    onMutate: async (args) => {
      await qc.cancelQueries({ queryKey: ["schedules"] });
      const prev = qc.getQueryData<ScheduleRow[]>(["schedules"]);
      qc.setQueryData<ScheduleRow[]>(["schedules"], (old) =>
        (old ?? []).map((s) => (s.id === args.id ? { ...s, ...args.patch } : s)),
      );
      return { prev };
    },
    onError: (err, _a, ctx) => {
      log.error("schedule:patch", err);
      if (ctx?.prev) qc.setQueryData(["schedules"], ctx.prev);
      toast.error("Could not save — reverted.");
    },
    onSuccess: () => { flashSaved(); toast.success("Schedule saved", { description: "Change saved automatically." }); },
  });

  const addMutation = useMutation({
    mutationFn: createSchedule,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["schedules"] }); toast.success("Schedule added"); },
    onError: (e) => { log.error("schedule:create", e); toast.error("Could not add schedule"); },
  });

  const crewColorMutation = useMutation({
    mutationFn: (args: { id: string; color: string | null }) => updateCrew(args.id, { color: args.color }),
    onMutate: async (args) => {
      await qc.cancelQueries({ queryKey: ["crews"] });
      const prev = qc.getQueryData<CrewRow[]>(["crews"]);
      qc.setQueryData<CrewRow[]>(["crews"], (old) =>
        (old ?? []).map((c) => (c.id === args.id ? { ...c, color: args.color } : c)));
      return { prev };
    },
    onError: (e, _a, ctx) => { log.error("crew:color", e); if (ctx?.prev) qc.setQueryData(["crews"], ctx.prev); toast.error("Could not save crew color"); },
    onSuccess: () => { flashSaved(); toast.success("Crew color updated"); },
  });


  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">Capacity Calendar</h2>
          <p className="text-sm text-muted-foreground">
            Drag a bar to move it. Drag the left/right edges to extend or shorten. Changes save automatically.
            {savedFlash && (
              <span className="ml-2 inline-flex items-center gap-1 text-success">
                <Save className="h-3 w-3" /> Saved {savedFlash}
              </span>
            )}
          </p>
        </div>
        <ContractorHoursChip />
        <div className="hidden" aria-hidden>{/* spacer to keep layout */}</div>

        <AddScheduleModal
          trigger={<Button className="gap-1.5"><CalendarPlus className="h-4 w-4" /> Add schedule item</Button>}
          defaultDate={toISO(anchor)}
          jobOptions={jobs.map((j) => ({
            value: j.id,
            label: `${j.job_code} · ${j.job_name}`,
            estimatedHours: j.estimated_hours,
          }))}
          crewOptions={crews.map((c) => c.name)}
          onSave={async (v) => {
            const job = jobs.find((j) => j.id === v.job);
            const crew = crews.find((c) => c.name === v.crew);
            if (!job) { toast.error("Job not found"); return; }
            await addMutation.mutateAsync({
              jobId: job.id, crewId: crew?.id ?? null,
              date: v.startDate, endDate: v.endDate,
              startTime: v.startTime, endTime: v.endTime,
              plannedHours: Number(v.plannedHours), notes: v.notes ?? null,
            });
          }}
        />
      </div>

      {/* Toolbar */}
      <Card>
        <CardContent className="p-3 flex flex-wrap items-center gap-3">
          <div className="inline-flex rounded-lg border border-border p-0.5 bg-muted/40">
            {(["day", "week", "month"] as const).map((v) => (
              <button key={v} onClick={() => setView(v)}
                className={`px-3 py-1 text-xs font-medium rounded-md capitalize transition-colors ${
                  view === v ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                }`}>{v}</button>
            ))}
          </div>

          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setAnchor(navStep(anchor, view, -1))}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" className="h-8" onClick={() => setAnchor(new Date())}>Today</Button>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setAnchor(navStep(anchor, view, 1))}>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <div className="ml-2 text-sm font-semibold">{headerLabel(anchor, view)}</div>
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <Select value={crewFilter} onValueChange={setCrewFilter}>
              <SelectTrigger className="h-8 w-44"><SelectValue placeholder="All crews" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>All crews</SelectItem>
                {crews.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-8 w-44"><SelectValue placeholder="All statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>All statuses</SelectItem>
                {["Planned","Scheduled","In Progress","Delayed","On Hold","Completed"].map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {view === "month"
        ? <MonthGrid days={days} schedules={schedules} jobsById={jobsById}
            statusFilter={statusFilter} onPatch={(id, patch) => patchMutation.mutate({ id, patch })} />
        : <GanttBoard days={days} crews={visibleCrews} schedules={schedules}
            jobsById={jobsById} statusFilter={statusFilter}
            onPatch={(id, patch) => patchMutation.mutate({ id, patch })}
            onCrewColor={(id, color) => crewColorMutation.mutate({ id, color })} />
      }

    </div>
  );
}

/* -------------------------- Gantt board (day & week views) -------------------------- */

type PatchFn = (id: string, patch: Partial<ScheduleRow>) => void;

function GanttBoard(props: {
  days: Date[]; crews: CrewRow[]; schedules: ScheduleRow[];
  jobsById: Record<string, JobRow>; statusFilter: string;
  onPatch: PatchFn;
  onCrewColor: (id: string, color: string | null) => void;
}) {
  const { days, crews, schedules, jobsById, statusFilter, onPatch, onCrewColor } = props;
  const cols = `${LABEL_COL}px repeat(${days.length}, minmax(140px, 1fr))`;
  const todayKey = toISO(new Date());
  const firstDay = days[0];
  const lastDay = days[days.length - 1];

  // Filter & clip schedules to the visible range.
  const visible = useMemo(() => schedules.filter((s) => {
    if (statusFilter !== ALL && s.status !== statusFilter) return false;
    const start = parseISO(s.scheduled_date);
    const end = parseISO(s.end_date ?? s.scheduled_date);
    return end >= firstDay && start <= lastDay;
  }), [schedules, statusFilter, firstDay, lastDay]);

  return (
    <Card>
      <CardContent className="p-0 overflow-x-auto">
        <div className="min-w-full">
          {/* header */}
          <div className="grid border-b border-border bg-muted/40 sticky top-0 z-10" style={{ gridTemplateColumns: cols }}>
            <div className="px-4 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Crew / Day</div>
            {days.map((d) => (
              <div key={toISO(d)} className={`px-2 py-2 text-center border-l border-border ${toISO(d) === todayKey ? "bg-accent/15" : ""}`}>
                <div className="text-xs font-semibold">{dayLabel(d)}</div>
                <div className="text-[11px] text-muted-foreground">{shortDate(d)}</div>
              </div>
            ))}
          </div>

          {crews.length === 0 && <div className="p-8 text-sm text-muted-foreground text-center">No crews to display.</div>}

          {crews.map((c) => (
            <GanttRow key={c.id} crew={c} days={days}
              schedules={visible.filter((s) => s.crew_id === c.id)}
              jobsById={jobsById} cols={cols} onPatch={onPatch} onCrewColor={onCrewColor} />
          ))}

          {/* Unassigned bucket */}
          {visible.some((s) => !s.crew_id) && (
            <GanttRow crew={{ id: "__unassigned", name: "Unassigned", weekly_capacity_hours: 0, color: null } as CrewRow}
              days={days} schedules={visible.filter((s) => !s.crew_id)}
              jobsById={jobsById} cols={cols} onPatch={onPatch} onCrewColor={onCrewColor} unassigned />
          )}
        </div>

        <div className="flex flex-wrap gap-4 px-4 py-3 border-t border-border text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1"><GripVertical className="h-3 w-3" /> Drag bar to move</span>
          <span>·</span><span>Drag bar edges to resize</span>
          <span>·</span><span>Click the palette icon to change colors</span>
          <span>·</span><span>Changes save automatically</span>
        </div>
      </CardContent>
    </Card>
  );
}


/* -------------------------- single crew Gantt row -------------------------- */

type BarLayout = { row: number; startCol: number; span: number; schedule: ScheduleRow };

function packRows(items: { startCol: number; span: number }[]): number[] {
  // Greedy: assign each item to the lowest row whose last bar ends before this bar starts.
  const rowEnds: number[] = [];
  return items.map((it) => {
    for (let r = 0; r < rowEnds.length; r++) {
      if (rowEnds[r] <= it.startCol) { rowEnds[r] = it.startCol + it.span; return r; }
    }
    rowEnds.push(it.startCol + it.span);
    return rowEnds.length - 1;
  });
}

function GanttRow(props: {
  crew: CrewRow; days: Date[]; schedules: ScheduleRow[];
  jobsById: Record<string, JobRow>; cols: string; onPatch: PatchFn;
  onCrewColor: (id: string, color: string | null) => void;
  unassigned?: boolean;
}) {
  const { crew, days, schedules, jobsById, cols, onPatch, onCrewColor, unassigned } = props;
  const stripRef = useRef<HTMLDivElement | null>(null);
  const firstDay = days[0];
  const dayCount = days.length;
  const dailyCap = unassigned ? 0 : Math.round(crew.weekly_capacity_hours / 5);

  const crewColorKey = resolveColorKey(unassigned ? "slate" : crew.color, crew.id || crew.name);

  // Compute clipped bar positions inside the visible window.
  const sorted = useMemo(() => [...schedules].sort((a, b) => a.scheduled_date.localeCompare(b.scheduled_date)),
    [schedules]);
  const positions = useMemo(() => sorted.map((s) => {
    const start = parseISO(s.scheduled_date);
    const end = parseISO(s.end_date ?? s.scheduled_date);
    const startCol = Math.max(0, diffDays(firstDay, start));
    const endCol = Math.min(dayCount - 1, diffDays(firstDay, end));
    return { startCol, span: Math.max(1, endCol - startCol + 1) };
  }), [sorted, firstDay, dayCount]);
  const rowIdx = useMemo(() => packRows(positions), [positions]);
  const bars: BarLayout[] = sorted.map((s, i) => ({ ...positions[i], row: rowIdx[i], schedule: s }));
  const stripRows = Math.max(1, (rowIdx[rowIdx.length - 1] ?? 0) + 1);

  /* ---- compute target day index from pointer X relative to strip ---- */
  const dayFromClientX = useCallback((clientX: number): number => {
    const el = stripRef.current; if (!el) return 0;
    const rect = el.getBoundingClientRect();
    const cellW = rect.width / dayCount;
    return Math.max(0, Math.min(dayCount - 1, Math.floor((clientX - rect.left) / cellW)));
  }, [dayCount]);

  /* ---- drag ghost state: highlight target cells while dragging over ---- */
  const [ghost, setGhost] = useState<{ startCol: number; span: number } | null>(null);

  /* ---- HTML5 drag handlers (move) ---- */
  const onBarDragStart = (e: DragEvent<HTMLDivElement>, s: ScheduleRow) => {
    const grabDayIdx = dayFromClientX(e.clientX) - Math.max(0, diffDays(firstDay, parseISO(s.scheduled_date)));
    const span = Math.max(1, diffDays(parseISO(s.scheduled_date), parseISO(s.end_date ?? s.scheduled_date)) + 1);
    const payload = { id: s.id, grabDayIdx, span, originCrew: s.crew_id ?? null };
    e.dataTransfer.setData("application/x-schedule", JSON.stringify(payload));
    e.dataTransfer.effectAllowed = "move";
    // module-level mirror so dragover (which can't read dataTransfer) can position the ghost
    activeDrag = payload;

    // Build a translucent ghost element from the bar
    const node = e.currentTarget as HTMLElement;
    const clone = node.cloneNode(true) as HTMLElement;
    const rect = node.getBoundingClientRect();
    clone.style.position = "absolute";
    clone.style.top = "-9999px";
    clone.style.left = "-9999px";
    clone.style.width = `${rect.width}px`;
    clone.style.height = `${rect.height}px`;
    clone.style.opacity = "0.85";
    clone.style.pointerEvents = "none";
    clone.style.transform = "rotate(-1deg)";
    clone.style.boxShadow = "0 12px 28px rgba(0,0,0,0.35)";
    document.body.appendChild(clone);
    try { e.dataTransfer.setDragImage(clone, e.clientX - rect.left, e.clientY - rect.top); } catch {}
    setTimeout(() => clone.remove(), 0);
  };
  const onBarDragEnd = () => { activeDrag = null; setGhost(null); };

  const onStripDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault(); e.dataTransfer.dropEffect = "move";
    if (!activeDrag) return;
    const targetDayIdx = dayFromClientX(e.clientX) - activeDrag.grabDayIdx;
    const start = Math.max(0, Math.min(dayCount - 1, targetDayIdx));
    const span = Math.max(1, Math.min(activeDrag.span, dayCount - start));
    setGhost({ startCol: start, span });
  };
  const onStripDragLeave = () => { setGhost(null); };

  const onStripDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setGhost(null);
    const raw = e.dataTransfer.getData("application/x-schedule"); if (!raw) { activeDrag = null; return; }
    const { id, grabDayIdx, span } = JSON.parse(raw) as { id: string; grabDayIdx: number; span: number; originCrew: string | null };
    const targetDayIdx = dayFromClientX(e.clientX) - grabDayIdx;
    const newStart = addDays(firstDay, Math.max(0, Math.min(dayCount - 1, targetDayIdx)));
    const durationDays = Math.max(0, span - 1);
    const patch: Partial<ScheduleRow> = {
      scheduled_date: toISO(newStart),
      end_date: toISO(addDays(newStart, durationDays)),
      crew_id: unassigned ? null : crew.id,
    };
    activeDrag = null;
    onPatch(id, patch);
  };

  /* ---- pointer-based resize handles ---- */
  const [resizing, setResizing] = useState<{ id: string; side: "left" | "right"; previewStart: string; previewEnd: string } | null>(null);

  const beginResize = (e: ReactPointerEvent<HTMLDivElement>, s: ScheduleRow, side: "left" | "right") => {
    e.stopPropagation(); e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setResizing({ id: s.id, side, previewStart: s.scheduled_date, previewEnd: s.end_date ?? s.scheduled_date });
  };
  const moveResize = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!resizing) return;
    const dayIdx = dayFromClientX(e.clientX);
    const target = toISO(addDays(firstDay, dayIdx));
    setResizing((r) => {
      if (!r) return r;
      if (r.side === "left") {
        return { ...r, previewStart: target <= r.previewEnd ? target : r.previewEnd };
      }
      return { ...r, previewEnd: target >= r.previewStart ? target : r.previewStart };
    });
  };
  const endResize = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!resizing) return;
    (e.currentTarget as HTMLElement).releasePointerCapture?.(e.pointerId);
    const orig = sorted.find((x) => x.id === resizing.id);
    if (orig && (orig.scheduled_date !== resizing.previewStart || (orig.end_date ?? orig.scheduled_date) !== resizing.previewEnd)) {
      onPatch(resizing.id, { scheduled_date: resizing.previewStart, end_date: resizing.previewEnd });
    }
    setResizing(null);
  };

  // booked hours per day for the capacity strip
  const bookedPerDay = useMemo(() => {
    const arr = new Array(dayCount).fill(0);
    for (const s of schedules) {
      const start = Math.max(0, diffDays(firstDay, parseISO(s.scheduled_date)));
      const end = Math.min(dayCount - 1, diffDays(firstDay, parseISO(s.end_date ?? s.scheduled_date)));
      const span = Math.max(1, end - start + 1);
      const per = Number(s.planned_hours ?? 0) / span;
      for (let i = start; i <= end; i++) arr[i] += per;
    }
    return arr;
  }, [schedules, firstDay, dayCount]);

  const crewSwatch = GRADIENTS[crewColorKey];

  return (
    <div className="border-b border-border last:border-0">
      <div className="grid" style={{ gridTemplateColumns: cols }}>
        {/* crew label */}
        <div className="px-4 py-3 border-r border-border bg-muted/10 flex items-center gap-2">
          <span className="h-6 w-1.5 rounded-full shrink-0"
            style={{ background: `linear-gradient(180deg, ${crewSwatch.from}, ${crewSwatch.to})` }} />
          <div className="min-w-0 flex-1">
            {unassigned ? (
              <span className="text-sm font-semibold text-muted-foreground italic">Unassigned</span>
            ) : (
              <Link to="/crews/$crewId" params={{ crewId: crew.id }} className="text-sm font-semibold hover:underline block truncate">
                {crew.name}
              </Link>
            )}
            {!unassigned && <div className="text-[11px] text-muted-foreground">{crew.weekly_capacity_hours}h / wk</div>}
          </div>
          {!unassigned && (
            <ColorPicker
              value={crew.color}
              onChange={(v) => onCrewColor(crew.id, v)}
              allowInherit
              inheritLabel="Auto color"
            />
          )}
        </div>

        {/* gantt strip — drop target spanning all day columns */}
        <div
          ref={stripRef}
          className="relative"
          style={{ gridColumn: `2 / span ${dayCount}` }}
          onDragOver={onStripDragOver}
          onDragLeave={onStripDragLeave}
          onDrop={onStripDrop}
          onPointerMove={moveResize}
          onPointerUp={endResize}
          onPointerCancel={endResize}
        >
          {/* day grid background */}
          <div className="absolute inset-0 grid pointer-events-none" style={{ gridTemplateColumns: `repeat(${dayCount}, 1fr)` }}>
            {days.map((d, i) => {
              const weekend = [0, 6].includes(d.getDay());
              const isToday = toISO(d) === toISO(new Date());
              return (
                <div key={i} className={`border-l border-border ${weekend ? "bg-muted/20" : ""} ${isToday ? "bg-accent/10" : ""}`} />
              );
            })}
          </div>

          {/* drag ghost — shows where the bar will land */}
          {ghost && (
            <div
              className="absolute pointer-events-none rounded-md border-2 border-dashed z-20 animate-pulse"
              style={{
                top: 6, bottom: 6,
                left: `${(ghost.startCol / dayCount) * 100}%`,
                width: `${(ghost.span / dayCount) * 100}%`,
                background: `linear-gradient(135deg, ${crewSwatch.from}40, ${crewSwatch.to}40)`,
                borderColor: crewSwatch.ring,
              }}
            />
          )}

          {/* bars */}
          <div className="relative grid gap-1 p-1.5" style={{
            gridTemplateColumns: `repeat(${dayCount}, 1fr)`,
            gridAutoRows: "44px",
            minHeight: stripRows * 44 + 12,
          }}>
            {bars.map(({ schedule, row, startCol, span }) => {
              const live = resizing && resizing.id === schedule.id
                ? { ...schedule, scheduled_date: resizing.previewStart, end_date: resizing.previewEnd }
                : schedule;
              const liveStartCol = Math.max(0, diffDays(firstDay, parseISO(live.scheduled_date)));
              const liveEndCol = Math.min(dayCount - 1, diffDays(firstDay, parseISO(live.end_date ?? live.scheduled_date)));
              const liveSpan = Math.max(1, liveEndCol - liveStartCol + 1);
              return (
                <ScheduleBar key={schedule.id}
                  schedule={live} job={jobsById[schedule.job_id]}
                  colorKey={resolveColorKey(schedule.color, schedule.id) }
                  inheritedKey={crewColorKey}
                  row={row} startCol={resizing?.id === schedule.id ? liveStartCol : startCol}
                  span={resizing?.id === schedule.id ? liveSpan : span}
                  isResizing={resizing?.id === schedule.id}
                  onDragStart={(e) => onBarDragStart(e, schedule)}
                  onDragEnd={onBarDragEnd}
                  onResizeStart={(e, side) => beginResize(e, schedule, side)}
                  onColorChange={(v) => onPatch(schedule.id, { color: v })}
                />
              );
            })}
          </div>
        </div>
      </div>

      {/* capacity strip */}
      {!unassigned && (
        <div className="grid bg-muted/5 border-t border-border/60" style={{ gridTemplateColumns: cols }}>
          <div className="px-4 py-1.5 text-[10px] uppercase tracking-wide text-muted-foreground font-semibold">Capacity</div>
          {days.map((d, i) => {
            const weekend = [0, 6].includes(d.getDay());
            const cap = weekend ? Math.round(dailyCap * 0.4) : dailyCap;
            const booked = Math.round(bookedPerDay[i] * 10) / 10;
            const pct = cap === 0 ? 0 : Math.min((booked / cap) * 100, 100);
            const over = booked > cap;
            return (
              <div key={i} className="px-2 py-1.5 border-l border-border">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="tabular-nums">{booked}/{cap}h</span>
                  <span className={`px-1 rounded text-[9px] font-semibold ${
                    over ? "bg-critical/20 text-critical" :
                    pct >= 90 ? "bg-warning/30 text-warning-foreground" :
                    "bg-success/15 text-success"
                  }`}>{over ? "Over" : pct >= 90 ? "Full" : "OK"}</span>
                </div>
                <div className="mt-1 h-1 rounded-full bg-muted overflow-hidden">
                  <div className={`h-full ${over ? "bg-critical" : pct >= 90 ? "bg-warning" : "bg-success"}`} style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Module-level mirror of the active drag payload so dragover (which has no
// access to dataTransfer) can position the live ghost.
let activeDrag: { id: string; grabDayIdx: number; span: number; originCrew: string | null } | null = null;


/* -------------------------- bar -------------------------- */

function ScheduleBar(props: {
  schedule: ScheduleRow; job: JobRow | undefined;
  colorKey: ColorKey;
  inheritedKey: ColorKey;
  row: number; startCol: number; span: number; isResizing: boolean;
  onDragStart: (e: DragEvent<HTMLDivElement>) => void;
  onDragEnd: () => void;
  onResizeStart: (e: ReactPointerEvent<HTMLDivElement>, side: "left" | "right") => void;
  onColorChange: (v: string | null) => void;
}) {
  const { schedule, job, colorKey, inheritedKey, row, startCol, span, isResizing,
    onDragStart, onDragEnd, onResizeStart, onColorChange } = props;

  // If the bar has its own color, use it; otherwise fall back to the crew color.
  const effectiveKey: ColorKey = schedule.color ? colorKey : inheritedKey;
  const g = GRADIENTS[effectiveKey];

  const statusRing =
    schedule.status === "Delayed" ? "ring-warning" :
    schedule.status === "Completed" ? "ring-success" :
    schedule.status === "On Hold" ? "ring-muted-foreground" :
    "ring-white/40";

  const navigate = useNavigate();

  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onClick={(e) => {
        // Allow the resize handles / color picker to swallow their own clicks.
        if ((e.target as HTMLElement).closest("[data-bar-noclick]")) return;
        if (job) navigate({ to: "/jobs/$jobId", params: { jobId: job.job_code } });
      }}
      style={{
        gridColumn: `${startCol + 1} / span ${span}`,
        gridRow: row + 1,
        background: `linear-gradient(135deg, ${g.from}, ${g.to})`,
        borderColor: g.ring,
        color: "#fff",
      }}
      className={`group relative rounded-md border px-2 py-1 text-left shadow-sm
        cursor-pointer active:cursor-grabbing transition-all min-w-0 overflow-hidden
        hover:brightness-110 ring-1 ${statusRing} ${isResizing ? "ring-2 ring-primary/80" : ""}`}
      title={job ? `${job.job_code} ${job.job_name}${job.contract_value ? ` · $${Number(job.contract_value).toLocaleString()} contract` : ""}` : "Unknown job"}
    >
      {/* left resize handle */}
      <div
        data-bar-noclick
        draggable={false}
        onPointerDown={(e) => onResizeStart(e, "left")}
        className="absolute left-0 top-0 bottom-0 w-1.5 cursor-ew-resize hover:bg-black/20 z-10"
      />
      {/* right resize handle */}
      <div
        data-bar-noclick
        draggable={false}
        onPointerDown={(e) => onResizeStart(e, "right")}
        className="absolute right-0 top-0 bottom-0 w-1.5 cursor-ew-resize hover:bg-black/20 z-10"
      />

      <div className="flex items-center gap-1 min-w-0">
        <GripVertical className="h-3 w-3 shrink-0 opacity-70" />
        <div className="min-w-0 flex-1">
          {job ? (
            <Link
              to="/jobs/$jobId" params={{ jobId: job.job_code }}
              draggable={false}
              onClick={(e) => e.stopPropagation()}
              className="block min-w-0"
            >
              <div className="text-[11px] font-semibold truncate leading-tight hover:underline">
                {job.job_code} · {job.job_name}
              </div>
              <div className="text-[10px] truncate opacity-95 leading-tight">
                {job.client_name} · {schedule.planned_hours}h
                {job.contract_value ? (
                  <span className="ml-1 rounded bg-white/20 px-1 py-px text-[9px] font-bold">
                    ${Number(job.contract_value) >= 1000 ? `${Math.round(Number(job.contract_value)/1000)}k` : Math.round(Number(job.contract_value))}
                  </span>
                ) : null}
                {job.source_deal_id && (
                  <Link
                    to="/crm/$dealId"
                    params={{ dealId: job.source_deal_id }}
                    draggable={false}
                    onClick={(e) => e.stopPropagation()}
                    className="ml-1 rounded bg-white/25 px-1 py-px text-[9px] font-bold uppercase tracking-wide hover:bg-white/40"
                    title="View source CRM deal"
                  >
                    Deal
                  </Link>
                )}
              </div>

            </Link>
          ) : (
            <div className="text-xs italic opacity-80">Unknown job</div>
          )}
        </div>
        <div className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
          data-bar-noclick
          onClick={(e) => { e.stopPropagation(); e.preventDefault(); }}
          onPointerDown={(e) => e.stopPropagation()}
          draggable={false}
        >
          <ColorPicker
            value={schedule.color}
            onChange={onColorChange}
            allowInherit
            inheritLabel="Use crew color"
            tone="dark"
          />
        </div>
      </div>
    </div>
  );
}


/* -------------------------- Month grid (overview) -------------------------- */

function MonthGrid(props: {
  days: Date[]; schedules: ScheduleRow[];
  jobsById: Record<string, JobRow>; statusFilter: string;
  onPatch: PatchFn;
}) {
  const { days, schedules, jobsById, statusFilter, onPatch } = props;
  const byDay = useMemo(() => {
    const m = new Map<string, ScheduleRow[]>();
    for (const s of schedules) {
      if (statusFilter !== ALL && s.status !== statusFilter) continue;
      const start = parseISO(s.scheduled_date);
      const end = parseISO(s.end_date ?? s.scheduled_date);
      for (let d = new Date(start); d <= end; d = addDays(d, 1)) {
        const k = toISO(d);
        const arr = m.get(k) ?? []; arr.push(s); m.set(k, arr);
      }
    }
    return m;
  }, [schedules, statusFilter]);

  const todayKey = toISO(new Date());
  const monthOf = days[15]?.getMonth();

  return (
    <Card>
      <CardContent className="p-0">
        <div className="grid grid-cols-7 border-b border-border bg-muted/40">
          {["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map((d) => (
            <div key={d} className="px-3 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground text-center">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {days.map((d) => {
            const k = toISO(d);
            const inMonth = d.getMonth() === monthOf;
            const items = byDay.get(k) ?? [];
            const totalHours = items.reduce((s, x) => s + Number(x.planned_hours ?? 0), 0);
            const isToday = k === todayKey;
            return (
              <div key={k}
                onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }}
                onDrop={(e) => {
                  e.preventDefault();
                  const raw = e.dataTransfer.getData("application/x-month-id"); if (!raw) return;
                  const s = schedules.find((x) => x.id === raw); if (!s) return;
                  const dur = diffDays(parseISO(s.scheduled_date), parseISO(s.end_date ?? s.scheduled_date));
                  onPatch(raw, { scheduled_date: k, end_date: toISO(addDays(parseISO(k), dur)) });
                }}
                className={`p-2 min-h-28 border-b border-r border-border ${inMonth ? "" : "opacity-50 bg-muted/10"} ${isToday ? "bg-accent/10" : ""}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-xs font-semibold ${isToday ? "text-accent-foreground" : ""}`}>{d.getDate()}</span>
                  {totalHours > 0 && <Badge variant="outline" className="text-[10px] h-4">{totalHours}h</Badge>}
                </div>
                <div className="space-y-1">
                  {items.slice(0, 3).map((s) => {
                    const job = jobsById[s.job_id];
                    return (
                      <div key={s.id} draggable
                        onDragStart={(e) => e.dataTransfer.setData("application/x-month-id", s.id)}
                        className="text-[10px] rounded bg-primary/15 text-primary border border-primary/30 px-1.5 py-0.5 truncate cursor-grab active:cursor-grabbing">
                        {job ? (
                          <Link to="/jobs/$jobId" params={{ jobId: job.job_code }} className="hover:underline" draggable={false}>
                            {job.job_code} {job.job_name}
                          </Link>
                        ) : "Unknown"}
                      </div>
                    );
                  })}
                  {items.length > 3 && <div className="text-[10px] text-muted-foreground">+{items.length - 3} more</div>}
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex items-center gap-2 px-4 py-3 text-xs text-muted-foreground border-t border-border">
          <AlertTriangle className="h-3 w-3" /> Use Day or Week view to resize bars by dragging their edges.
        </div>
      </CardContent>
    </Card>
  );
}

function ContractorHoursChip() {
  const { data = [] } = useQuery(allContractorAssignmentsQuery);
  const total = data.reduce((s, a) => s + Number(a.allocated_hours ?? 0), 0);
  if (total === 0) return null;
  return (
    <Badge variant="accent" className="gap-1.5 text-xs">
      <span className="opacity-70">Contractor hrs booked</span>
      <span className="font-semibold">{total}h</span>
    </Badge>
  );
}


// Avoid unused-import warnings if effect helper is removed.
void useEffect;
