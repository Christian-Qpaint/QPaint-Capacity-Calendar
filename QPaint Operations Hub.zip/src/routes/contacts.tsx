import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search, UserPlus, Mail, Phone } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { contactsQuery, createContact, type ContactRow } from "@/lib/db";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { PipedriveSyncButton } from "@/components/pipedrive-sync-button";
import { useQueryClient } from "@tanstack/react-query";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/contacts")({
  component: () => (
    <RequireRole roles={ACCESS.contacts}>
      <ContactsPage />
    </RequireRole>
  ),
  head: () => ({ meta: [{ title: "Contacts · QPaint" }] }),
  errorComponent: ({ error }) => (
    <div className="p-6 text-sm text-destructive">Failed to load contacts: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-6 text-sm">Not found</div>,
});

const fmtMoney = (v: number | null | undefined) =>
  v == null ? "—" : new Intl.NumberFormat("en-AU", { style: "currency", currency: "AUD", maximumFractionDigits: 0 }).format(Number(v));

function ContactsPage() {
  const { data: contacts = [], isLoading, refetch } = useQuery(contactsQuery);
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const router = useRouter();

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return contacts;
    return contacts.filter((c) =>
      [c.name, c.email, c.phone, c.address, c.company].some((v) => v?.toLowerCase().includes(t)),
    );
  }, [contacts, q]);

  const totals = useMemo(
    () => ({
      contacts: contacts.length,
      withDeals: contacts.filter((c) => c.total_deals > 0).length,
      withJobs: contacts.filter((c) => c.total_jobs > 0).length,
      lifetime: contacts.reduce((s, c) => s + Number(c.lifetime_value ?? 0), 0),
    }),
    [contacts],
  );

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Contacts</h1>
          <p className="text-sm text-muted-foreground">
            Master list of clients. Auto-created from every Deal and Job — same person never duplicated.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <PipedriveSyncButton
            mode="contacts"
            onDone={() => qc.invalidateQueries({ queryKey: ["contacts"] })}
          />
          <Button onClick={() => setOpen(true)} className="gap-1.5">
            <UserPlus className="h-4 w-4" /> Add Contact
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Total Contacts" value={totals.contacts.toString()} />
        <StatCard label="With Deals" value={totals.withDeals.toString()} />
        <StatCard label="With Jobs" value={totals.withJobs.toString()} />
        <StatCard label="Lifetime Value" value={fmtMoney(totals.lifetime)} />
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
          <CardTitle className="text-base">Directory</CardTitle>
          <div className="relative w-72 max-w-full">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search name, email, phone…"
              className="pl-8"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-sm text-muted-foreground">
              No contacts yet. Add one above, or create a Deal/Job — contacts auto-create.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-[11px] uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-4 py-2.5 text-left font-semibold">Name</th>
                    <th className="px-4 py-2.5 text-left font-semibold">Contact</th>
                    <th className="px-4 py-2.5 text-left font-semibold">Address</th>
                    <th className="px-4 py-2.5 text-right font-semibold">Deals</th>
                    <th className="px-4 py-2.5 text-right font-semibold">Jobs</th>
                    <th className="px-4 py-2.5 text-right font-semibold">Lifetime Value</th>
                    <th className="px-4 py-2.5 text-left font-semibold">Ranking</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((c) => (
                    <tr
                      key={c.id}
                      className="cursor-pointer border-t border-border/60 transition-colors hover:bg-muted/30"
                      onClick={() => router.navigate({ to: "/contacts/$contactId", params: { contactId: c.id } })}
                    >
                      <td className="px-4 py-2.5">
                        <Link
                          to="/contacts/$contactId"
                          params={{ contactId: c.id }}
                          className="font-medium text-foreground hover:text-primary"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {c.name}
                        </Link>
                        {c.company && <div className="text-[11px] text-muted-foreground">{c.company}</div>}
                      </td>
                      <td className="px-4 py-2.5 text-muted-foreground">
                        <div className="flex flex-col gap-0.5">
                          {c.email && (
                            <span className="inline-flex items-center gap-1.5 text-xs">
                              <Mail className="h-3 w-3" /> {c.email}
                            </span>
                          )}
                          {c.phone && (
                            <span className="inline-flex items-center gap-1.5 text-xs">
                              <Phone className="h-3 w-3" /> {c.phone}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-2.5 text-xs text-muted-foreground">{c.address ?? "—"}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">{c.total_deals}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">{c.total_jobs}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">{fmtMoney(c.lifetime_value)}</td>
                      <td className="px-4 py-2.5">
                        {c.ranking ? <Badge variant="outline">{c.ranking}</Badge> : <span className="text-muted-foreground">—</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="text-[11px] text-muted-foreground">
        API: <code className="rounded bg-muted px-1 py-0.5">GET /api/public/contacts</code> ·{" "}
        <code className="rounded bg-muted px-1 py-0.5">GET /api/public/contacts/$id</code>
      </div>

      <AddContactDialog
        open={open}
        onOpenChange={setOpen}
        onCreated={() => {
          refetch();
          toast.success("Contact created");
        }}
      />
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="mt-1 font-display text-2xl font-bold tabular-nums">{value}</div>
      </CardContent>
    </Card>
  );
}

function AddContactDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: () => void;
}) {
  const [form, setForm] = useState<Partial<ContactRow>>({});
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!form.name?.trim()) {
      toast.error("Name is required");
      return;
    }
    setBusy(true);
    try {
      await createContact({ name: form.name.trim(), ...form });
      onCreated();
      onOpenChange(false);
      setForm({});
    } catch (e) {
      toast.error("Failed to create contact", { description: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New contact</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Name *">
            <Input value={form.name ?? ""} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Email"><Input value={form.email ?? ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
            <Field label="Phone"><Input value={form.phone ?? ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          </div>
          <Field label="Address"><Input value={form.address ?? ""} onChange={(e) => setForm({ ...form, address: e.target.value })} /></Field>
          <Field label="Company"><Input value={form.company ?? ""} onChange={(e) => setForm({ ...form, company: e.target.value })} /></Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} disabled={busy}>{busy ? "Saving…" : "Create"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}


