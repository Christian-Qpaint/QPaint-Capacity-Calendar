import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { jobs, crews } from "@/lib/mock-data";
import {
  Download,
  FileText,
  Send,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Clock,
  DollarSign,
  Users,
  Activity,
} from "lucide-react";
import { capacityStatus, capacityTone } from "@/lib/capacity";
import { CapacityBadge } from "@/components/CapacityIndicator";
import { ProfitabilityReport } from "@/components/ProfitabilityReport";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Reports · QPaint" },
      {
        name: "description",
        content:
          "Operational reporting for admin, billing, and management: completed jobs, billing readiness, capacity utilization, and job progress.",
      },
    ],
  }),
  component: () => (
    <RequireRole roles={ACCESS.reports}>
      <ReportsPage />
    </RequireRole>
  ),
});

// ---------- derived mock data ----------
interface JobReport {
  id: string;
  client: string;
  name: string;
  crew: string;
  progress: number;
  hoursWorked: number;
  estimatedHours: number;
  milestone: string;
  billingStatus: "Not ready" | "Ready for invoice" | "Invoiced" | "Paid";
  adminNotes: string;
  planned: number;
  status: string;
}

const billingMap: Record<string, JobReport["billingStatus"]> = {
  "QP-1042": "Not ready",
  "QP-1043": "Not ready",
  "QP-1044": "Not ready",
  "QP-1045": "Not ready",
  "QP-1039": "Ready for invoice",
  "QP-1040": "Invoiced",
};

const milestoneMap: Record<string, string> = {
  "QP-1042": "2nd coat ext.",
  "QP-1043": "Site prep",
  "QP-1044": "Ceilings done",
  "QP-1045": "Awaiting access",
  "QP-1039": "Final handover",
  "QP-1040": "Closed out",
};

const notesMap: Record<string, string> = {
  "QP-1042": "Weather risk Fri",
  "QP-1043": "Materials confirmed",
  "QP-1044": "Variation pending",
  "QP-1045": "Client delay",
  "QP-1039": "Sign-off received",
  "QP-1040": "Invoice #INV-2208",
};

const jobReports: JobReport[] = jobs.map((j) => {
  const est = Math.round(j.value / 95);
  const worked = Math.round((est * j.progress) / 100);
  // planned % based on schedule elapsed
  const start = new Date(j.start).getTime();
  const end = new Date(j.end).getTime();
  const now = new Date("2026-06-24").getTime();
  const planned = Math.max(
    0,
    Math.min(100, Math.round(((now - start) / (end - start)) * 100)),
  );
  return {
    id: j.id,
    client: j.client,
    name: j.name,
    crew: j.crew,
    progress: j.progress,
    hoursWorked: worked,
    estimatedHours: est,
    milestone: milestoneMap[j.id] ?? "—",
    billingStatus: billingMap[j.id] ?? "Not ready",
    adminNotes: notesMap[j.id] ?? "",
    planned,
    status: j.status,
  };
});

interface CrewUtil {
  name: string;
  available: number;
  booked: number;
  overbooked: number;
  idle: number;
  utilization: number;
}

const crewUtil: CrewUtil[] = crews.map((c) => {
  const available = c.size * 38; // 38h/wk per painter
  const booked = Math.round((available * c.utilization) / 100);
  const overbooked = booked > available ? booked - available : 0;
  const idle = booked < available ? available - booked : 0;
  return {
    name: c.name,
    available,
    booked,
    overbooked,
    idle,
    utilization: c.utilization,
  };
});

// ---------- helpers ----------
function billingTone(s: JobReport["billingStatus"]) {
  switch (s) {
    case "Ready for invoice":
      return "bg-warning/15 text-warning border-warning/30";
    case "Invoiced":
      return "bg-primary/15 text-primary border-primary/30";
    case "Paid":
      return "bg-success/15 text-success border-success/30";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function utilTone(pct: number) {
  return capacityTone(capacityStatus(pct)).bar;
}

function diffBadge(diff: number) {
  if (diff > 5)
    return (
      <Badge variant="outline" className="bg-success/15 text-success border-success/30 gap-1">
        <TrendingUp className="h-3 w-3" /> +{diff}%
      </Badge>
    );
  if (diff < -5)
    return (
      <Badge variant="outline" className="bg-critical/15 text-critical border-critical/30 gap-1">
        <TrendingDown className="h-3 w-3" /> {diff}%
      </Badge>
    );
  return (
    <Badge variant="outline" className="bg-muted text-muted-foreground">
      {diff > 0 ? "+" : ""}
      {diff}%
    </Badge>
  );
}

// ---------- page ----------
function ReportsPage() {
  const [crewFilter, setCrewFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [billingFilter, setBillingFilter] = useState("all");
  const [clientFilter, setClientFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("2026-06-01");
  const [dateTo, setDateTo] = useState("2026-07-15");

  const clients = useMemo(
    () => Array.from(new Set(jobReports.map((j) => j.client))),
    [],
  );

  const filtered = useMemo(() => {
    return jobReports.filter((j) => {
      if (crewFilter !== "all" && j.crew !== crewFilter) return false;
      if (statusFilter !== "all" && j.status !== statusFilter) return false;
      if (billingFilter !== "all" && j.billingStatus !== billingFilter) return false;
      if (clientFilter !== "all" && j.client !== clientFilter) return false;
      return true;
    });
  }, [crewFilter, statusFilter, billingFilter, clientFilter]);

  // KPIs
  const completedCount = filtered.filter((j) => j.status === "Completed").length;
  const readyToInvoice = filtered.filter((j) => j.billingStatus === "Ready for invoice").length;
  const totalWorked = filtered.reduce((s, j) => s + j.hoursWorked, 0);
  const totalEstimated = filtered.reduce((s, j) => s + j.estimatedHours, 0);
  const avgCompletion = filtered.length
    ? Math.round(filtered.reduce((s, j) => s + j.progress, 0) / filtered.length)
    : 0;
  const delayedCount = filtered.filter((j) => j.progress - j.planned < -5).length;
  const totalAvailable = crewUtil.reduce((s, c) => s + c.available, 0);
  const totalBooked = crewUtil.reduce((s, c) => s + c.booked, 0);
  const capacityUtil = Math.round((totalBooked / totalAvailable) * 100);

  const kpis = [
    {
      label: "Completed jobs",
      value: completedCount,
      icon: CheckCircle2,
      tone: "text-success",
    },
    {
      label: "Ready for invoice",
      value: readyToInvoice,
      icon: DollarSign,
      tone: "text-warning",
    },
    {
      label: "Hours worked",
      value: `${totalWorked}h`,
      icon: Clock,
      tone: "text-primary",
    },
    {
      label: "Estimated hours",
      value: `${totalEstimated}h`,
      icon: Activity,
      tone: "text-muted-foreground",
    },
    {
      label: "Avg completion",
      value: `${avgCompletion}%`,
      icon: TrendingUp,
      tone: "text-primary",
    },
    {
      label: "Delayed jobs",
      value: delayedCount,
      icon: AlertTriangle,
      tone: "text-critical",
    },
    {
      label: "Capacity utilization",
      value: `${capacityUtil}%`,
      icon: Users,
      tone: "text-success",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
          <p className="text-sm text-muted-foreground">
            Admin, billing, and operations reporting across crews, jobs, and capacity.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" /> Export CSV
          </Button>
          <Button variant="outline" size="sm">
            <FileText className="h-4 w-4 mr-2" /> Export PDF
          </Button>
          <Button size="sm">
            <Send className="h-4 w-4 mr-2" /> Send to Admin
          </Button>
        </div>
      </div>

      {/* Filter bar */}
      <Card>
        <CardContent className="p-4">
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-6">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">From</label>
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">To</label>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Crew</label>
              <Select value={crewFilter} onValueChange={setCrewFilter}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All crews</SelectItem>
                  {crews.map((c) => (
                    <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Job status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="Scheduled">Scheduled</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="On Hold">On Hold</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Billing">Billing</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Billing</label>
              <Select value={billingFilter} onValueChange={setBillingFilter}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="Not ready">Not ready</SelectItem>
                  <SelectItem value="Ready for invoice">Ready for invoice</SelectItem>
                  <SelectItem value="Invoiced">Invoiced</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Client</label>
              <Select value={clientFilter} onValueChange={setClientFilter}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All clients</SelectItem>
                  {clients.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KPI cards */}
      <div className="grid gap-3 grid-cols-2 md:grid-cols-4 lg:grid-cols-7">
        {kpis.map((k) => {
          const Icon = k.icon;
          return (
            <Card key={k.label}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wide text-muted-foreground font-medium">
                    {k.label}
                  </span>
                  <Icon className={`h-4 w-4 ${k.tone}`} />
                </div>
                <div className="text-2xl font-bold mt-2">{k.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Billing Readiness Report */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>Billing readiness</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Jobs queued for invoicing and admin review.
            </p>
          </div>
          <Button variant="ghost" size="sm">
            <Download className="h-4 w-4 mr-2" /> CSV
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job ID</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Job</TableHead>
                <TableHead className="w-[140px]">% Complete</TableHead>
                <TableHead>Hours worked</TableHead>
                <TableHead>Milestone</TableHead>
                <TableHead>Billing status</TableHead>
                <TableHead>Admin notes</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((j) => (
                <TableRow key={j.id}>
                  <TableCell className="font-mono text-xs">{j.id}</TableCell>
                  <TableCell>{j.client}</TableCell>
                  <TableCell className="font-medium">{j.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={j.progress} className="h-2 w-20" />
                      <span className="text-xs text-muted-foreground">{j.progress}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="tabular-nums">
                    {j.hoursWorked}/{j.estimatedHours}h
                  </TableCell>
                  <TableCell className="text-sm">{j.milestone}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={billingTone(j.billingStatus)}>
                      {j.billingStatus}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{j.adminNotes}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      {j.billingStatus === "Ready for invoice" ? "Invoice" : "Review"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={9} className="text-center text-sm text-muted-foreground py-8">
                    No jobs match the current filters.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Capacity Utilization Report */}
        <Card>
          <CardHeader>
            <CardTitle>Capacity utilization</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Weekly booked vs available hours per crew.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* simple bar chart */}
            <div className="space-y-3">
              {crewUtil.map((c) => (
                <div key={c.name}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">{c.name}</span>
                    <span className="flex items-center gap-2 tabular-nums text-muted-foreground">
                      {c.booked}/{c.available}h
                      <CapacityBadge status={capacityStatus(c.utilization)} utilization={c.utilization} />
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className={`h-full ${utilTone(c.utilization)}`}
                      style={{ width: `${Math.min(100, c.utilization)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Crew</TableHead>
                  <TableHead className="text-right">Available</TableHead>
                  <TableHead className="text-right">Booked</TableHead>
                  <TableHead className="text-right">Util %</TableHead>
                  <TableHead className="text-right">Overbooked</TableHead>
                  <TableHead className="text-right">Idle</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {crewUtil.map((c) => (
                  <TableRow key={c.name}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell className="text-right tabular-nums">{c.available}h</TableCell>
                    <TableCell className="text-right tabular-nums">{c.booked}h</TableCell>
                    <TableCell className="text-right tabular-nums">{c.utilization}%</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {c.overbooked > 0 ? (
                        <span className="text-critical">{c.overbooked}h</span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {c.idle > 0 ? `${c.idle}h` : "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Job Progress Report */}
        <Card>
          <CardHeader>
            <CardTitle>Job progress vs plan</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Actual completion compared to scheduled progress.
            </p>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job</TableHead>
                  <TableHead className="text-right">Planned</TableHead>
                  <TableHead className="text-right">Actual</TableHead>
                  <TableHead className="text-right">Diff</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((j) => {
                  const diff = j.progress - j.planned;
                  return (
                    <TableRow key={j.id}>
                      <TableCell>
                        <div className="font-medium">{j.name}</div>
                        <div className="text-xs text-muted-foreground font-mono">{j.id}</div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Progress value={j.planned} className="h-1.5 w-14" />
                          <span className="text-xs tabular-nums w-8">{j.planned}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Progress value={j.progress} className="h-1.5 w-14" />
                          <span className="text-xs tabular-nums w-8">{j.progress}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">{diffBadge(diff)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">{j.status}</Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{j.adminNotes}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <ProfitabilityReport />
      </div>
    </div>
  );
}
