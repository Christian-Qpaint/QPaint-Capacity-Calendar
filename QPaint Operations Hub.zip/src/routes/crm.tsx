import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState, type DragEvent } from "react";
import { PipedriveSyncButton } from "@/components/pipedrive-sync-button";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuSub,
  DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

import {
  DEAL_PRIORITIES,
  dealsQuery, pipelinesQuery, pipelineStagesQuery,
  createDeal, updateDeal, deleteDeal,
  moveDealToStage,
  type DealRow, type DealPriority,
  type PipelineRow, type PipelineStageRow,
} from "@/lib/db";

import {
  Plus, Search, MapPin, MoreHorizontal, Pencil, Trash2,
  ArrowRightLeft, DollarSign, Briefcase, Flame, Sparkles, Settings as SettingsIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/crm")({
  component: () => (
    <RequireRole roles={ACCESS.crm}>
      <CrmPage />
    </RequireRole>
  ),
});

const PRIORITY_TONE: Record<DealPriority, string> = {
  Low: "bg-slate-100 text-slate-600",
  Normal: "bg-sky-100 text-sky-700",
  High: "bg-amber-100 text-amber-700",
  Urgent: "bg-rose-100 text-rose-700",
};

const CATEGORIES = ["Residential", "Commercial", "Strata", "Industrial", "Insurance", "Other"];
const QUOTE_TYPES = ["Interior", "Exterior", "Full Repaint", "Touch-up", "Roof", "Specialty"];
const OWNERS = ["Ava Henderson", "Marcus Lee", "Priya Shah", "Jordan Reyes"];

const fmtMoney = (n?: number | null) =>
  n == null ? "—" : n.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 });

function CrmPage() {
  const qc = useQueryClient();
  const navigate = Route.useNavigate();

  const { data: liveDeals = [], isLoading: dealsLoading } = useQuery(dealsQuery);
  const { data: pipelines = [], isLoading: pipelinesLoading } = useQuery(pipelinesQuery);
  const { data: allStages = [], isLoading: stagesLoading } = useQuery(pipelineStagesQuery);
  const loading = dealsLoading || pipelinesLoading || stagesLoading;

  const deals = liveDeals;

  const [activePipelineId, setActivePipelineId] = useState<string | null>(null);
  const activePipeline = useMemo(
    () => pipelines.find((p) => p.id === activePipelineId) ?? pipelines[0] ?? null,
    [pipelines, activePipelineId],
  );

  const stages = useMemo<PipelineStageRow[]>(
    () => (activePipeline ? allStages.filter((s) => s.pipeline_id === activePipeline.id) : []),
    [allStages, activePipeline],
  );

  const decoratedDeals = deals;

  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [editDeal, setEditDeal] = useState<DealRow | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<DealRow | null>(null);

  // optimistic stage moves
  const [overrides, setOverrides] = useState<Record<string, { pipeline_id: string; pipeline_stage_id: string }>>({});

  const dealsInPipeline = useMemo(() => {
    if (!activePipeline) return [];
    const q = search.trim().toLowerCase();
    return decoratedDeals
      .map((d) => {
        const o = overrides[d.id];
        return { ...d, ...(o ?? {}) } as DealRow;
      })
      .filter((d) => d.pipeline_id === activePipeline.id)
      .filter((d) => {
        if (!q) return true;
        return (
          d.client_name.toLowerCase().includes(q) ||
          d.quote_id.toLowerCase().includes(q) ||
          (d.property_address ?? "").toLowerCase().includes(q) ||
          (d.contact_person ?? "").toLowerCase().includes(q)
        );
      });
  }, [decoratedDeals, activePipeline, overrides, search]);

  const grouped = useMemo(() => {
    const g: Record<string, DealRow[]> = {};
    for (const s of stages) g[s.id] = [];
    for (const d of dealsInPipeline) {
      const sid = d.pipeline_stage_id ?? stages[0]?.id;
      if (sid && g[sid]) g[sid].push(d);
    }
    return g;
  }, [dealsInPipeline, stages]);

  const totals = useMemo(() => {
    const value = dealsInPipeline.reduce((s, d) => s + Number(d.expected_value ?? 0), 0);
    const urgent = dealsInPipeline.filter((d) => d.priority === "Urgent" || d.priority === "High").length;
    const wonStageIds = new Set(stages.filter((s) => s.is_won).map((s) => s.id));
    const wonCount = dealsInPipeline.filter((d) => d.pipeline_stage_id && wonStageIds.has(d.pipeline_stage_id)).length;
    return { value, count: dealsInPipeline.length, urgent, wonCount };
  }, [dealsInPipeline, stages]);

  /* ---------------- mutations ---------------- */

  async function handleDropStage(dealId: string, stageId: string) {
    const deal = decoratedDeals.find((d) => d.id === dealId);
    if (!deal || !activePipeline) return;
    if (deal.pipeline_stage_id === stageId) return;
    setOverrides((p) => ({ ...p, [dealId]: { pipeline_id: activePipeline.id, pipeline_stage_id: stageId } }));
    try {
      await moveDealToStage({ deal, pipelineId: activePipeline.id, stageId, pipeline: activePipeline });
      toast.success(`Moved ${deal.quote_id}`);
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["schedules"] });
      qc.invalidateQueries({ queryKey: ["jobs"] });
      setOverrides((p) => { const { [dealId]: _drop, ...rest } = p; return rest; });
    } catch {
      setOverrides((p) => { const { [dealId]: _drop, ...rest } = p; return rest; });
      toast.error("Could not move deal");
    }
  }

  async function handleMoveToPipeline(deal: DealRow, pipelineId: string) {
    const targetPipe = pipelines.find((p) => p.id === pipelineId);
    if (!targetPipe) return;
    const firstStage = allStages.filter((s) => s.pipeline_id === pipelineId).sort((a, b) => a.position - b.position)[0];
    if (!firstStage) {
      toast.error("Target pipeline has no stages");
      return;
    }
    setOverrides((p) => ({ ...p, [deal.id]: { pipeline_id: pipelineId, pipeline_stage_id: firstStage.id } }));
    try {
      await moveDealToStage({ deal, pipelineId, stageId: firstStage.id, pipeline: targetPipe });
      toast.success(
        targetPipe.auto_schedule
          ? `Moved to ${targetPipe.name} — added to Capacity Calendar`
          : `Moved to ${targetPipe.name}`,
      );
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["schedules"] });
      qc.invalidateQueries({ queryKey: ["jobs"] });
      setOverrides((p) => { const { [deal.id]: _drop, ...rest } = p; return rest; });
    } catch {
      setOverrides((p) => { const { [deal.id]: _drop, ...rest } = p; return rest; });
      toast.error("Could not move deal");
    }
  }

  async function handleCreate(values: AddValues) {
    try {
      await createDeal({
        ...values,
        pipeline_id: values.pipeline_id,
        pipeline_stage_id: values.pipeline_stage_id,
      });
      toast.success("Deal added");
      qc.invalidateQueries({ queryKey: ["deals"] });
    } catch {
      toast.error("Could not create deal");
    }
  }

  async function handleEdit(values: AddValues) {
    if (!editDeal) return;
    try {
      await updateDeal(editDeal.id, values);
      toast.success("Deal updated");
      qc.invalidateQueries({ queryKey: ["deals"] });
      setEditDeal(null);
    } catch {
      toast.error("Update failed");
    }
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    try {
      await deleteDeal(confirmDelete.id);
      toast.success("Deal deleted");
      qc.invalidateQueries({ queryKey: ["deals"] });
      setConfirmDelete(null);
    } catch {
      toast.error("Delete failed");
    }
  }

  /* ---------------- render ---------------- */

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">Pipelines</p>
          <h1 className="font-display text-2xl font-bold tracking-tight">CRM</h1>
          <p className="text-sm text-muted-foreground">
            Drag deals across stages. Move a deal into a pipeline marked as <em>auto-schedule</em> to push it onto the Capacity Calendar.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <PipedriveSyncButton
            mode="deals"
            onDone={() => {
              qc.invalidateQueries({ queryKey: ["deals"] });
              qc.invalidateQueries({ queryKey: ["pipelines"] });
              qc.invalidateQueries({ queryKey: ["pipeline_stages"] });
            }}
          />
          <Button asChild variant="outline" size="sm" className="gap-1.5">
            <Link to="/settings"><SettingsIcon className="h-4 w-4" /> Manage pipelines</Link>
          </Button>
          <Button onClick={() => setAddOpen(true)} className="gap-1.5">
            <Plus className="h-4 w-4" /> Add Deal
          </Button>
        </div>
      </div>

      {/* Pipeline tabs */}
      <div className="flex flex-wrap items-center gap-1.5 border-b">
        {pipelines.map((p) => {
          const isActive = activePipeline?.id === p.id;
          return (
            <button
              key={p.id}
              onClick={() => setActivePipelineId(p.id)}
              className={cn(
                "relative -mb-px flex items-center gap-1.5 border-b-2 px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "border-primary text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground",
              )}
            >
              <span
                className="h-2 w-2 rounded-full"
                style={{ background: p.color ?? "#94a3b8" }}
              />
              {p.name}
              {p.auto_schedule && (
                <span className="rounded bg-orange-100 px-1 text-[10px] font-semibold uppercase text-orange-700">auto</span>
              )}
            </button>
          );
        })}
        {pipelines.length === 0 && (
          <p className="px-3 py-2 text-sm text-muted-foreground">
            No pipelines yet. <Link to="/settings" className="text-primary underline">Create one in Settings</Link>.
          </p>
        )}
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Kpi icon={<Briefcase className="h-4 w-4" />} label="Deals" value={String(totals.count)} />
        <Kpi icon={<DollarSign className="h-4 w-4" />} label="Pipeline value" value={fmtMoney(totals.value)} />
        <Kpi icon={<Sparkles className="h-4 w-4" />} label="In won stage" value={String(totals.wonCount)} tone="emerald" />
        <Kpi icon={<Flame className="h-4 w-4" />} label="High / urgent" value={String(totals.urgent)} tone="amber" />
      </div>

      <Card className="border-border/60">
        <CardContent className="flex flex-wrap items-center gap-2 p-3">
          <div className="relative min-w-[240px] flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search client, quote ID, address…" className="pl-8" />
          </div>
        </CardContent>
      </Card>

      {/* Kanban */}
      {loading && pipelines.length === 0 && <KanbanSkeleton columns={6} />}

      {activePipeline && stages.length > 0 && (
        <div
          className="grid gap-3 pb-2"
          style={{ gridTemplateColumns: `repeat(${stages.length}, minmax(0, 1fr))` }}
        >
          {stages.map((s) => (
            <StageColumn
              key={s.id}
              stage={s}
              deals={grouped[s.id] ?? []}
              pipelines={pipelines}
              activePipelineId={activePipeline.id}
              loading={dealsLoading}
              onOpen={(id) => navigate({ to: "/crm/$dealId", params: { dealId: id } })}
              onDrop={handleDropStage}
              onEdit={(d) => setEditDeal(d)}
              onDelete={(d) => setConfirmDelete(d)}
              onMoveToPipeline={handleMoveToPipeline}
            />
          ))}
        </div>
      )}


      {activePipeline && stages.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            This pipeline has no stages yet.{" "}
            <Link to="/settings" className="text-primary underline">Add stages in Settings</Link>.
          </CardContent>
        </Card>
      )}

      <DealDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        pipelines={pipelines}
        stages={allStages}
        defaultPipelineId={activePipeline?.id}
        title="Add Deal"
        submitLabel="Add to pipeline"
        onSubmit={async (v) => { await handleCreate(v); setAddOpen(false); }}
      />

      <DealDialog
        open={!!editDeal}
        onOpenChange={(o) => !o && setEditDeal(null)}
        pipelines={pipelines}
        stages={allStages}
        initial={editDeal ?? undefined}
        title="Edit Deal"
        submitLabel="Save changes"
        onSubmit={handleEdit}
      />

      <Dialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Delete deal?</DialogTitle>
            <DialogDescription>
              {confirmDelete?.client_name} ({confirmDelete?.quote_id}) — this cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmDelete(null)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ---------------- sub-components ---------------- */

function Kpi({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: string; tone?: "emerald" | "amber" }) {
  return (
    <Card className="border-border/60">
      <CardContent className="p-4">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="font-medium uppercase tracking-wide">{label}</span>
          <span className={cn(
            "flex h-7 w-7 items-center justify-center rounded-md",
            tone === "emerald" ? "bg-emerald-100 text-emerald-700"
              : tone === "amber" ? "bg-amber-100 text-amber-700"
              : "bg-primary/10 text-primary",
          )}>{icon}</span>
        </div>
        <div className="mt-2 font-display text-2xl font-bold tabular-nums">{value}</div>
      </CardContent>
    </Card>
  );
}

function KanbanSkeleton({ columns = 6 }: { columns?: number }) {
  return (
    <div className="grid gap-3 pb-2" style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}>
      {Array.from({ length: columns }).map((_, i) => (
        <div key={i} className="flex min-w-0 flex-col rounded-lg border bg-muted/30">
          <div className="border-b border-border/60 px-3 py-2.5">
            <div className="h-4 w-20 animate-pulse rounded bg-muted-foreground/20" />
            <div className="mt-2 h-3 w-12 animate-pulse rounded bg-muted-foreground/15" />
          </div>
          <div className="space-y-2 p-2">
            {Array.from({ length: 3 }).map((_, j) => (
              <div key={j} className="h-20 animate-pulse rounded-md border border-border/40 bg-card" />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function StageColumn({
  stage, deals, pipelines, activePipelineId, loading, onOpen, onDrop, onEdit, onDelete, onMoveToPipeline,
}: {
  stage: PipelineStageRow;
  deals: DealRow[];
  pipelines: PipelineRow[];
  activePipelineId: string;
  loading?: boolean;
  onOpen: (id: string) => void;
  onDrop: (id: string, stageId: string) => void;
  onEdit: (d: DealRow) => void;
  onDelete: (d: DealRow) => void;
  onMoveToPipeline: (d: DealRow, pipelineId: string) => void;
}) {
  const [hover, setHover] = useState(false);
  const value = deals.reduce((s, d) => s + Number(d.expected_value ?? 0), 0);

  return (
    <div
      className={cn(
        "flex min-w-0 w-full flex-col rounded-lg border bg-muted/30 transition-colors",
        hover && "border-primary/60 bg-primary/5",
      )}
      onDragOver={(e: DragEvent<HTMLDivElement>) => { e.preventDefault(); if (!hover) setHover(true); }}
      onDragLeave={() => setHover(false)}
      onDrop={(e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setHover(false);
        const id = e.dataTransfer.getData("text/deal");
        if (id) onDrop(id, stage.id);
      }}
    >
      <div className="flex items-start justify-between gap-2 border-b border-border/60 px-3 py-2.5">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span
              className="rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide"
              style={{ borderColor: stage.color ?? undefined, color: stage.color ?? undefined, background: (stage.color ?? "#94a3b8") + "15" }}
            >
              {stage.name}
            </span>
            <span className="text-xs font-medium text-muted-foreground tabular-nums">{deals.length}</span>
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground tabular-nums">{fmtMoney(value)}</p>
        </div>
      </div>
      <div className="flex min-h-[60px] flex-col gap-2 overflow-y-auto p-2" style={{ maxHeight: "calc(100vh - 380px)" }}>
        {loading && deals.length === 0 && (
          <>
            {Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="h-20 animate-pulse rounded-md border border-border/40 bg-card" />
            ))}
          </>
        )}
        {deals.map((d) => (
          <DealCard
            key={d.id}
            deal={d}
            pipelines={pipelines}
            activePipelineId={activePipelineId}
            onOpen={onOpen}
            onEdit={onEdit}
            onDelete={onDelete}
            onMoveToPipeline={onMoveToPipeline}
          />
        ))}
        {!loading && deals.length === 0 && (
          <div className="rounded-md border border-dashed border-border/70 p-3 text-center text-[11px] text-muted-foreground">
            Drop here
          </div>
        )}
      </div>
    </div>
  );
}


function DealCard({
  deal, pipelines, activePipelineId, onOpen, onEdit, onDelete, onMoveToPipeline,
}: {
  deal: DealRow;
  pipelines: PipelineRow[];
  activePipelineId: string;
  onOpen: (id: string) => void;
  onEdit: (d: DealRow) => void;
  onDelete: (d: DealRow) => void;
  onMoveToPipeline: (d: DealRow, pipelineId: string) => void;
}) {
  return (
    <div
      role="button"
      tabIndex={0}
      draggable
      onDragStart={(e) => e.dataTransfer.setData("text/deal", deal.id)}
      onClick={() => onOpen(deal.id)}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onOpen(deal.id)}
      className="group cursor-grab rounded-md border border-border/70 bg-card p-2.5 text-left shadow-sm transition-all hover:border-primary/50 hover:shadow-md active:cursor-grabbing"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="font-mono text-[10px] font-semibold text-primary">{deal.quote_id}</span>
            <span className={cn("rounded px-1.5 py-0.5 text-[9px] font-semibold uppercase", PRIORITY_TONE[deal.priority])}>{deal.priority}</span>
          </div>
          <p className="mt-1 truncate text-sm font-semibold text-foreground">{deal.client_name}</p>
          {deal.property_address && (
            <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] text-muted-foreground">
              <MapPin className="h-3 w-3 shrink-0" /> {deal.property_address}
            </p>
          )}
        </div>
        <div className="flex items-start gap-1" onClick={(e) => e.stopPropagation()}>
          {deal.expected_value != null && Number(deal.expected_value) > 0 && (
            <span className="rounded bg-emerald-50 px-1.5 py-0.5 text-[11px] font-semibold tabular-nums text-emerald-700">
              {fmtMoney(Number(deal.expected_value))}
            </span>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                aria-label="Deal actions"
                onClick={(e) => e.stopPropagation()}
                className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuItem onClick={() => onOpen(deal.id)}>Open</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onEdit(deal)}>
                <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
              </DropdownMenuItem>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger>
                  <ArrowRightLeft className="mr-2 h-3.5 w-3.5" /> Move to pipeline
                </DropdownMenuSubTrigger>
                <DropdownMenuSubContent className="w-52">
                  <DropdownMenuLabel className="text-[11px]">Send this deal to…</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {pipelines
                    .filter((p) => p.id !== activePipelineId)
                    .map((p) => (
                      <DropdownMenuItem key={p.id} onClick={() => onMoveToPipeline(deal, p.id)}>
                        <span className="mr-2 h-2 w-2 rounded-full" style={{ background: p.color ?? "#94a3b8" }} />
                        {p.name}
                        {p.auto_schedule && (
                          <span className="ml-auto rounded bg-orange-100 px-1 text-[9px] font-semibold uppercase text-orange-700">auto</span>
                        )}
                      </DropdownMenuItem>
                    ))}
                  {pipelines.filter((p) => p.id !== activePipelineId).length === 0 && (
                    <DropdownMenuItem disabled>No other pipelines</DropdownMenuItem>
                  )}
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-rose-600" onClick={() => onDelete(deal)}>
                <Trash2 className="mr-2 h-3.5 w-3.5" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-1">
        {deal.category && <Badge variant="outline" className="text-[10px]">{deal.category}</Badge>}
        {deal.quote_type && <Badge variant="outline" className="text-[10px]">{deal.quote_type}</Badge>}
        {deal.converted_job_id && (
          <Badge variant="outline" className="border-blue-200 bg-blue-50 text-[10px] text-blue-700">
            On calendar
          </Badge>
        )}
      </div>

      <div className="mt-2 flex items-center justify-between border-t border-border/50 pt-2 text-[10px] text-muted-foreground">
        <span className="truncate">{deal.owner ?? "Unassigned"}</span>
      </div>
    </div>
  );
}

/* ---------------- Deal create/edit dialog ---------------- */

const dealSchema = z.object({
  client_name: z.string().min(2, "Client name required"),
  contact_person: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  property_address: z.string().optional(),
  category: z.string().optional(),
  quote_type: z.string().optional(),
  owner: z.string().optional(),
  pipeline_id: z.string().min(1, "Pipeline required"),
  pipeline_stage_id: z.string().min(1, "Stage required"),
  priority: z.enum(DEAL_PRIORITIES),
  expected_value: z.coerce.number().min(0).optional(),
  target_hours: z.coerce.number().min(0).optional(),
  extent_of_work: z.string().optional(),
});
type AddValues = z.infer<typeof dealSchema>;

function DealDialog({
  open, onOpenChange, pipelines, stages, defaultPipelineId, initial, title, submitLabel, onSubmit,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  pipelines: PipelineRow[];
  stages: PipelineStageRow[];
  defaultPipelineId?: string;
  initial?: DealRow;
  title: string;
  submitLabel: string;
  onSubmit: (v: AddValues) => Promise<void>;
}) {
  const firstPipe = initial?.pipeline_id ?? defaultPipelineId ?? pipelines[0]?.id ?? "";
  const firstStage = initial?.pipeline_stage_id ?? stages.find((s) => s.pipeline_id === firstPipe)?.id ?? "";

  const form = useForm<AddValues>({
    resolver: zodResolver(dealSchema),
    values: {
      client_name: initial?.client_name ?? "",
      contact_person: initial?.contact_person ?? "",
      phone: initial?.phone ?? "",
      email: initial?.email ?? "",
      property_address: initial?.property_address ?? "",
      category: initial?.category ?? undefined,
      quote_type: initial?.quote_type ?? undefined,
      owner: initial?.owner ?? undefined,
      pipeline_id: firstPipe,
      pipeline_stage_id: firstStage,
      priority: initial?.priority ?? "Normal",
      expected_value: initial?.expected_value != null ? Number(initial.expected_value) : undefined,
      target_hours: initial?.target_hours != null ? Number(initial.target_hours) : undefined,
      extent_of_work: initial?.extent_of_work ?? "",
    },
  });
  const { register, handleSubmit, setValue, watch, formState: { errors, isSubmitting }, reset } = form;
  const pipeId = watch("pipeline_id");
  const stagesForPipe = stages.filter((s) => s.pipeline_id === pipeId).sort((a, b) => a.position - b.position);

  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) reset(); }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>Pipeline and stage decide where the card appears. Moving into an auto-schedule pipeline creates a Capacity Calendar item.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(async (v) => { await onSubmit(v); reset(); })} className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <Field label="Client name" error={errors.client_name?.message} required>
            <Input {...register("client_name")} placeholder="Marina Heights Strata" />
          </Field>
          <Field label="Contact person">
            <Input {...register("contact_person")} />
          </Field>
          <Field label="Phone"><Input {...register("phone")} /></Field>
          <Field label="Email" error={errors.email?.message}><Input type="email" {...register("email")} /></Field>
          <Field label="Property address" className="md:col-span-2">
            <Input {...register("property_address")} />
          </Field>

          <Field label="Pipeline" required>
            <Select value={watch("pipeline_id")} onValueChange={(v) => {
              setValue("pipeline_id", v);
              const first = stages.filter((s) => s.pipeline_id === v).sort((a, b) => a.position - b.position)[0];
              if (first) setValue("pipeline_stage_id", first.id);
            }}>
              <SelectTrigger><SelectValue placeholder="Select pipeline" /></SelectTrigger>
              <SelectContent>
                {pipelines.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name}{p.auto_schedule ? " · auto-schedules" : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Stage" required>
            <Select value={watch("pipeline_stage_id")} onValueChange={(v) => setValue("pipeline_stage_id", v)}>
              <SelectTrigger><SelectValue placeholder="Select stage" /></SelectTrigger>
              <SelectContent>
                {stagesForPipe.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Category">
            <SelectMini value={watch("category")} onChange={(v) => setValue("category", v)} options={CATEGORIES} />
          </Field>
          <Field label="Quote type">
            <SelectMini value={watch("quote_type")} onChange={(v) => setValue("quote_type", v)} options={QUOTE_TYPES} />
          </Field>
          <Field label="Owner">
            <SelectMini value={watch("owner")} onChange={(v) => setValue("owner", v)} options={OWNERS} />
          </Field>
          <Field label="Priority">
            <SelectMini value={watch("priority")} onChange={(v) => setValue("priority", v as DealPriority)} options={DEAL_PRIORITIES as unknown as string[]} />
          </Field>
          <Field label="Expected value ($)">
            <Input type="number" step="100" min={0} {...register("expected_value")} />
          </Field>
          <Field label="Target hours">
            <Input type="number" step="1" min={0} {...register("target_hours")} />
          </Field>
          <Field label="Extent of work" className="md:col-span-2">
            <Textarea rows={2} {...register("extent_of_work")} />
          </Field>
          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={isSubmitting}>{isSubmitting ? "Saving…" : submitLabel}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children, error, required, className }: { label: string; children: React.ReactNode; error?: string; required?: boolean; className?: string }) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label} {required && <span className="text-rose-600">*</span>}
      </Label>
      {children}
      {error && <p className="text-[11px] text-rose-600">{error}</p>}
    </div>
  );
}

function SelectMini({ value, onChange, options }: { value?: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
      <SelectContent>{options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
    </Select>
  );
}


