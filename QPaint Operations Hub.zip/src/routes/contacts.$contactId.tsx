import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Mail, Phone, MapPin, Building2, Save, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useConfirm } from "@/components/confirm-dialog";
import {
  contactByIdQuery,
  dealsByContactQuery,
  jobsByContactQuery,
  updateContact,
  deleteContact,
  type ContactRow,
} from "@/lib/db";

export const Route = createFileRoute("/contacts/$contactId")({
  component: ContactDetail,
  head: ({ params }) => ({ meta: [{ title: `Contact · ${params.contactId.slice(0, 8)} · QPaint` }] }),
  errorComponent: ({ error }) => (
    <div className="p-6 text-sm text-destructive">Failed to load contact: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-6 text-sm">Contact not found</div>,
});

const fmtMoney = (v: number | null | undefined) =>
  v == null ? "—" : new Intl.NumberFormat("en-AU", { style: "currency", currency: "AUD", maximumFractionDigits: 0 }).format(Number(v));

function ContactDetail() {
  const { contactId } = Route.useParams();
  const qc = useQueryClient();
  const router = useRouter();
  const { data: contact, isLoading } = useQuery(contactByIdQuery(contactId));
  const { data: deals = [] } = useQuery(dealsByContactQuery(contactId));
  const { data: jobs = [] } = useQuery(jobsByContactQuery(contactId));
  const [editing, setEditing] = useState<Partial<ContactRow> | null>(null);
  const [busy, setBusy] = useState(false);
  const confirm = useConfirm();

  if (isLoading) {
    return (
      <div className="space-y-4 p-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!contact) {
    return (
      <div className="space-y-4 p-6">
        <Link to="/contacts" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to Contacts
        </Link>
        <p className="text-sm text-muted-foreground">Contact not found.</p>
      </div>
    );
  }

  const form: Partial<ContactRow> = editing ?? contact;

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    try {
      await updateContact(contact.id, editing);
      await qc.invalidateQueries({ queryKey: ["contact", contact.id] });
      await qc.invalidateQueries({ queryKey: ["contacts"] });
      toast.success("Contact updated");
      setEditing(null);
    } catch (e) {
      toast.error("Failed to update", { description: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!(await confirm({ title: `Delete contact "${contact.name}"?`, description: "Linked deals and jobs keep their data; the contact link is cleared. This only affects your local database.", confirmLabel: "Delete", destructive: true }))) return;
    setBusy(true);
    try {
      await deleteContact(contact.id);
      toast.success("Contact deleted");
      router.navigate({ to: "/contacts" });
    } catch (e) {
      toast.error("Failed to delete", { description: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between gap-2">
        <Link to="/contacts" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to Contacts
        </Link>
        <div className="flex gap-2">
          {editing ? (
            <>
              <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
              <Button onClick={save} disabled={busy} className="gap-1.5"><Save className="h-4 w-4" /> Save</Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setEditing(contact)}>Edit</Button>
              <Button variant="ghost" onClick={remove} disabled={busy} className="gap-1.5 text-destructive">
                <Trash2 className="h-4 w-4" /> Delete
              </Button>
            </>
          )}
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle className="font-display text-2xl">{contact.name}</CardTitle>
              <div className="mt-1 text-sm text-muted-foreground">
                {contact.company || "Individual"} · Added {new Date(contact.created_at).toLocaleDateString()}
              </div>
            </div>
            {contact.ranking && <Badge variant="outline">{contact.ranking}</Badge>}
          </div>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          {editing ? (
            <>
              <Field label="Name"><Input value={form.name ?? ""} onChange={(e) => setEditing({ ...form, name: e.target.value })} /></Field>
              <Field label="Company"><Input value={form.company ?? ""} onChange={(e) => setEditing({ ...form, company: e.target.value })} /></Field>
              <Field label="Email"><Input value={form.email ?? ""} onChange={(e) => setEditing({ ...form, email: e.target.value })} /></Field>
              <Field label="Phone"><Input value={form.phone ?? ""} onChange={(e) => setEditing({ ...form, phone: e.target.value })} /></Field>
              <Field label="Address" full><Input value={form.address ?? ""} onChange={(e) => setEditing({ ...form, address: e.target.value })} /></Field>
              <Field label="Ranking"><Input value={form.ranking ?? ""} onChange={(e) => setEditing({ ...form, ranking: e.target.value })} /></Field>
              <Field label="Source"><Input value={form.source ?? ""} onChange={(e) => setEditing({ ...form, source: e.target.value })} /></Field>
              <Field label="Notes" full><Textarea rows={3} value={form.notes ?? ""} onChange={(e) => setEditing({ ...form, notes: e.target.value })} /></Field>
            </>
          ) : (
            <>
              <InfoRow icon={Mail} label="Email" value={contact.email} />
              <InfoRow icon={Phone} label="Phone" value={contact.phone} />
              <InfoRow icon={MapPin} label="Address" value={contact.address} />
              <InfoRow icon={Building2} label="Company" value={contact.company} />
              <InfoRow label="Source" value={contact.source} />
              <InfoRow label="Ranking" value={contact.ranking} />
              {contact.notes && (
                <div className="md:col-span-2">
                  <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Notes</div>
                  <p className="mt-1 whitespace-pre-wrap text-sm">{contact.notes}</p>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-3">
        <Stat label="Total Deals" value={contact.total_deals.toString()} />
        <Stat label="Total Jobs" value={contact.total_jobs.toString()} />
        <Stat label="Lifetime Value" value={fmtMoney(contact.lifetime_value)} />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Linked Deals</CardTitle></CardHeader>
        <CardContent className="p-0">
          {deals.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">No deals linked yet.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-2 text-left font-semibold">Quote ID</th>
                  <th className="px-4 py-2 text-left font-semibold">Stage</th>
                  <th className="px-4 py-2 text-left font-semibold">Description</th>
                  <th className="px-4 py-2 text-right font-semibold">Value</th>
                </tr>
              </thead>
              <tbody>
                {deals.map((d) => (
                  <tr key={d.id} className="border-t border-border/60 hover:bg-muted/30">
                    <td className="px-4 py-2">
                      <Link to="/crm/$dealId" params={{ dealId: d.id }} className="font-medium text-primary hover:underline">
                        {d.quote_id || d.id.slice(0, 8)}
                      </Link>
                    </td>
                    <td className="px-4 py-2"><Badge variant="outline">{d.stage}</Badge></td>
                    <td className="px-4 py-2 text-muted-foreground">{d.description ?? d.extent_of_work ?? "—"}</td>
                    <td className="px-4 py-2 text-right tabular-nums">{fmtMoney(d.expected_value)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Linked Jobs</CardTitle></CardHeader>
        <CardContent className="p-0">
          {jobs.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">No jobs linked yet.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-2 text-left font-semibold">Job</th>
                  <th className="px-4 py-2 text-left font-semibold">Status</th>
                  <th className="px-4 py-2 text-left font-semibold">Location</th>
                  <th className="px-4 py-2 text-right font-semibold">% Complete</th>
                </tr>
              </thead>
              <tbody>
                {jobs.map((j) => (
                  <tr key={j.id} className="border-t border-border/60 hover:bg-muted/30">
                    <td className="px-4 py-2">
                      <Link to="/jobs/$jobId" params={{ jobId: j.id }} className="font-medium text-primary hover:underline">
                        {j.job_name || j.job_code}
                      </Link>
                    </td>
                    <td className="px-4 py-2"><Badge variant="outline">{j.status}</Badge></td>
                    <td className="px-4 py-2 text-muted-foreground">{j.location ?? "—"}</td>
                    <td className="px-4 py-2 text-right tabular-nums">{j.completion_percentage}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <div className="text-[11px] text-muted-foreground">
        API: <code className="rounded bg-muted px-1 py-0.5">GET /api/public/contacts/{contact.id}</code>
      </div>
    </div>
  );
}

function Field({ label, full, children }: { label: string; full?: boolean; children: React.ReactNode }) {
  return (
    <div className={`space-y-1.5 ${full ? "md:col-span-2" : ""}`}>
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon?: typeof Mail; label: string; value: string | null | undefined }) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-0.5 inline-flex items-center gap-1.5 text-sm">
        {Icon && <Icon className="h-3.5 w-3.5 text-muted-foreground" />}
        {value || <span className="text-muted-foreground">—</span>}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="mt-1 font-display text-2xl font-bold tabular-nums">{value}</div>
      </CardContent>
    </Card>
  );
}
