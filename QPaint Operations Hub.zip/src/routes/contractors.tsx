import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Building2, HardHat, ShieldCheck, ShieldAlert } from "lucide-react";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/contractors")({
  head: () => ({
    meta: [
      { title: "Contractors · QPaint" },
      { name: "description", content: "Subcontractor companies, individual contractors, and their assignments." },
    ],
  }),
  component: () => (
    <RequireRole roles={ACCESS.people}>
      <ContractorsPage />
    </RequireRole>
  ),
});

type Company = {
  id: string; name: string; contact_name: string | null; email: string | null;
  phone: string | null; trade: string | null; insurance_provider: string | null;
  insurance_expiry: string | null; compliance_status: string; is_active: boolean;
};
type Contractor = {
  id: string; company_id: string | null; name: string; email: string | null;
  phone: string | null; trade: string | null; skills: string[] | null;
  hourly_cost: number | null; hourly_bill_rate: number | null; is_active: boolean;
};
type Assignment = {
  id: string; job_id: string; contractor_id: string;
  allocated_hours: number | null; hours_worked: number | null; status: string;
};

function ContractorsPage() {
  const companies = useQuery({
    queryKey: ["subcontractor_companies"],
    queryFn: async () => {
      const { data, error } = await supabase.from("subcontractor_companies" as never).select("*").order("name");
      if (error) throw error;
      return (data ?? []) as unknown as Company[];
    },
  });

  const contractors = useQuery({
    queryKey: ["contractors"],
    queryFn: async () => {
      const { data, error } = await supabase.from("contractors" as never).select("*").order("name");
      if (error) throw error;
      return (data ?? []) as unknown as Contractor[];
    },
  });

  const assignments = useQuery({
    queryKey: ["job_contractor_assignments"],
    queryFn: async () => {
      const { data, error } = await supabase.from("job_contractor_assignments" as never).select("*");
      if (error) throw error;
      return (data ?? []) as unknown as Assignment[];
    },
  });

  const assignmentsByContractor = new Map<string, Assignment[]>();
  (assignments.data ?? []).forEach((a) => {
    const list = assignmentsByContractor.get(a.contractor_id) ?? [];
    list.push(a);
    assignmentsByContractor.set(a.contractor_id, list);
  });

  const activeContractors = (contractors.data ?? []).filter((c) => c.is_active).length;
  const verifiedCompanies = (companies.data ?? []).filter((c) => c.compliance_status === "verified").length;
  const totalAllocated = (assignments.data ?? []).reduce((s, a) => s + Number(a.allocated_hours ?? 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">Contractors</h2>
        <p className="text-sm text-muted-foreground">Subcontractor companies, individual trades, and job assignments.</p>
      </div>

      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Kpi label="Companies" value={String(companies.data?.length ?? 0)} icon={Building2} tone="primary" />
        <Kpi label="Verified compliance" value={`${verifiedCompanies}/${companies.data?.length ?? 0}`} icon={ShieldCheck} tone="success" />
        <Kpi label="Active contractors" value={String(activeContractors)} icon={HardHat} tone="accent" />
        <Kpi label="Allocated hours" value={`${totalAllocated}h`} icon={ShieldAlert} tone="warning" />
      </div>

      <Card>
        <CardHeader><CardTitle>Subcontractor companies</CardTitle></CardHeader>
        <CardContent className="p-0">
          {companies.isLoading ? (
            <div className="p-6 space-y-2"><Skeleton className="h-8" /><Skeleton className="h-8" /><Skeleton className="h-8" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Company</TableHead>
                  <TableHead>Trade</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Insurance</TableHead>
                  <TableHead>Compliance</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(companies.data ?? []).map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell>{c.trade ?? "—"}</TableCell>
                    <TableCell className="text-sm">
                      <div>{c.contact_name ?? "—"}</div>
                      <div className="text-xs text-muted-foreground">{c.email ?? c.phone ?? ""}</div>
                    </TableCell>
                    <TableCell className="text-sm">
                      {c.insurance_provider ?? "—"}
                      {c.insurance_expiry && <div className="text-xs text-muted-foreground">Exp: {c.insurance_expiry}</div>}
                    </TableCell>
                    <TableCell>
                      <Badge variant={c.compliance_status === "verified" ? "success" : c.compliance_status === "expired" ? "destructive" : "warning"}>
                        {c.compliance_status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={c.is_active ? "default" : "outline"}>{c.is_active ? "Active" : "Inactive"}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Individual contractors</CardTitle></CardHeader>
        <CardContent className="p-0">
          {contractors.isLoading ? (
            <div className="p-6 space-y-2"><Skeleton className="h-8" /><Skeleton className="h-8" /><Skeleton className="h-8" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Trade / Skills</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead className="text-right">Cost / hr</TableHead>
                  <TableHead className="text-right">Bill / hr</TableHead>
                  <TableHead className="text-right">Assignments</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(contractors.data ?? []).map((c) => {
                  const company = companies.data?.find((co) => co.id === c.company_id);
                  const ax = assignmentsByContractor.get(c.id) ?? [];
                  return (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell>{company?.name ?? "—"}</TableCell>
                      <TableCell>
                        <div className="text-sm">{c.trade ?? "—"}</div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {(c.skills ?? []).slice(0, 3).map((s) => (
                            <Badge key={s} variant="outline" className="text-[10px]">{s}</Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{c.email ?? c.phone ?? "—"}</TableCell>
                      <TableCell className="text-right tabular-nums">{c.hourly_cost ? `$${c.hourly_cost}` : "—"}</TableCell>
                      <TableCell className="text-right tabular-nums">{c.hourly_bill_rate ? `$${c.hourly_bill_rate}` : "—"}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant={ax.length ? "default" : "outline"}>{ax.length}</Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Kpi({ label, value, icon: Icon, tone }: {
  label: string; value: string; icon: typeof Building2; tone: "primary" | "accent" | "success" | "warning";
}) {
  const toneCls = {
    primary: "bg-primary/10 text-primary",
    accent: "bg-accent/20 text-accent-foreground",
    success: "bg-success/15 text-success",
    warning: "bg-warning/20 text-warning-foreground",
  }[tone];
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`grid h-10 w-10 place-items-center rounded-lg ${toneCls}`}><Icon className="h-4 w-4" /></div>
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
          <div className="text-xl font-bold">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
