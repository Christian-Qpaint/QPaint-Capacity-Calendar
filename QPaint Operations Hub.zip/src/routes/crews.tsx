import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";


import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Briefcase, Plus, Users } from "lucide-react";
import { AddCrewModal } from "@/components/modals";
import { capacityStatus, capacityTone } from "@/lib/capacity";
import { CapacityBadge } from "@/components/CapacityIndicator";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/crews")({
  head: () => ({
    meta: [
      { title: "Crews · QPaint" },
      { name: "description", content: "QPaint crew roster: leadership, specialties, capacity and utilization." },
    ],
  }),
  component: () => (
    <RequireRole roles={ACCESS.people}>
      <CrewsPage />
    </RequireRole>
  ),
});

/* ---------- data ---------- */

type CrewStatus = "Available" | "Partially Booked" | "Fully Booked" | "Overbooked" | "On Leave";

interface Crew {
  id: string;
  name: string;
  leader: string;
  members: number;
  skills: string[];
  currentJob: string | null;
  weeklyCapacity: number;
  bookedHours: number;
  availabilityNote: string;
}

const crews: Crew[] = [
  {
    id: "res-a", name: "Residential Crew A", leader: "Jordan Mills", members: 5,
    skills: ["Interior", "Exterior", "Heritage"],
    currentJob: "Marina Heights Repaint",
    weeklyCapacity: 200, bookedHours: 184,
    availabilityNote: "Free from Jul 3",
  },
  {
    id: "res-b", name: "Residential Crew B", leader: "Priya Shah", members: 4,
    skills: ["Interior", "Trim & doors", "Wallpaper removal"],
    currentJob: "Glenwood Townhouses Block C",
    weeklyCapacity: 160, bookedHours: 112,
    availabilityNote: "Half-days available Thu–Fri",
  },
  {
    id: "comm", name: "Commercial Crew", leader: "Marco Diaz", members: 6,
    skills: ["Commercial fit-out", "Spray painting", "After-hours"],
    currentJob: "Northside Medical Fitout",
    weeklyCapacity: 240, bookedHours: 256,
    availabilityNote: "Overbooked Wed — needs rebalancing",
  },
  {
    id: "touch", name: "Touch-up Crew", leader: "Anna Kovac", members: 3,
    skills: ["Fine finishing", "Defect rectification", "Handover"],
    currentJob: "Wattle Primary School",
    weeklyCapacity: 120, bookedHours: 48,
    availabilityNote: "2 painters on leave/sick this week",
  },
  {
    id: "prep", name: "Prep Team", leader: "Tom Becker", members: 4,
    skills: ["Surface prep", "Sanding", "Patch & repair", "Masking"],
    currentJob: null,
    weeklyCapacity: 160, bookedHours: 80,
    availabilityNote: "Available from Today",
  },
  {
    id: "ext", name: "External Contractors", leader: "Hassan Ali (vendor)", members: 8,
    skills: ["Overflow capacity", "Exterior", "Roof & gutters"],
    currentJob: "Cliffside Villa Exterior",
    weeklyCapacity: 320, bookedHours: 200,
    availabilityNote: "On-demand · 48h notice",
  },
];

/* ---------- helpers ---------- */

function deriveStatus(c: Crew): CrewStatus {
  if (c.id === "touch") return "On Leave"; // 2 painters out
  const pct = (c.bookedHours / c.weeklyCapacity) * 100;
  if (pct > 100) return "Overbooked";
  if (pct >= 95) return "Fully Booked";
  if (pct >= 40) return "Partially Booked";
  return "Available";
}

const statusTone: Record<CrewStatus, string> = {
  "Available":        "bg-success/15 text-success border-success/30",
  "Partially Booked": "bg-primary/10 text-primary border-primary/20",
  "Fully Booked":     "bg-accent/20 text-accent-foreground border-accent/40",
  "Overbooked":       "bg-critical/15 text-critical border-critical/40",
  "On Leave":         "bg-warning/20 text-warning-foreground border-warning/40",
};

function StatusBadge({ status }: { status: CrewStatus }) {
  return <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full border whitespace-nowrap ${statusTone[status]}`}>{status}</span>;
}

function utilTone(pct: number) {
  return capacityTone(capacityStatus(pct)).bar;
}

/* ---------- page ---------- */

function CrewsPage() {
  const totalCap = crews.reduce((s, c) => s + c.weeklyCapacity, 0);
  const totalBooked = crews.reduce((s, c) => s + c.bookedHours, 0);
  const avgUtil = Math.round((totalBooked / totalCap) * 100);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">Crews</h2>
          <p className="text-sm text-muted-foreground">
            {crews.length} crews · {crews.reduce((s, c) => s + c.members, 0)} painters · {avgUtil}% average utilization
          </p>
        </div>
        <AddCrewModal trigger={<Button className="gap-1.5"><Plus className="h-4 w-4" /> Add crew</Button>} />
      </div>

      {/* Crew cards */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {crews.map((c) => {
          const pct = Math.round((c.bookedHours / c.weeklyCapacity) * 100);
          const remaining = c.weeklyCapacity - c.bookedHours;
          const status = deriveStatus(c);
          return (
            <Card key={c.id}>
              <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div className="min-w-0">
                  <Link to="/crews/$crewId" params={{ crewId: c.id }} className="font-bold truncate hover:underline block">{c.name}</Link>
                  <div className="text-xs text-muted-foreground mt-0.5">Led by {c.leader}</div>
                </div>
                <StatusBadge status={status} />
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-1.5">
                  {c.skills.map((s) => (
                    <Badge key={s} variant="outline" className="font-normal">{s}</Badge>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Members</div>
                    <div className="font-semibold flex items-center gap-1.5"><Users className="h-3.5 w-3.5" /> {c.members}</div>
                  </div>
                  <div>
                    <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Weekly cap</div>
                    <div className="font-semibold">{c.weeklyCapacity}h</div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Current job</div>
                    <div className="font-medium truncate flex items-center gap-1.5">
                      <Briefcase className="h-3.5 w-3.5 text-muted-foreground" />
                      {c.currentJob ?? <span className="text-muted-foreground italic">No active job</span>}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-muted-foreground">Utilization</span>
                    <span className={`font-semibold ${pct > 100 ? "text-critical" : pct >= 95 ? "text-accent-foreground" : ""}`}>{pct}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div className={`h-full ${utilTone(pct)}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                  </div>
                  <div className="flex justify-between text-[11px] text-muted-foreground mt-1">
                    <span>{c.bookedHours}h booked</span>
                    <span className={remaining < 0 ? "text-critical font-semibold" : ""}>
                      {remaining >= 0 ? `${remaining}h remaining` : `${Math.abs(remaining)}h over`}
                    </span>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground border-t border-border pt-3">
                  Availability · <span className="text-foreground">{c.availabilityNote}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Detail table */}
      <Card>
        <CardHeader>
          <div className="font-semibold">Crew detail</div>
          <p className="text-xs text-muted-foreground mt-1">Side-by-side comparison of crew load and availability.</p>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Crew</TableHead>
                <TableHead>Leader</TableHead>
                <TableHead className="text-right">Members</TableHead>
                <TableHead>Skills</TableHead>
                <TableHead>Current job</TableHead>
                <TableHead className="text-right">Weekly cap</TableHead>
                <TableHead className="text-right">Booked</TableHead>
                <TableHead className="text-right">Remaining</TableHead>
                <TableHead className="w-40">Utilization</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {crews.map((c) => {
                const pct = Math.round((c.bookedHours / c.weeklyCapacity) * 100);
                const remaining = c.weeklyCapacity - c.bookedHours;
                const status = deriveStatus(c);
                return (
                  <TableRow key={c.id} className="hover:bg-muted/40">
                    <TableCell className="font-medium">
                      <Link to="/crews/$crewId" params={{ crewId: c.id }} className="hover:underline">{c.name}</Link>
                    </TableCell>
                    <TableCell>{c.leader}</TableCell>
                    <TableCell className="text-right tabular-nums">{c.members}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {c.skills.map((s) => <Badge key={s} variant="outline" className="font-normal text-[10px]">{s}</Badge>)}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">
                      {c.currentJob ?? <span className="text-muted-foreground italic">—</span>}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{c.weeklyCapacity}h</TableCell>
                    <TableCell className="text-right tabular-nums">{c.bookedHours}h</TableCell>
                    <TableCell className={`text-right tabular-nums ${remaining < 0 ? "text-critical font-semibold" : ""}`}>
                      {remaining >= 0 ? `${remaining}h` : `−${Math.abs(remaining)}h`}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 flex-1 rounded-full bg-muted overflow-hidden">
                          <div className={`h-full ${utilTone(pct)}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                        </div>
                        <span className="text-xs tabular-nums w-10 text-right">{pct}%</span>
                      </div>
                    </TableCell>
                    <TableCell><StatusBadge status={status} /></TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
