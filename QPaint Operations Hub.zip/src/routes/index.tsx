import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertTriangle, Briefcase, CalendarClock, CheckCircle2, Clock,
  DollarSign, FileText, TrendingDown, UserX, Users, Wrench, Eye,
} from "lucide-react";
import { calculateDailyCapacity, capacityTone } from "@/lib/capacity";
import { CapacityBadge } from "@/components/CapacityIndicator";
import { JobRiskBadge } from "@/components/JobRiskBadge";
import { ExecutiveRevenueStrip } from "@/components/ExecutiveRevenueStrip";
import { useMyRoles, pickPrimaryRole, ROLE_LABELS, type AppRole } from "@/lib/roles";
import { MyAssignmentsPanel } from "@/components/MyAssignmentsPanel";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard · QPaint Capacity OS" },
      { name: "description", content: "What's happening today and this week: jobs, crew capacity, blockers and billing readiness." },
    ],
  }),
  component: Dashboard,
});

/* ---------- sample data ---------- */

type JobStatus = "On Track" | "Behind" | "At Risk" | "Blocked" | "Awaiting Crew" | "Completed";

const todaysJobs = [
  { id: "QP-1042", name: "Marina Heights Repaint", site: "12 Marina Pde, Bondi", crew: "Crew Alpha", lead: "Jordan Mills", status: "On Track" as JobStatus, progress: 62, blocker: null },
  { id: "QP-1044", name: "Northside Medical Fitout", site: "5 Pacific Hwy, Chatswood", crew: "Crew Charlie", lead: "Marco Diaz", status: "Behind" as JobStatus, progress: 35, blocker: "Waiting on tint batch #4421" },
  { id: "QP-1045", name: "Wattle Primary School", site: "210 Wattle Rd, Ryde", crew: "Crew Delta", lead: "Anna Kovac", status: "Blocked" as JobStatus, progress: 18, blocker: "2 painters on leave/sick" },
  { id: "QP-1043", name: "Cafe Lumen Interior", site: "88 Oxford St, Paddington", crew: "Crew Bravo", lead: "Priya Shah", status: "On Track" as JobStatus, progress: 8, blocker: null },
  { id: "QP-1049", name: "Cliffside Villa Exterior", site: "9 Cliff Rd, Vaucluse", crew: "Crew Echo", lead: "Tom Becker", status: "On Track" as JobStatus, progress: 22, blocker: null },
];

const week = [
  { day: "Mon", date: "Jun 22", booked: 38, available: 40 },
  { day: "Tue", date: "Jun 23", booked: 40, available: 40 },
  { day: "Wed", date: "Jun 24", booked: 44, available: 40 },
  { day: "Thu", date: "Jun 25", booked: 36, available: 40 },
  { day: "Fri", date: "Jun 26", booked: 32, available: 40 },
  { day: "Sat", date: "Jun 27", booked: 8, available: 16 },
  { day: "Sun", date: "Jun 28", booked: 0, available: 16 },
];

const attention = [
  { id: "QP-1044", name: "Northside Medical Fitout", reason: "2 days behind schedule", type: "delayed" as const, owner: "Crew Charlie" },
  { id: "QP-1045", name: "Wattle Primary School", reason: "Progress stalled at 18% for 5 days", type: "low-progress" as const, owner: "Crew Delta" },
  { id: "QP-1051", name: "Bay Bistro Repaint", reason: "No crew assigned — starts Jun 29", type: "unassigned" as const, owner: "—" },
  { id: "QP-1048", name: "Glenwood Townhouses Block C", reason: "Awaiting admin review (variation)", type: "admin" as const, owner: "Crew Bravo" },
  { id: "QP-1047", name: "Riverside Dental Repaint", reason: "Client signoff overdue", type: "admin" as const, owner: "Crew Alpha" },
];

const billingReady = [
  { id: "QP-1039", name: "Eastview Apartments", client: "Eastview Strata", value: 102300, completed: "Jun 22" },
  { id: "QP-1040", name: "Harbour Office Tower L12", client: "Harbour REIT", value: 158900, completed: "Jun 20" },
  { id: "QP-1036", name: "Greenwood Bakery", client: "Greenwood Group", value: 14800, completed: "Jun 18" },
];

const pendingUpdate = [
  { id: "QP-1044", name: "Northside Medical Fitout", crew: "Crew Charlie", lastUpdate: "2 days ago" },
  { id: "QP-1045", name: "Wattle Primary School", crew: "Crew Delta", lastUpdate: "4 days ago" },
  { id: "QP-1049", name: "Cliffside Villa Exterior", crew: "Crew Echo", lastUpdate: "1 day ago" },
];

const milestones = [
  { id: "M-201", text: "Marina Heights — Level 3 prep complete", when: "Today, 9:14am" },
  { id: "M-202", text: "Harbour Tower L12 — Final coat signed off", when: "Yesterday" },
  { id: "M-203", text: "Eastview Apartments — Handover complete", when: "Yesterday" },
  { id: "M-204", text: "Cafe Lumen — Site setup complete", when: "2 days ago" },
];

/* ---------- helpers ---------- */

const statusTone: Record<JobStatus, string> = {
  "On Track": "bg-success/15 text-success border-success/30",
  "Behind": "bg-warning/20 text-warning-foreground border-warning/40",
  "At Risk": "bg-warning/20 text-warning-foreground border-warning/40",
  "Blocked": "bg-critical/15 text-critical border-critical/40",
  "Awaiting Crew": "bg-primary/10 text-primary border-primary/20",
  "Completed": "bg-success/15 text-success border-success/30",
};

function StatusBadge({ status }: { status: JobStatus }) {
  return <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full border ${statusTone[status]}`}>{status}</span>;
}

// dayTone removed — replaced by shared calculateDailyCapacity + capacityTone from @/lib/capacity



function Kpi({
  label, value, hint, icon: Icon, tone,
}: { label: string; value: string; hint: string; icon: typeof Briefcase; tone: "primary" | "accent" | "success" | "warning" | "critical" }) {
  const toneCls = {
    primary: "bg-primary/10 text-primary",
    accent: "bg-accent/20 text-accent-foreground",
    success: "bg-success/15 text-success",
    warning: "bg-warning/20 text-warning-foreground",
    critical: "bg-critical/15 text-critical",
  }[tone];
  return (
    <Card>
      <CardContent className="p-5 flex items-start gap-4">
        <div className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${toneCls}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
          <div className="text-2xl font-bold mt-0.5">{value}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>
        </div>
      </CardContent>
    </Card>
  );
}

const attentionMeta = {
  delayed: { icon: Clock, tone: "text-warning-foreground bg-warning/20", label: "Delayed" },
  "low-progress": { icon: TrendingDown, tone: "text-critical bg-critical/15", label: "Low progress" },
  unassigned: { icon: UserX, tone: "text-primary bg-primary/10", label: "Unassigned" },
  admin: { icon: FileText, tone: "text-accent-foreground bg-accent/20", label: "Admin review" },
} as const;

/* ---------- page ---------- */

function Dashboard() {
  const overbookedDays = week.filter(d => d.booked > d.available).length;
  const totalAvail = week.reduce((s, d) => s + Math.max(d.available - d.booked, 0), 0);
  const { data: myRoles = [] } = useMyRoles();
  const primary = pickPrimaryRole(myRoles);
  const [view, setView] = useState<AppRole>(primary);

  // View filter: crew leader sees only their crew (mock: Crew Alpha); contractor sees a "my assignments" pane.
  const visibleJobs = view === "crew_leader"
    ? todaysJobs.filter((j) => j.crew === "Crew Alpha")
    : todaysJobs;

  return (
    <div className="space-y-6">
      {/* Role view switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Eye className="h-3.5 w-3.5" /> Viewing as
        </div>
        <Tabs value={view} onValueChange={(v) => setView(v as AppRole)}>
          <TabsList>
            <TabsTrigger value="owner">{ROLE_LABELS.owner}</TabsTrigger>
            <TabsTrigger value="ops_manager">{ROLE_LABELS.ops_manager}</TabsTrigger>
            <TabsTrigger value="crew_leader">{ROLE_LABELS.crew_leader}</TabsTrigger>
            <TabsTrigger value="contractor">{ROLE_LABELS.contractor}</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Phase 2.1 — Financial Capacity Engine (owner/admin) */}
      {(view === "owner" || view === "admin") && <ExecutiveRevenueStrip />}

      {view === "contractor" && <MyAssignmentsPanel compact />}


      {/* Page header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">Operations overview</h2>
          <p className="text-sm text-muted-foreground">
            Today is <span className="font-medium text-foreground">Wednesday, June 24</span> · 5 crews on site, {overbookedDays} overbooked day this week.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to="/capacity"><CalendarClock className="h-4 w-4" /> Open calendar</Link>
          </Button>
          <Button size="sm" asChild>
            <Link to="/jobs"><Briefcase className="h-4 w-4" /> View jobs</Link>
          </Button>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <Kpi label="Active jobs" value="12" hint="Across 5 crews" icon={Briefcase} tone="primary" />
        <Kpi label="Starting this week" value="4" hint="2 awaiting crew" icon={CalendarClock} tone="accent" />
        <Kpi label="Behind schedule" value="3" hint="1 critical · needs review" icon={AlertTriangle} tone="critical" />
        <Kpi label="Available capacity" value={`${totalAvail}h`} hint="Painter-hours this week" icon={Users} tone="success" />
        <Kpi label="Overbooked days" value={String(overbookedDays)} hint="Next 7 days" icon={Wrench} tone="warning" />
        <Kpi label="Ready for invoice" value={`$${(billingReady.reduce((s, b) => s + b.value, 0) / 1000).toFixed(0)}k`} hint={`${billingReady.length} jobs · admin queue`} icon={DollarSign} tone="success" />
      </div>

      {/* Today's operations */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Today's operations</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">Wednesday, June 24 · 5 jobs on site</p>
          </div>
          <Badge variant="outline" className="gap-1.5">
            <span className="h-2 w-2 rounded-full bg-success" /> Live
          </Badge>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job</TableHead>
                <TableHead>Crew</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-44">Completion</TableHead>
                <TableHead>Blocker</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {visibleJobs.map((j) => (
                <TableRow key={j.id} className="hover:bg-muted/30">
                  <TableCell>
                    <Link to="/jobs/$jobId" params={{ jobId: j.id }} className="block">
                      <div className="font-medium hover:underline">{j.name}</div>
                      <div className="text-xs text-muted-foreground">
                        <span className="font-mono">{j.id}</span> · {j.site}
                      </div>
                    </Link>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{j.crew}</div>
                    <div className="text-xs text-muted-foreground">{j.lead}</div>
                  </TableCell>
                  <TableCell><StatusBadge status={j.status} /></TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={j.progress} className="h-1.5 flex-1" />
                      <span className="text-xs tabular-nums w-8 text-right">{j.progress}%</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    {j.blocker
                      ? <span className="inline-flex items-center gap-1.5 text-xs text-critical"><AlertTriangle className="h-3.5 w-3.5" /> {j.blocker}</span>
                      : <span className="text-xs text-muted-foreground">—</span>}
                  </TableCell>
                </TableRow>
              ))}

            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Weekly capacity */}
      <Card>
        <CardHeader>
          <CardTitle>Weekly capacity</CardTitle>
          <p className="text-xs text-muted-foreground mt-1">Painter-hours booked vs available · week of Jun 22</p>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 grid-cols-2 sm:grid-cols-4 lg:grid-cols-7">
            {week.map((d) => {
              const cap = calculateDailyCapacity({ staffHours: d.available, bookedHours: d.booked });
              const tone = capacityTone(cap.status);
              const pct = Math.min(cap.utilizationPct, 100);
              const ring =
                cap.status === "Overbooked"
                  ? "border-critical/40"
                  : cap.status === "Full"
                  ? "border-warning/40"
                  : cap.status === "Near Capacity"
                  ? "border-warning/30"
                  : "border-success/30";
              return (
                <div key={d.day} className={`rounded-xl border ${ring} bg-card p-4`}>
                  <div className="flex items-baseline justify-between">
                    <div>
                      <div className="text-sm font-semibold">{d.day}</div>
                      <div className="text-[11px] text-muted-foreground">{d.date}</div>
                    </div>
                    <CapacityBadge status={cap.status} utilization={cap.utilizationPct} />
                  </div>
                  <div className="mt-3 h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className={`h-full ${tone.bar}`} style={{ width: `${pct}%` }} />
                  </div>
                  <div className="mt-3 space-y-0.5 text-xs">
                    <div className="flex justify-between"><span className="text-muted-foreground">Booked</span><span className="font-medium">{cap.bookedHours}h</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Available</span><span className="font-medium">{cap.availableHours}h</span></div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Remaining</span>
                      <span className={`font-semibold ${cap.remainingHours < 0 ? "text-critical" : cap.remainingHours === 0 ? "text-warning" : "text-success"}`}>
                        {cap.remainingHours > 0 ? `+${cap.remainingHours}` : cap.remainingHours}h
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Attention + Admin */}
      <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Jobs needing attention</CardTitle>
            <Badge variant="outline">{attention.length}</Badge>
          </CardHeader>
          <CardContent className="space-y-2">
            {attention.map((a) => {
              const meta = attentionMeta[a.type];
              const Icon = meta.icon;
              return (
                <div key={a.id} className="flex items-center gap-3 rounded-lg border border-border p-3">
                  <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${meta.tone}`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-muted-foreground">{a.id}</span>
                      <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{meta.label}</span>
                    </div>
                    <div className="font-medium text-sm truncate">{a.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{a.reason} · {a.owner}</div>
                  </div>
                  <Button variant="ghost" size="sm" asChild>
                    <Link to="/jobs/$jobId" params={{ jobId: a.id }}>Open</Link>
                  </Button>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Admin & billing snapshot</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Ready to invoice</div>
                <Badge className="bg-success text-success-foreground hover:bg-success">
                  ${(billingReady.reduce((s, b) => s + b.value, 0) / 1000).toFixed(0)}k
                </Badge>
              </div>
              <div className="space-y-1.5">
                {billingReady.map((b) => (
                  <div key={b.id} className="flex items-center justify-between text-sm rounded-md px-3 py-2 bg-muted/50">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{b.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{b.client} · completed {b.completed}</div>
                    </div>
                    <div className="font-semibold tabular-nums">${b.value.toLocaleString()}</div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Pending progress update</div>
              <div className="space-y-1.5">
                {pendingUpdate.map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm rounded-md px-3 py-2 border border-border">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.crew}</div>
                    </div>
                    <span className="text-xs text-warning-foreground">{p.lastUpdate}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Recent milestones</div>
              <ul className="space-y-1.5">
                {milestones.map((m) => (
                  <li key={m.id} className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-success shrink-0 mt-0.5" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate">{m.text}</div>
                      <div className="text-xs text-muted-foreground">{m.when}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
