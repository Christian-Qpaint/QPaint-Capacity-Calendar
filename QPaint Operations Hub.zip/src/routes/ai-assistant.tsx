import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  PaintRoller,
  Send,
  Database,
  AlertTriangle,
  Activity,
  Calendar,
  FileText,
  Bell,
  ExternalLink,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/ai-assistant")({
  head: () => ({
    meta: [
      { title: "AI Assistant · QPaint" },
      {
        name: "description",
        content:
          "Ask the QPaint assistant about jobs, crews, capacity, progress, and billing readiness.",
      },
    ],
  }),
  component: () => (
    <RequireRole roles={ACCESS.ai}>
      <AssistantPage />
    </RequireRole>
  ),
});

// ---------- mock response model ----------
interface ActionBtn {
  label: string;
  icon: typeof Calendar;
  to?: string;
}

interface CardBlock {
  type: "card";
  title: string;
  metric?: string;
  tone?: "default" | "success" | "warning" | "critical";
  items?: string[];
}

interface BulletBlock {
  type: "bullets";
  title?: string;
  items: string[];
}

interface SummaryBlock {
  type: "summary";
  text: string;
}

type ResponseBlock = CardBlock | BulletBlock | SummaryBlock;

interface AssistantReply {
  blocks: ResponseBlock[];
  actions: ActionBtn[];
}

interface Message {
  id: string;
  from: "user" | "assistant";
  text?: string;
  reply?: AssistantReply;
}

// ---------- canned mock answers ----------
const cannedResponses: { match: RegExp; reply: AssistantReply }[] = [
  {
    match: /status.*today|today.*status|what.*today/i,
    reply: {
      blocks: [
        {
          type: "summary",
          text: "Today there are 8 active jobs. 2 jobs are at risk, 1 crew is overbooked on Thursday, and 3 jobs are ready for admin billing review.",
        },
        {
          type: "card",
          title: "Today's snapshot",
          items: [
            "Active jobs: 8",
            "Crews on site: 4",
            "Jobs at risk: 2",
            "Ready for invoice: 3",
          ],
        },
      ],
      actions: [
        { label: "View jobs", icon: ExternalLink, to: "/jobs" },
        { label: "Open calendar", icon: Calendar, to: "/capacity" },
        { label: "Generate report", icon: FileText, to: "/reports" },
      ],
    },
  },
  {
    match: /behind.*schedul|delayed|at risk/i,
    reply: {
      blocks: [
        {
          type: "summary",
          text: "2 jobs are tracking behind their planned progress this week.",
        },
        {
          type: "bullets",
          title: "Behind schedule",
          items: [
            "QP-1044 · Northside Medical Fitout — actual 35% vs planned 48% (−13%)",
            "QP-1045 · Wattle Primary School — on hold, client access delay",
          ],
        },
      ],
      actions: [
        { label: "View jobs", icon: ExternalLink, to: "/jobs" },
        { label: "Open calendar", icon: Calendar, to: "/capacity" },
        { label: "Notify admin", icon: Bell },
      ],
    },
  },
  {
    match: /overbook|capacity.*week|crews.*week/i,
    reply: {
      blocks: [
        {
          type: "summary",
          text: "Crew Alpha is overbooked on Thursday (Jul 02) — 42h booked vs 38h available.",
        },
        {
          type: "card",
          title: "Capacity flags",
          tone: "warning",
          items: [
            "Crew Alpha · Thu Jul 02 · +4h over",
            "Crew Charlie · near full (94%)",
            "Crew Echo · 30% utilization — has room",
          ],
        },
      ],
      actions: [
        { label: "Open calendar", icon: Calendar, to: "/capacity" },
        { label: "View crews", icon: ExternalLink, to: "/crews" },
      ],
    },
  },
  {
    match: /ready.*invoice|billing/i,
    reply: {
      blocks: [
        {
          type: "summary",
          text: "3 jobs are ready for invoice — combined value $261,200.",
        },
        {
          type: "bullets",
          title: "Ready for invoice",
          items: [
            "QP-1039 · Eastview Apartments · $102,300",
            "QP-1040 · Harbour Office Tower L12 · $158,900",
            "QP-1037 · Bayside Retail Refresh · $39,400",
          ],
        },
      ],
      actions: [
        { label: "View jobs", icon: ExternalLink, to: "/jobs" },
        { label: "Generate report", icon: FileText, to: "/reports" },
        { label: "Notify admin", icon: Bell },
      ],
    },
  },
  {
    match: /fit.*new.*job|new.*3.day|fit.*next week/i,
    reply: {
      blocks: [
        {
          type: "summary",
          text: "Yes — a 3-day job can fit next week using Crew Echo (Mon–Wed) or Crew Bravo (Wed–Fri).",
        },
        {
          type: "card",
          title: "Recommended slot",
          tone: "success",
          items: [
            "Crew Echo · Mon Jun 29 – Wed Jul 01",
            "114h available, no conflicts",
            "Lead: Tom Becker",
          ],
        },
      ],
      actions: [
        { label: "Open calendar", icon: Calendar, to: "/capacity" },
        { label: "View Crew Echo", icon: ExternalLink, to: "/crews" },
      ],
    },
  },
  {
    match: /low progress/i,
    reply: {
      blocks: [
        {
          type: "bullets",
          title: "Jobs with low progress",
          items: [
            "QP-1045 · Wattle Primary School — 18% (on hold)",
            "QP-1044 · Northside Medical Fitout — 35%",
            "QP-1043 · Cafe Lumen Interior — 0% (starts Fri)",
          ],
        },
      ],
      actions: [
        { label: "View jobs", icon: ExternalLink, to: "/jobs" },
        { label: "Notify admin", icon: Bell },
      ],
    },
  },
  {
    match: /changed.*yesterday|since yesterday/i,
    reply: {
      blocks: [
        {
          type: "bullets",
          title: "Changes since yesterday",
          items: [
            "QP-1039 marked Completed — ready for invoice",
            "QP-1044 progress +8% (now 35%)",
            "Crew Delta: 1 painter called in sick",
            "New conflict flagged: Crew Alpha Jul 02",
          ],
        },
      ],
      actions: [
        { label: "Open calendar", icon: Calendar, to: "/capacity" },
        { label: "Generate report", icon: FileText, to: "/reports" },
      ],
    },
  },
];

const fallbackReply: AssistantReply = {
  blocks: [
    {
      type: "summary",
      text: "I can answer questions about jobs, crews, capacity, progress, and billing. Try one of the suggested questions on the right.",
    },
  ],
  actions: [
    { label: "Open calendar", icon: Calendar, to: "/capacity" },
    { label: "Generate report", icon: FileText, to: "/reports" },
  ],
};

function getReply(prompt: string): AssistantReply {
  for (const r of cannedResponses) if (r.match.test(prompt)) return r.reply;
  return fallbackReply;
}

const suggestedQuestions = [
  "What is the status today?",
  "Which jobs are behind schedule?",
  "Which crews are overbooked this week?",
  "What jobs are ready for invoice?",
  "Can we fit a new 3-day job next week?",
  "Which jobs have low progress?",
  "What changed since yesterday?",
];

const dataSources = [
  { label: "Jobs database", count: "24 active" },
  { label: "Crew schedules", count: "6 crews" },
  { label: "Staff roster", count: "24 painters" },
  { label: "Billing queue", count: "3 ready" },
  { label: "Time entries", count: "this week" },
];

const recentUpdates = [
  { text: "QP-1039 marked Completed", time: "12 min ago", tone: "success" as const },
  { text: "QP-1044 progress updated to 35%", time: "1h ago", tone: "default" as const },
  { text: "Crew Delta: 1 painter on sick leave", time: "2h ago", tone: "warning" as const },
];

const capacityAlerts = [
  { text: "Crew Alpha overbooked Thu Jul 02 (+4h)", tone: "critical" as const },
  { text: "Crew Charlie near full (94%)", tone: "warning" as const },
  { text: "Crew Echo idle Mon–Wed", tone: "default" as const },
];

// ---------- page ----------
function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "m0",
      from: "assistant",
      reply: {
        blocks: [
          {
            type: "summary",
            text: "Hi Sam — I can help with jobs, crews, capacity and billing. Try a suggested question on the right, or ask anything.",
          },
        ],
        actions: [],
      },
    },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed) return;
    const userMsg: Message = { id: `u-${Date.now()}`, from: "user", text: trimmed };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setThinking(true);
    try {
      const { askAssistant } = await import("@/lib/ai.functions");
      const { reply } = await askAssistant({ data: { question: trimmed } });
      setMessages((m) => [
        ...m,
        { id: `a-${Date.now()}`, from: "assistant", reply: { blocks: [{ type: "summary", text: reply }], actions: [] } },
      ]);
    } catch (err) {
      console.error("[assistant:send]", err);
      setMessages((m) => [
        ...m,
        { id: `a-${Date.now()}`, from: "assistant", reply: { blocks: [{ type: "summary", text: "Sorry — the assistant failed to respond. Try again in a moment." }], actions: [] } },
      ]);
    } finally {
      setThinking(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      {/* Chat */}
      <Card className="flex flex-col h-[calc(100vh-8rem)]">
        <CardHeader className="border-b border-border">
          <CardTitle className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-accent-foreground shadow-sm">
              <PaintRoller className="h-4 w-4" />
            </span>
            <div className="leading-tight">
              <div>QPaint Operations Assistant</div>
              <div className="text-[11px] font-normal text-muted-foreground -mt-0.5">
                Answers about jobs, crews, capacity, progress and billing
              </div>
            </div>
            <Badge variant="outline" className="ml-2 text-[10px]">Live</Badge>
          </CardTitle>
        </CardHeader>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-5">
          {messages.map((m) => (
            <MessageBubble key={m.id} m={m} />
          ))}
          {thinking && (
            <div className="flex">
              <div className="flex items-center gap-2 rounded-2xl bg-muted px-4 py-2.5 text-sm text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-pulse" />
                <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-pulse [animation-delay:120ms]" />
                <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-pulse [animation-delay:240ms]" />
                <span className="ml-1">Thinking…</span>
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-border p-3">
          <div className="flex gap-2 items-end">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder="Ask about jobs, crews, capacity, or billing…"
              className="min-h-[44px] max-h-32 resize-none"
            />
            <Button onClick={() => send(input)} size="icon" aria-label="Send" disabled={!input.trim() || thinking}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>

      {/* Context panel */}
      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Database className="h-4 w-4 text-muted-foreground" /> Data sources
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5 text-sm">
            {dataSources.map((d) => (
              <div key={d.label} className="flex justify-between items-center">
                <span>{d.label}</span>
                <span className="text-xs text-muted-foreground">{d.count}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Activity className="h-4 w-4 text-muted-foreground" /> Recent updates
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {recentUpdates.map((u, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className={`mt-1.5 h-1.5 w-1.5 rounded-full shrink-0 ${
                  u.tone === "success" ? "bg-success" : u.tone === "warning" ? "bg-warning" : "bg-primary"
                }`} />
                <div className="flex-1">
                  <div className="text-foreground">{u.text}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {u.time}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" /> Capacity alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {capacityAlerts.map((a, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className={`mt-1.5 h-1.5 w-1.5 rounded-full shrink-0 ${
                  a.tone === "critical" ? "bg-critical" : a.tone === "warning" ? "bg-warning" : "bg-muted-foreground"
                }`} />
                <span>{a.text}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Suggested questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {suggestedQuestions.map((q) => (
              <button
                key={q}
                onClick={() => send(q)}
                className="w-full text-left text-sm rounded-lg border border-border bg-card hover:bg-muted px-3 py-2 transition-colors"
              >
                {q}
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function MessageBubble({ m }: { m: Message }) {
  if (m.from === "user") {
    return (
      <div className="flex justify-end">
        <div className="max-w-[80%] rounded-2xl rounded-br-sm bg-primary text-primary-foreground px-4 py-2.5 text-sm">
          {m.text}
        </div>
      </div>
    );
  }
  const reply = m.reply!;
  return (
    <div className="flex gap-3">
      <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-accent text-accent-foreground shadow-sm">
        <PaintRoller className="h-4 w-4" />
      </span>
      <div className="max-w-[85%] space-y-3">
        {reply.blocks.map((b, i) => (
          <ReplyBlock key={i} block={b} />
        ))}
        {reply.actions.length > 0 && (
          <>
            <Separator className="my-2" />
            <div className="flex flex-wrap gap-2">
              {reply.actions.map((a) => {
                const Icon = a.icon;
                const content = (
                  <>
                    <Icon className="h-3.5 w-3.5 mr-1.5" />
                    {a.label}
                  </>
                );
                return a.to ? (
                  <Button key={a.label} asChild variant="outline" size="sm">
                    <Link to={a.to}>{content}</Link>
                  </Button>
                ) : (
                  <Button key={a.label} variant="outline" size="sm">
                    {content}
                  </Button>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function ReplyBlock({ block }: { block: ResponseBlock }) {
  if (block.type === "summary") {
    return <div className="text-sm leading-relaxed text-foreground">{block.text}</div>;
  }
  if (block.type === "bullets") {
    return (
      <div className="rounded-xl border border-border bg-card p-3">
        {block.title && (
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
            {block.title}
          </div>
        )}
        <ul className="space-y-1.5 text-sm">
          {block.items.map((it, i) => (
            <li key={i} className="flex gap-2">
              <CheckCircle2 className="h-3.5 w-3.5 mt-0.5 text-primary shrink-0" />
              <span>{it}</span>
            </li>
          ))}
        </ul>
      </div>
    );
  }
  // card
  const toneClass =
    block.tone === "success"
      ? "border-success/30 bg-success/5"
      : block.tone === "warning"
      ? "border-warning/30 bg-warning/5"
      : block.tone === "critical"
      ? "border-critical/30 bg-critical/5"
      : "border-border bg-card";
  return (
    <div className={`rounded-xl border p-3 ${toneClass}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {block.title}
        </div>
        {block.metric && <div className="text-lg font-bold">{block.metric}</div>}
      </div>
      {block.items && (
        <ul className="space-y-1 text-sm">
          {block.items.map((it, i) => (
            <li key={i} className="text-foreground/90">• {it}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
