import { createFileRoute } from "@tanstack/react-router";

// One-shot bootstrap: creates the initial owner user if it doesn't exist
// and grants the 'owner' role. Idempotent. Safe to call multiple times.
// GET /api/public/bootstrap-owner
export const Route = createFileRoute("/api/public/bootstrap-owner")({
  server: {
    handlers: {
      GET: async () => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const email = "christian@qpaint.com.au";
        const password = "QPaint#Temp2026!";

        // Try to find existing user
        let userId: string | null = null;
        const { data: list, error: listErr } = await supabaseAdmin.auth.admin.listUsers({
          page: 1,
          perPage: 200,
        });
        if (listErr) {
          return new Response(JSON.stringify({ ok: false, step: "list", error: listErr.message }), {
            status: 500,
            headers: { "content-type": "application/json" },
          });
        }
        const existing = list.users.find((u) => u.email?.toLowerCase() === email.toLowerCase());
        if (existing) {
          userId = existing.id;
          // Reset password to the documented temp password so login always works.
          await supabaseAdmin.auth.admin.updateUserById(existing.id, {
            password,
            email_confirm: true,
          });
        } else {
          const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
            email,
            password,
            email_confirm: true,
          });
          if (createErr || !created.user) {
            return new Response(
              JSON.stringify({ ok: false, step: "create", error: createErr?.message }),
              { status: 500, headers: { "content-type": "application/json" } },
            );
          }
          userId = created.user.id;
        }

        // Grant owner role (idempotent)
        const { error: roleErr } = await supabaseAdmin
          .from("user_roles")
          .upsert({ user_id: userId, role: "owner" }, { onConflict: "user_id,role" });
        if (roleErr) {
          return new Response(
            JSON.stringify({ ok: false, step: "role", error: roleErr.message, userId }),
            { status: 500, headers: { "content-type": "application/json" } },
          );
        }

        return new Response(
          JSON.stringify({ ok: true, email, userId, tempPassword: password }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      },
    },
  },
});
