import { createFileRoute } from "@tanstack/react-router";
import { MyAssignmentsPanel } from "@/components/MyAssignmentsPanel";

export const Route = createFileRoute("/my-assignments")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "My Assignments · QPaint Capacity OS" },
      { name: "description", content: "Contractor view: jobs you're scheduled on, hours logged, and earnings." },
    ],
  }),
  component: MyAssignmentsPage,
});

function MyAssignmentsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">My assignments</h2>
        <p className="text-sm text-muted-foreground">Everything scheduled for you — hours, rates and job status in one place.</p>
      </div>
      <MyAssignmentsPanel />
    </div>
  );
}
