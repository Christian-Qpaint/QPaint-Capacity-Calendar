import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertTriangle, CalendarOff, Mail, MoreHorizontal, Pencil,
  Phone, Plus, Search, UserPlus, X,
} from "lucide-react";
import { AddStaffModal, AddLeaveModal } from "@/components/modals";
import { RequireRole, ACCESS } from "@/components/RequireRole";

export const Route = createFileRoute("/staff")({
  head: () => ({
    meta: [
      { title: "Staff · QPaint" },
      { name: "description", content: "Manage staff availability, leave, sick days and weekly capacity." },
    ],
  }),
  component: () => (
    <RequireRole roles={ACCESS.people}>
      <StaffPage />
    </RequireRole>
  ),
});

/* ---------- data ---------- */

type DayStatus = "Available" | "Assigned" | "Leave" | "Sick" | "Unavailable" | "Training";

interface Staff {
  id: string;
  name: string;
  role: string;
  crew: string;
  skills: string[];
  normalHours: number;
  currentJob: string | null;
  phone: string;
  email: string;
  week: DayStatus[];         // length 7, Mon..Sun
  upcoming: { date: string; text: string }[];
  leaveHistory: { range: string; type: string }[];
  notes: string;
}

const staff: Staff[] = [
  {
    id: "S-01", name: "Jordan Mills", role: "Crew Lead", crew: "Residential A",
    skills: ["Interior", "Exterior", "Heritage"], normalHours: 40,
    currentJob: "Marina Heights Repaint",
    phone: "+61 412 884 110", email: "jordan.m@qpaint.au",
    week: ["Assigned","Assigned","Assigned","Assigned","Assigned","Available","Available"],
    upcoming: [
      { date: "Jul 03", text: "Eastview handover walkthrough" },
      { date: "Jul 07", text: "Quote — Vaucluse villa" },
    ],
    leaveHistory: [{ range: "May 5–9", type: "Annual leave" }],
    notes: "Preferred lead for heritage repaints.",
  },
  {
    id: "S-02", name: "Priya Shah", role: "Crew Lead", crew: "Residential B",
    skills: ["Interior", "Trim & doors"], normalHours: 40,
    currentJob: "Glenwood Townhouses Block C",
    phone: "+61 412 884 120", email: "priya.s@qpaint.au",
    week: ["Assigned","Assigned","Assigned","Available","Available","Available","Available"],
    upcoming: [{ date: "Jun 26", text: "Cafe Lumen interior — start" }],
    leaveHistory: [],
    notes: "",
  },
  {
    id: "S-03", name: "Marco Diaz", role: "Crew Lead", crew: "Commercial",
    skills: ["Commercial", "Spray", "After-hours"], normalHours: 45,
    currentJob: "Northside Medical Fitout",
    phone: "+61 412 884 130", email: "marco.d@qpaint.au",
    week: ["Assigned","Assigned","Assigned","Assigned","Assigned","Assigned","Unavailable"],
    upcoming: [{ date: "Jul 10", text: "Site handover Chatswood" }],
    leaveHistory: [],
    notes: "Overtime approved through Jul 10.",
  },
  {
    id: "S-04", name: "Anna Kovac", role: "Crew Lead", crew: "Touch-up",
    skills: ["Fine finishing", "Defects"], normalHours: 38,
    currentJob: "Wattle Primary School",
    phone: "+61 412 884 140", email: "anna.k@qpaint.au",
    week: ["Assigned","Assigned","Assigned","Assigned","Training","Available","Available"],
    upcoming: [{ date: "Jun 26", text: "Spray gun certification refresher" }],
    leaveHistory: [{ range: "Apr 1–5", type: "Annual leave" }],
    notes: "",
  },
  {
    id: "S-05", name: "Tom Becker", role: "Crew Lead", crew: "Prep Team",
    skills: ["Prep", "Sanding", "Patch & repair"], normalHours: 40,
    currentJob: null,
    phone: "+61 412 884 150", email: "tom.b@qpaint.au",
    week: ["Available","Available","Assigned","Assigned","Assigned","Available","Available"],
    upcoming: [{ date: "Jun 24", text: "Prep for Cliffside exterior" }],
    leaveHistory: [],
    notes: "Available for overflow this week.",
  },
  {
    id: "S-06", name: "Lila Nguyen", role: "Painter", crew: "Residential A",
    skills: ["Interior", "Wallpaper"], normalHours: 40,
    currentJob: "Marina Heights Repaint",
    phone: "+61 412 884 160", email: "lila.n@qpaint.au",
    week: ["Assigned","Assigned","Assigned","Assigned","Assigned","Available","Available"],
    upcoming: [], leaveHistory: [], notes: "",
  },
  {
    id: "S-07", name: "Ben Carter", role: "Painter", crew: "Residential B",
    skills: ["Interior", "Trim"], normalHours: 40,
    currentJob: null,
    phone: "+61 412 884 170", email: "ben.c@qpaint.au",
    week: ["Leave","Leave","Leave","Leave","Leave","Unavailable","Unavailable"],
    upcoming: [{ date: "Jun 29", text: "Returns from leave" }],
    leaveHistory: [{ range: "Jun 22–26", type: "Annual leave" }],
    notes: "Annual leave — pre-approved.",
  },
  {
    id: "S-08", name: "Henry Liu", role: "Apprentice", crew: "Commercial",
    skills: ["Prep", "Trainee"], normalHours: 38,
    currentJob: "Northside Medical Fitout",
    phone: "+61 412 884 180", email: "henry.l@qpaint.au",
    week: ["Assigned","Training","Assigned","Assigned","Assigned","Available","Available"],
    upcoming: [{ date: "Jun 23", text: "TAFE day" }],
    leaveHistory: [], notes: "Mentored by Marco.",
  },
  {
    id: "S-09", name: "Sara Okafor", role: "Painter", crew: "Touch-up",
    skills: ["Fine finishing"], normalHours: 40,
    currentJob: null,
    phone: "+61 412 884 190", email: "sara.o@qpaint.au",
    week: ["Sick","Sick","Sick","Available","Available","Available","Available"],
    upcoming: [{ date: "Jun 25", text: "Return-to-work check" }],
    leaveHistory: [{ range: "Jun 22–24", type: "Sick leave" }],
    notes: "Reduced duties on return.",
  },
  {
    id: "S-10", name: "Ravi Khan", role: "Painter", crew: "Prep Team",
    skills: ["Prep", "Exterior"], normalHours: 40,
    currentJob: null,
    phone: "+61 412 884 200", email: "ravi.k@qpaint.au",
    week: ["Available","Available","Available","Available","Available","Available","Available"],
    upcoming: [], leaveHistory: [], notes: "Fully available this week.",
  },
  {
    id: "S-11", name: "Aaron Webb", role: "Painter", crew: "Residential A",
    skills: ["Interior", "Spray"], normalHours: 40,
    currentJob: "Marina Heights Repaint",
    phone: "+61 412 884 210", email: "aaron.w@qpaint.au",
    week: ["Assigned","Assigned","Assigned","Assigned","Assigned","Available","Available"],
    upcoming: [], leaveHistory: [], notes: "",
  },
  {
    id: "S-12", name: "Mei Tan", role: "Painter", crew: "Residential A",
    skills: ["Interior"], normalHours: 32,
    currentJob: "Marina Heights Repaint",
    phone: "+61 412 884 220", email: "mei.t@qpaint.au",
    week: ["Assigned","Assigned","Assigned","Leave","Leave","Unavailable","Unavailable"],
    upcoming: [{ date: "Jun 29", text: "Returns from leave" }],
    leaveHistory: [{ range: "Jun 25–26", type: "Carer's leave" }],
    notes: "Part-time, 4 days/week.",
  },
];

/* ---------- visual ---------- */

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const DATES = ["Jun 22", "Jun 23", "Jun 24", "Jun 25", "Jun 26", "Jun 27", "Jun 28"];

const dayTone: Record<DayStatus, string> = {
  Available:   "bg-success/20 text-success border-success/40",
  Assigned:    "bg-primary text-primary-foreground border-primary",
  Leave:       "bg-warning/30 text-warning-foreground border-warning/40",
  Sick:        "bg-critical/15 text-critical border-critical/40",
  Unavailable: "bg-muted text-muted-foreground border-border",
  Training:    "bg-accent/30 text-accent-foreground border-accent/50",
};

const absentStatuses: DayStatus[] = ["Leave", "Sick", "Unavailable"];

function leaveBadgeFor(s: Staff) {
  if (s.week.every(d => d === "Leave")) return { label: "On leave", tone: "warning" };
  if (s.week.includes("Sick")) return { label: "Sick", tone: "critical" };
  if (s.week.includes("Leave")) return { label: "Partial leave", tone: "warning" };
  if (s.week.includes("Training")) return { label: "Training", tone: "accent" };
  return { label: "Active", tone: "success" };
}
const leaveBadgeTone: Record<string, string> = {
  warning:  "bg-warning/20 text-warning-foreground border-warning/40",
  critical: "bg-critical/15 text-critical border-critical/40",
  success:  "bg-success/15 text-success border-success/30",
  accent:   "bg-accent/20 text-accent-foreground border-accent/40",
};

function availableHoursThisWeek(s: Staff) {
  // Normal day = normalHours/5; absent days subtract that allocation.
  const perDay = s.normalHours / 5;
  const weekdayAbsent = s.week.slice(0, 5).filter(d => absentStatuses.includes(d)).length;
  return Math.max(0, Math.round(s.normalHours - weekdayAbsent * perDay));
}

/* ---------- page ---------- */

function StaffPage() {
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Staff | null>(staff[0]);

  const filtered = useMemo(() => {
    if (!q) return staff;
    const ql = q.toLowerCase();
    return staff.filter(s =>
      `${s.name} ${s.role} ${s.crew} ${s.skills.join(" ")}`.toLowerCase().includes(ql));
  }, [q]);

  const absentToday = staff.filter(s => absentStatuses.includes(s.week[2]));
  const lostHoursToday = absentToday.reduce((sum, s) => sum + s.normalHours / 5, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">Staff</h2>
          <p className="text-sm text-muted-foreground">
            {staff.length} on the roster · {absentToday.length} absent today
          </p>
        </div>
        <div className="flex gap-2">
          <AddLeaveModal trigger={<Button variant="outline" className="gap-1.5"><CalendarOff className="h-4 w-4" /> Add leave / absence</Button>} />
          <AddStaffModal trigger={<Button className="gap-1.5"><UserPlus className="h-4 w-4" /> Add staff member</Button>} />
        </div>
      </div>

      {/* Capacity warning */}
      {absentToday.length > 0 && (
        <div className="flex items-start gap-3 rounded-lg border border-warning/40 bg-warning/10 p-4">
          <AlertTriangle className="h-5 w-5 text-warning-foreground shrink-0 mt-0.5" />
          <div className="text-sm">
            <span className="font-semibold">{absentToday.length} absent today</span> ·
            this reduces available capacity by <span className="font-semibold">{Math.round(lostHoursToday)} hours</span>.
            <span className="text-muted-foreground"> Affected: {absentToday.map(s => s.name).join(", ")}.</span>
          </div>
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="space-y-6 min-w-0">
          {/* Search */}
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search staff, role, skill…" className="pl-9 h-9" />
          </div>

          {/* Roster table */}
          <Card>
            <CardHeader><CardTitle>Roster</CardTitle></CardHeader>
            <CardContent className="p-0 overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Staff</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Crew</TableHead>
                    <TableHead>Skills</TableHead>
                    <TableHead className="text-right">Normal hrs</TableHead>
                    <TableHead className="text-right">Avail this wk</TableHead>
                    <TableHead>Current assignment</TableHead>
                    <TableHead>Leave</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((s) => {
                    const lb = leaveBadgeFor(s);
                    const avail = availableHoursThisWeek(s);
                    const selectedRow = selected?.id === s.id;
                    return (
                      <TableRow
                        key={s.id}
                        onClick={() => setSelected(s)}
                        className={`cursor-pointer ${selectedRow ? "bg-accent/10" : "hover:bg-muted/40"}`}
                      >
                        <TableCell>
                          <div className="flex items-center gap-2.5">
                            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground text-[11px] font-semibold">
                              {s.name.split(" ").map(n => n[0]).join("")}
                            </div>
                            <div className="min-w-0">
                              <Link to="/staff/$staffId" params={{ staffId: s.id }} className="font-medium text-sm truncate hover:underline block" onClick={(e) => e.stopPropagation()}>{s.name}</Link>
                              <div className="text-[11px] text-muted-foreground font-mono">{s.id}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">{s.role}</TableCell>
                        <TableCell className="text-sm">{s.crew}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {s.skills.map((k) => <Badge key={k} variant="outline" className="font-normal text-[10px]">{k}</Badge>)}
                          </div>
                        </TableCell>
                        <TableCell className="text-right tabular-nums">{s.normalHours}h</TableCell>
                        <TableCell className={`text-right tabular-nums font-medium ${avail < s.normalHours ? "text-warning-foreground" : "text-success"}`}>
                          {avail}h
                        </TableCell>
                        <TableCell className="text-sm">{s.currentJob ?? <span className="text-muted-foreground italic">—</span>}</TableCell>
                        <TableCell>
                          <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full border ${leaveBadgeTone[lb.tone]}`}>{lb.label}</span>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{s.phone}</TableCell>
                        <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-44">
                              <DropdownMenuItem><Pencil className="h-4 w-4 mr-2" /> Edit profile</DropdownMenuItem>
                              <DropdownMenuItem><CalendarOff className="h-4 w-4 mr-2" /> Log absence</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem><Plus className="h-4 w-4 mr-2" /> Assign to job</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Weekly availability grid */}
          <Card>
            <CardHeader>
              <CardTitle>Weekly availability</CardTitle>
              <p className="text-xs text-muted-foreground mt-1">Week of Jun 22 · click a staff row above to focus.</p>
            </CardHeader>
            <CardContent className="p-0 overflow-x-auto">
              <div className="min-w-[820px]">
                <div className="grid border-b border-border bg-muted/40" style={{ gridTemplateColumns: "200px repeat(7, minmax(80px, 1fr))" }}>
                  <div className="px-4 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Staff</div>
                  {DAYS.map((d, i) => (
                    <div key={d} className="px-2 py-2 text-center border-l border-border">
                      <div className="text-xs font-semibold">{d}</div>
                      <div className="text-[11px] text-muted-foreground">{DATES[i]}</div>
                    </div>
                  ))}
                </div>
                {filtered.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => setSelected(s)}
                    className={`grid border-b border-border last:border-b-0 cursor-pointer ${selected?.id === s.id ? "bg-accent/10" : "hover:bg-muted/30"}`}
                    style={{ gridTemplateColumns: "200px repeat(7, minmax(80px, 1fr))" }}
                  >
                    <div className="px-4 py-2.5 border-r border-border">
                      <div className="text-sm font-medium truncate">{s.name}</div>
                      <div className="text-[11px] text-muted-foreground">{s.role} · {s.crew}</div>
                    </div>
                    {s.week.map((status, i) => (
                      <div key={i} className={`p-1.5 border-l border-border ${i >= 5 ? "bg-muted/20" : ""}`}>
                        <div className={`text-[10px] font-semibold uppercase tracking-wide text-center rounded px-1 py-1.5 border ${dayTone[status]}`}>
                          {status === "Available" ? "Free" : status === "Unavailable" ? "Off" : status}
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
                {/* legend */}
                <div className="flex flex-wrap gap-3 px-4 py-3 border-t border-border text-xs">
                  {(["Available","Assigned","Leave","Sick","Training","Unavailable"] as DayStatus[]).map((d) => (
                    <div key={d} className="flex items-center gap-1.5">
                      <span className={`inline-block h-3 w-4 rounded border ${dayTone[d]}`} />
                      <span className="text-muted-foreground">{d}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Side panel */}
        <ProfilePanel staff={selected} onClose={() => setSelected(null)} />
      </div>
    </div>
  );
}

function ProfilePanel({ staff, onClose }: { staff: Staff | null; onClose: () => void }) {
  if (!staff) {
    return (
      <Card className="xl:sticky xl:top-20 self-start">
        <CardContent className="p-6 text-center text-sm text-muted-foreground">
          Select a staff member to view their profile and schedule.
        </CardContent>
      </Card>
    );
  }
  const avail = availableHoursThisWeek(staff);
  const lost = staff.normalHours - avail;

  return (
    <Card className="xl:sticky xl:top-20 self-start">
      <CardContent className="p-5 space-y-5">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground text-sm font-semibold">
              {staff.name.split(" ").map(n => n[0]).join("")}
            </div>
            <div className="min-w-0">
              <div className="font-bold truncate">{staff.name}</div>
              <div className="text-xs text-muted-foreground">{staff.role} · {staff.crew}</div>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={onClose}><X className="h-4 w-4" /></Button>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {staff.skills.map((k) => <Badge key={k} variant="outline" className="font-normal">{k}</Badge>)}
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          <Stat label="Normal" value={`${staff.normalHours}h`} />
          <Stat label="Available" value={`${avail}h`} tone={avail < staff.normalHours ? "warning" : "success"} />
          <Stat label="Lost" value={`${lost}h`} tone={lost > 0 ? "critical" : "muted"} />
        </div>

        {lost > 0 && (
          <div className="flex gap-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-xs text-warning-foreground">
            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>This absence reduces available capacity by <span className="font-semibold">{lost}h</span> this week.</span>
          </div>
        )}

        <Section title="Current job">
          <div className="text-sm">{staff.currentJob ?? <span className="text-muted-foreground italic">No active assignment</span>}</div>
        </Section>

        <Section title="Upcoming schedule">
          {staff.upcoming.length === 0
            ? <div className="text-sm text-muted-foreground">Nothing scheduled.</div>
            : <ul className="space-y-1.5">
                {staff.upcoming.map((u, i) => (
                  <li key={i} className="flex gap-2 text-sm">
                    <span className="text-xs font-mono text-muted-foreground w-14 shrink-0">{u.date}</span>
                    <span>{u.text}</span>
                  </li>
                ))}
              </ul>}
        </Section>

        <Section title="Leave history">
          {staff.leaveHistory.length === 0
            ? <div className="text-sm text-muted-foreground">No recent leave.</div>
            : <ul className="space-y-1.5">
                {staff.leaveHistory.map((l, i) => (
                  <li key={i} className="flex gap-2 text-sm">
                    <span className="text-xs font-mono text-muted-foreground w-20 shrink-0">{l.range}</span>
                    <span>{l.type}</span>
                  </li>
                ))}
              </ul>}
        </Section>

        {staff.notes && (
          <Section title="Notes">
            <p className="text-sm">{staff.notes}</p>
          </Section>
        )}

        <div className="flex flex-col gap-2 pt-1">
          <Button variant="outline" size="sm" className="gap-1.5 justify-start"><Phone className="h-4 w-4" /> {staff.phone}</Button>
          <Button variant="outline" size="sm" className="gap-1.5 justify-start"><Mail className="h-4 w-4" /> {staff.email}</Button>
        </div>
      </CardContent>
    </Card>
  );
}

function Stat({ label, value, tone = "muted" }: { label: string; value: string; tone?: "muted" | "success" | "warning" | "critical" }) {
  const cls = {
    muted: "",
    success: "text-success",
    warning: "text-warning-foreground",
    critical: "text-critical",
  }[tone];
  return (
    <div className="rounded-lg border border-border p-2">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={`text-sm font-bold ${cls}`}>{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-1.5">{title}</div>
      {children}
    </div>
  );
}
