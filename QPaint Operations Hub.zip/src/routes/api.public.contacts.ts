import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

function client() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
}

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json",
};

export const Route = createFileRoute("/api/public/contacts")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: cors }),
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const search = url.searchParams.get("q")?.trim().toLowerCase();
        const limit = Math.min(Number(url.searchParams.get("limit") ?? 100), 500);

        const sb = client();
        let query = sb.from("contacts").select("*").order("updated_at", { ascending: false }).limit(limit);
        if (search) {
          query = query.or(
            `name.ilike.%${search}%,email.ilike.%${search}%,phone.ilike.%${search}%,company.ilike.%${search}%`,
          );
        }
        const { data, error } = await query;
        if (error) {
          return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: cors });
        }
        return new Response(JSON.stringify({ data, count: data?.length ?? 0 }), { status: 200, headers: cors });
      },
    },
  },
});
