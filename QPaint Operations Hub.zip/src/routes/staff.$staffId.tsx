/**
 * Staff detail page — /staff/$staffId
 *
 * URL-addressable: any UUID hits the live `staff` table. Unknown slugs render
 * a friendly "not found" so legacy links don't crash.
 */
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { ArrowLeft, Mail, Phone, User } from "lucide-react";
import { staffByIdQuery, crewsQuery, schedulesQuery, jobsQuery } from "@/lib/db";

export const Route = createFileRoute("/staff/$staffId")({
  head: ({ params }) => ({
    meta: [
      { title: `Staff ${params.staffId} · QPaint` },
      { name: "description", content: "Staff profile: role, crew, availability and assignments." },
    ],
  }),
  loader: ({ context, params }) => {
    context.queryClient.ensureQueryData(staffByIdQuery(params.staffId));
    context.queryClient.ensureQueryData(crewsQuery);
    context.queryClient.ensureQueryData(schedulesQuery);
    context.queryClient.ensureQueryData(jobsQuery);
  },
  component: StaffDetailPage,
  errorComponent: ({ error }) => (
    <div className="p-8 text-sm text-critical">Failed to load staff: {error.message}</div>
  ),
});

function StaffDetailPage() {
  const { staffId } = Route.useParams();
  const router = useRouter();
  const { data: staff } = useSuspenseQuery(staffByIdQuery(staffId));
  const { data: crews } = useSuspenseQuery(crewsQuery);
  const { data: schedules } = useSuspenseQuery(schedulesQuery);
  const { data: jobs } = useSuspenseQuery(jobsQuery);

  if (!staff) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" onClick={() => router.history.back()} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
        <Card>
          <CardContent className="p-10 text-center">
            <User className="h-10 w-10 mx-auto text-muted-foreground/40 mb-3" />
            <div className="font-semibold">Staff member not found</div>
            <p className="text-sm text-muted-foreground mt-1">
              No staff record matches <span className="font-mono">{staffId}</span>.
            </p>
            <Link to="/staff" className="inline-block mt-4">
              <Button variant="outline">Back to roster</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const crew = crews.find((c) => c.id === staff.crew_id);
  const upcoming = schedules
    .filter((s) => s.crew_id === staff.crew_id)
    .sort((a, b) => a.scheduled_date.localeCompare(b.scheduled_date))
    .slice(0, 8);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <Button variant="ghost" size="sm" onClick={() => router.history.back()} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
        <Link to="/staff"><Button variant="outline" size="sm">All staff</Button></Link>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start gap-4">
            <div className="grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground text-lg font-semibold shrink-0">
              {staff.full_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
            </div>
            <div className="min-w-0 flex-1">
              <CardTitle className="text-xl">{staff.full_name}</CardTitle>
              <div className="text-sm text-muted-foreground mt-1">{staff.role}</div>
              <div className="flex flex-wrap gap-2 mt-2">
                <Badge variant="outline">{staff.status}</Badge>
                {crew && (
                  <Link to="/crews/$crewId" params={{ crewId: crew.id }}>
                    <Badge variant="outline" className="hover:bg-muted">{crew.name}</Badge>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-3 gap-3">
            <Stat label="Normal hrs/wk" value={`${staff.normal_hours_per_week}h`} />
            <Stat label="Email" value={staff.email ?? "—"} icon={Mail} />
            <Stat label="Phone" value={staff.contact_number ?? "—"} icon={Phone} />
          </div>
          {staff.skills && staff.skills.length > 0 && (
            <div>
              <div className="text-[11px] uppercase tracking-wide text-muted-foreground mb-1.5">Skills</div>
              <div className="flex flex-wrap gap-1.5">
                {staff.skills.map((s) => <Badge key={s} variant="outline" className="font-normal">{s}</Badge>)}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Upcoming crew schedule</CardTitle></CardHeader>
        <CardContent className="p-0">
          {upcoming.length === 0 && <div className="p-6 text-sm text-muted-foreground">No upcoming schedule items for this staff member's crew.</div>}
          <Table>
            <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Job</TableHead><TableHead className="text-right">Planned hrs</TableHead></TableRow></TableHeader>
            <TableBody>
              {upcoming.map((s) => {
                const j = jobs.find((x) => x.id === s.job_id);
                return (
                  <TableRow key={s.id}>
                    <TableCell className="text-sm tabular-nums">{s.scheduled_date}</TableCell>
                    <TableCell>
                      {j ? (
                        <Link to="/jobs/$jobId" params={{ jobId: j.job_code }} className="font-medium hover:underline">
                          {j.job_code} · {j.job_name}
                        </Link>
                      ) : <span className="text-muted-foreground">Unknown job</span>}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{s.planned_hours}h</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function Stat({ label, value, icon: Icon }: { label: string; value: string; icon?: typeof Mail }) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground flex items-center gap-1.5">
        {Icon && <Icon className="h-3 w-3" />} {label}
      </div>
      <div className="text-sm font-semibold mt-0.5 truncate">{value}</div>
    </div>
  );
}
