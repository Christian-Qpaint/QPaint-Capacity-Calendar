import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { PaintRoller, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

import { log } from "@/lib/log";

export const Route = createFileRoute("/auth")({
  ssr: false, // session lives in localStorage; SSR can't read it
  head: () => ({
    meta: [
      { title: "Sign in · QPaint Capacity OS" },
      { name: "description", content: "Sign in to the QPaint operations console." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  // Already signed in? Bounce to the dashboard.
  useEffect(() => {
    let cancelled = false;
    supabase.auth.getUser().then(({ data }) => {
      if (!cancelled && data.user) {
        log.info("auth:already-signed-in", { id: data.user.id });
        navigate({ to: "/" });
      }
    });
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  async function handleEmail(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    log.info("auth:email", { mode, email });
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Signed in");
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Account created — check your email if confirmation is required");
      }
      navigate({ to: "/" });
    } catch (err) {
      log.error("auth:email", err);
      toast.error((err as Error).message ?? "Sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] grid place-items-center px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-3">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-accent text-accent-foreground">
            <PaintRoller className="h-6 w-6" />
          </div>
          <CardTitle className="text-xl">
            {mode === "signin" ? "Sign in to QPaint Ops" : "Create your account"}
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Access jobs, crews, capacity and billing dashboards.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">


          <form onSubmit={handleEmail} className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-xs">Email</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-xs">Password</Label>
              <Input id="password" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : mode === "signin" ? "Sign in" : "Create account"}
            </Button>
          </form>

          <div className="text-center text-xs text-muted-foreground">
            {mode === "signin" ? (
              <button className="hover:underline" onClick={() => setMode("signup")}>
                Don't have an account? Sign up
              </button>
            ) : (
              <button className="hover:underline" onClick={() => setMode("signin")}>
                Already have an account? Sign in
              </button>
            )}
          </div>

          <div className="text-center">
            <Link to="/" className="text-[11px] text-muted-foreground hover:underline">
              Continue without signing in (read-only)
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
