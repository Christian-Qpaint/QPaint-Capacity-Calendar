import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useConfirm } from "@/components/confirm-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Building2,
  Gauge,
  Briefcase,
  Users,
  ShieldCheck,
  Sparkles,
  Upload,
  X,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  KanbanSquare,
} from "lucide-react";
import {
  pipelinesQuery, pipelineStagesQuery,
  createPipeline, updatePipeline, deletePipeline,
  createStage, updateStage, deleteStage,
  crewsQuery,
  appSettingsQuery, revenueTargetsQuery,
  upsertAppSettings, createRevenueTarget, updateRevenueTarget, deleteRevenueTarget,
  type PipelineRow, type PipelineStageRow, type RevenueTargetRow,
} from "@/lib/db";
import { DollarSign, Target } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useMyRoles, ROLE_LABELS, type AppRole } from "@/lib/roles";


export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings · QPaint" },
      {
        name: "description",
        content:
          "Company, capacity, job, crew, admin and AI preferences for QPaint Capacity Management.",
      },
    ],
  }),
  component: SettingsPage,
});

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function SettingsPage() {
  const [workingDays, setWorkingDays] = useState<string[]>(["Mon", "Tue", "Wed", "Thu", "Fri"]);
  const [allowWeekend, setAllowWeekend] = useState(false);
  const [includeContractors, setIncludeContractors] = useState(true);
  const [aiEnabled, setAiEnabled] = useState(true);

  const [jobStatuses, setJobStatuses] = useState<string[]>([
    "Not Started", "Scheduled", "In Progress", "Delayed", "On Hold", "Completed",
  ]);
  const [billingStatuses, setBillingStatuses] = useState<string[]>([
    "Not ready", "Ready for invoice", "Invoiced", "Paid",
  ]);
  const [milestones, setMilestones] = useState<string[]>([
    "Site prep", "Surface prep", "First coat", "Second coat", "Touch-ups", "Client sign-off",
  ]);
  const [crewTypes, setCrewTypes] = useState<string[]>([
    "Residential", "Commercial", "Touch-up", "Prep", "External contractor",
  ]);
  const [skills, setSkills] = useState<string[]>([
    "Interior", "Exterior", "Spray", "Roof", "Heritage", "Epoxy floors", "Line marking",
  ]);
  const [roles, setRoles] = useState<string[]>([
    "Crew Lead", "Painter", "Apprentice", "Prep", "Site Supervisor",
  ]);
  const [billingRecipients, setBillingRecipients] = useState<string[]>([
    "admin@qpaint.com.au", "accounts@qpaint.com.au",
  ]);

  function toggleDay(d: string) {
    setWorkingDays((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]));
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
          <p className="text-sm text-muted-foreground">
            Configure how QPaint plans capacity, manages jobs, and notifies your team.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => toast("Changes discarded")}>Cancel</Button>
          <Button onClick={() => toast.success("Settings saved")}>Save changes</Button>
        </div>

      </div>

      <AccessRolesCard />
      <FinancialSettings />
      <RevenueTargetsManager />

      <PipelinesManager />


      {/* Company */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-4 w-4 text-muted-foreground" /> Company
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="flex items-center gap-4">
            <div className="grid h-20 w-20 place-items-center rounded-lg border-2 border-dashed border-border bg-muted text-muted-foreground">
              <Upload className="h-5 w-5" />
            </div>
            <div className="space-y-1">
              <div className="text-sm font-medium">Company logo</div>
              <div className="text-xs text-muted-foreground">PNG or SVG, square, up to 2MB.</div>
              <Button variant="outline" size="sm">Upload logo</Button>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Company name">
              <Input defaultValue="QPaint Pty Ltd" />
            </Field>
            <Field label="Timezone">
              <Select defaultValue="Australia/Sydney">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Australia/Sydney">Australia/Sydney</SelectItem>
                  <SelectItem value="Australia/Melbourne">Australia/Melbourne</SelectItem>
                  <SelectItem value="Australia/Brisbane">Australia/Brisbane</SelectItem>
                  <SelectItem value="Australia/Perth">Australia/Perth</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Business hours — start">
              <Input type="time" defaultValue="07:00" />
            </Field>
            <Field label="Business hours — end">
              <Input type="time" defaultValue="16:00" />
            </Field>
            <Field label="Default daily staff hours">
              <Input type="number" defaultValue={8} min={1} max={12} />
            </Field>
            <Field label="Default working days">
              <div className="flex flex-wrap gap-1.5 pt-1">
                {DAYS.map((d) => {
                  const active = workingDays.includes(d);
                  return (
                    <button
                      key={d}
                      type="button"
                      onClick={() => toggleDay(d)}
                      className={`h-9 min-w-9 px-3 rounded-md border text-sm transition-colors ${
                        active
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-card border-border hover:bg-muted"
                      }`}
                    >
                      {d}
                    </button>
                  );
                })}
              </div>
            </Field>
          </div>
        </CardContent>
      </Card>

      {/* Capacity Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gauge className="h-4 w-4 text-muted-foreground" /> Capacity rules
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Standard hours per staff / day">
              <Input type="number" defaultValue={8} min={1} max={12} />
            </Field>
            <Field label="Warning threshold (%)" hint="Crew flagged as near full.">
              <Input type="number" defaultValue={85} min={50} max={100} />
            </Field>
            <Field label="Overbooked threshold (%)" hint="Crew flagged as overbooked.">
              <Input type="number" defaultValue={100} min={80} max={150} />
            </Field>
          </div>
          <Separator />
          <ToggleRow
            label="Allow weekend scheduling"
            hint="Permit jobs to be scheduled on Sat/Sun."
            checked={allowWeekend}
            onChange={setAllowWeekend}
          />
          <ToggleRow
            label="Include contractors in capacity"
            hint="Counts external contractors toward total available hours."
            checked={includeContractors}
            onChange={setIncludeContractors}
          />
        </CardContent>
      </Card>

      {/* Job Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="h-4 w-4 text-muted-foreground" /> Job settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <Field label="Default job statuses">
            <ChipEditor items={jobStatuses} onChange={setJobStatuses} placeholder="Add status…" />
          </Field>
          <Field label="Default billing statuses">
            <ChipEditor items={billingStatuses} onChange={setBillingStatuses} placeholder="Add billing status…" />
          </Field>
          <Field label="Default milestone checklist" hint="Applied to every new job.">
            <ChipEditor items={milestones} onChange={setMilestones} placeholder="Add milestone…" />
          </Field>
        </CardContent>
      </Card>

      {/* Crew Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" /> Crew settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <Field label="Crew types">
            <ChipEditor items={crewTypes} onChange={setCrewTypes} placeholder="Add crew type…" />
          </Field>
          <Field label="Skills">
            <ChipEditor items={skills} onChange={setSkills} placeholder="Add skill…" />
          </Field>
          <Field label="Role types">
            <ChipEditor items={roles} onChange={setRoles} placeholder="Add role…" />
          </Field>
        </CardContent>
      </Card>

      {/* Admin Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-muted-foreground" /> Admin
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Default export format">
              <Select defaultValue="csv">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="xlsx">Excel (.xlsx)</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Admin notification email">
              <Input type="email" defaultValue="admin@qpaint.com.au" />
            </Field>
          </div>
          <Field label="Billing report recipients" hint="One email per chip. Sent the weekly billing summary.">
            <ChipEditor items={billingRecipients} onChange={setBillingRecipients} placeholder="Add email…" />
          </Field>
        </CardContent>
      </Card>

      {/* AI Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" /> AI assistant
            <Badge variant="outline" className="ml-2 text-xs">Preview</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <ToggleRow
            label="Enable AI assistant"
            hint="Adds the QPaint Assistant for natural-language queries about jobs and capacity."
            checked={aiEnabled}
            onChange={setAiEnabled}
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Response style">
              <Select defaultValue="concise" disabled={!aiEnabled}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="concise">Concise summaries</SelectItem>
                  <SelectItem value="detailed">Detailed breakdowns</SelectItem>
                  <SelectItem value="bullets">Bullet points</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Permissions">
              <Select defaultValue="read-only" disabled={!aiEnabled}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="read-only">Read-only</SelectItem>
                  <SelectItem value="suggest">Can suggest changes</SelectItem>
                  <SelectItem value="act">Can take actions (with approval)</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <Field label="Data sources" hint="What the assistant is allowed to read.">
            <div className="space-y-2">
              {[
                { id: "jobs", label: "Jobs & milestones", on: true },
                { id: "crews", label: "Crews & schedules", on: true },
                { id: "staff", label: "Staff availability", on: true },
                { id: "billing", label: "Billing & invoices", on: true },
                { id: "notes", label: "Notes & blockers", on: false },
              ].map((s) => (
                <DataSourceRow key={s.id} label={s.label} defaultChecked={s.on} disabled={!aiEnabled} />
              ))}
            </div>
          </Field>
          <Field label="Custom instructions">
            <Textarea
              disabled={!aiEnabled}
              placeholder="e.g. Always include the affected crew name in alerts."
              className="min-h-20"
            />
          </Field>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2 pb-4">
        <Button variant="outline" onClick={() => toast("Changes discarded")}>Cancel</Button>
        <Button onClick={() => toast.success("Settings saved")}>Save changes</Button>
      </div>

    </div>
  );
}

// ---------- small helpers ----------
function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium">{label}</Label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function ToggleRow({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <div className="text-sm font-medium">{label}</div>
        {hint && <div className="text-xs text-muted-foreground">{hint}</div>}
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

function DataSourceRow({
  label,
  defaultChecked,
  disabled,
}: {
  label: string;
  defaultChecked: boolean;
  disabled?: boolean;
}) {
  const [on, setOn] = useState(defaultChecked);
  return (
    <div className="flex items-center justify-between rounded-md border border-border bg-card px-3 py-2">
      <span className="text-sm">{label}</span>
      <Switch checked={on} onCheckedChange={setOn} disabled={disabled} />
    </div>
  );
}

function ChipEditor({
  items,
  onChange,
  placeholder,
}: {
  items: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
}) {
  const [draft, setDraft] = useState("");
  function add() {
    const v = draft.trim();
    if (!v || items.includes(v)) return;
    onChange([...items, v]);
    setDraft("");
  }
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1.5">
        {items.map((it) => (
          <Badge key={it} variant="secondary" className="gap-1 pr-1 py-1">
            {it}
            <button
              type="button"
              onClick={() => onChange(items.filter((x) => x !== it))}
              className="rounded hover:bg-background/60 p-0.5"
              aria-label={`Remove ${it}`}
            >
              <X className="h-3 w-3" />
            </button>
          </Badge>
        ))}
      </div>
      <div className="flex gap-2">
        <Input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add();
            }
          }}
          placeholder={placeholder}
        />
        <Button type="button" variant="outline" onClick={add}>Add</Button>
      </div>
    </div>
  );
}

/* ---------------- Pipelines Manager ---------------- */

function PipelinesManager() {
  const qc = useQueryClient();
  const { data: pipelines = [] } = useQuery(pipelinesQuery);
  const { data: stages = [] } = useQuery(pipelineStagesQuery);
  const [newPipeName, setNewPipeName] = useState("");
  const [newPipeAuto, setNewPipeAuto] = useState(false);

  function invalidate() {
    qc.invalidateQueries({ queryKey: ["pipelines"] });
    qc.invalidateQueries({ queryKey: ["pipeline_stages"] });
  }

  async function addPipeline() {
    if (!newPipeName.trim()) return;
    try {
      await createPipeline({ name: newPipeName.trim(), auto_schedule: newPipeAuto });
      toast.success("Pipeline added");
      setNewPipeName("");
      setNewPipeAuto(false);
      invalidate();
    } catch { toast.error("Could not create pipeline"); }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <KanbanSquare className="h-4 w-4 text-muted-foreground" /> CRM pipelines
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <p className="text-xs text-muted-foreground">
          Each pipeline has its own Kanban board on the CRM page. Turn on <em>auto-schedule</em> to push deals onto the Capacity Calendar when they enter the pipeline.
        </p>

        {pipelines.map((p) => (
          <PipelineEditor
            key={p.id}
            pipeline={p}
            stages={stages.filter((s) => s.pipeline_id === p.id).sort((a, b) => a.position - b.position)}
            onChanged={invalidate}
          />
        ))}

        <Separator />

        <div className="flex flex-wrap items-end gap-2">
          <div className="flex-1 min-w-[200px] space-y-1">
            <Label className="text-xs">New pipeline name</Label>
            <Input value={newPipeName} onChange={(e) => setNewPipeName(e.target.value)} placeholder="e.g. Maintenance" />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <Switch checked={newPipeAuto} onCheckedChange={setNewPipeAuto} />
            Auto-schedule on entry
          </label>
          <Button onClick={addPipeline} className="gap-1.5">
            <Plus className="h-4 w-4" /> Add pipeline
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function PipelineEditor({
  pipeline, stages, onChanged,
}: { pipeline: PipelineRow; stages: PipelineStageRow[]; onChanged: () => void }) {
  const [name, setName] = useState(pipeline.name);
  const [auto, setAuto] = useState(pipeline.auto_schedule);
  const [newStage, setNewStage] = useState("");
  const confirm = useConfirm();


  async function savePipeline() {
    try {
      await updatePipeline(pipeline.id, { name, auto_schedule: auto });
      toast.success("Pipeline saved");
      onChanged();
    } catch { toast.error("Save failed"); }
  }

  async function removePipeline() {
    if (!(await confirm({ title: `Delete pipeline "${pipeline.name}"?`, description: "Stages will be removed and deals will become unassigned. This only affects your local database — Pipedrive is untouched.", confirmLabel: "Delete", destructive: true }))) return;
    try {
      await deletePipeline(pipeline.id);
      toast.success(`Pipeline "${pipeline.name}" deleted`);
      onChanged();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  }

  async function addStage() {
    if (!newStage.trim()) return;
    try {
      await createStage({ pipeline_id: pipeline.id, name: newStage.trim(), position: stages.length });
      setNewStage("");
      toast.success("Stage added");
      onChanged();
    } catch { toast.error("Add stage failed"); }
  }

  async function moveStage(stage: PipelineStageRow, dir: -1 | 1) {
    const idx = stages.findIndex((s) => s.id === stage.id);
    const swap = stages[idx + dir];
    if (!swap) return;
    try {
      await Promise.all([
        updateStage(stage.id, { position: swap.position }),
        updateStage(swap.id, { position: stage.position }),
      ]);
      toast.success("Stages reordered");
      onChanged();
    } catch { toast.error("Reorder failed"); }
  }

  async function renameStage(stage: PipelineStageRow, newName: string) {
    if (newName === stage.name) return;
    try {
      await updateStage(stage.id, { name: newName });
      toast.success("Stage renamed");
      onChanged();
    } catch { toast.error("Rename failed"); }
  }

  async function removeStage(stage: PipelineStageRow) {
    if (!(await confirm({ title: `Delete stage "${stage.name}"?`, confirmLabel: "Delete", destructive: true }))) return;
    try {
      await deleteStage(stage.id);
      toast.success("Stage deleted");
      onChanged();
    } catch { toast.error("Delete failed"); }
  }


  return (
    <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
      <div className="flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-[180px] space-y-1">
          <Label className="text-xs">Pipeline name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <Switch checked={auto} onCheckedChange={setAuto} />
          Auto-schedule
        </label>
        <Badge variant="outline" className="text-[10px] uppercase">{pipeline.kind}</Badge>
        <Button size="sm" onClick={savePipeline}>Save</Button>
        <Button size="sm" variant="ghost" className="text-rose-600" onClick={removePipeline}>
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs uppercase tracking-wide text-muted-foreground">Stages</Label>
        {stages.map((s, i) => (
          <div key={s.id} className="flex items-center gap-2 rounded border bg-card p-2">
            <span className="w-6 text-center text-xs text-muted-foreground tabular-nums">{i + 1}</span>
            <Input
              defaultValue={s.name}
              onBlur={(e) => renameStage(s, e.target.value)}
              className="h-8"
            />
            <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === 0} onClick={() => moveStage(s, -1)}>
              <ArrowUp className="h-3.5 w-3.5" />
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === stages.length - 1} onClick={() => moveStage(s, 1)}>
              <ArrowDown className="h-3.5 w-3.5" />
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7 text-rose-600" onClick={() => removeStage(s)}>
              <X className="h-3.5 w-3.5" />
            </Button>
          </div>
        ))}
        <div className="flex gap-2 pt-1">
          <Input
            value={newStage}
            onChange={(e) => setNewStage(e.target.value)}
            placeholder="New stage name…"
            onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addStage())}
            className="h-8"
          />
          <Button size="sm" variant="outline" onClick={addStage} className="gap-1">
            <Plus className="h-3.5 w-3.5" /> Add stage
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Financial Settings (Phase 2.2) ---------------- */

function FinancialSettings() {
  const qc = useQueryClient();
  const { data: settings } = useQuery(appSettingsQuery);
  const [saving, setSaving] = useState(false);

  const [allocation, setAllocation] = useState<string>(settings?.revenue_allocation_method ?? "prorated_progress");
  const [recognition, setRecognition] = useState<string>(settings?.revenue_recognition_method ?? "progress_percent");
  const [green, setGreen] = useState<number>(Number(settings?.traffic_light_green_pct ?? 95));
  const [amber, setAmber] = useState<number>(Number(settings?.traffic_light_amber_pct ?? 80));
  const [fyMonth, setFyMonth] = useState<number>(Number(settings?.financial_year_start_month ?? 7));
  const [progressBilling, setProgressBilling] = useState<boolean>(!!settings?.progress_billing_enabled);

  // Sync state when data arrives
  useEffect(() => {
    if (!settings) return;
    setAllocation(settings.revenue_allocation_method);
    setRecognition(settings.revenue_recognition_method);
    setGreen(Number(settings.traffic_light_green_pct));
    setAmber(Number(settings.traffic_light_amber_pct));
    setFyMonth(Number(settings.financial_year_start_month));
    setProgressBilling(!!settings.progress_billing_enabled);
  }, [settings]);


  async function save() {
    setSaving(true);
    try {
      await upsertAppSettings({
        revenue_allocation_method: allocation as never,
        revenue_recognition_method: recognition as never,
        traffic_light_green_pct: green,
        traffic_light_amber_pct: amber,
        financial_year_start_month: fyMonth,
        progress_billing_enabled: progressBilling,
      });
      toast.success("Financial settings saved");
      qc.invalidateQueries({ queryKey: ["app_settings"] });
    } catch (e) {
      toast.error("Could not save financial settings");
    } finally { setSaving(false); }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-muted-foreground" /> Financial engine
          <Badge variant="outline" className="ml-2 text-xs">Phase 2</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Revenue allocation method" hint="How contract value is spread across months.">
            <Select value={allocation} onValueChange={setAllocation}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="start_month">Start month — full value in start month</SelectItem>
                <SelectItem value="prorated_dates">Prorated by scheduled dates</SelectItem>
                <SelectItem value="prorated_progress">Prorated by progress %</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Revenue recognition" hint="How earned revenue is calculated.">
            <Select value={recognition} onValueChange={setRecognition}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="on_completion">On completion</SelectItem>
                <SelectItem value="progress_percent">Progress % of contract</SelectItem>
                <SelectItem value="milestone">Milestone-based</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Traffic-light: Green ≥ (%)">
            <Input type="number" value={green} min={50} max={200} onChange={(e) => setGreen(Number(e.target.value))} />
          </Field>
          <Field label="Traffic-light: Amber ≥ (%)">
            <Input type="number" value={amber} min={0} max={200} onChange={(e) => setAmber(Number(e.target.value))} />
          </Field>
          <Field label="Financial year start month" hint="1 = Jan, 7 = Jul (AU).">
            <Input type="number" value={fyMonth} min={1} max={12} onChange={(e) => setFyMonth(Number(e.target.value))} />
          </Field>
          <ToggleRow
            label="Progress billing enabled"
            hint="Allow invoicing % complete before job finish."
            checked={progressBilling}
            onChange={setProgressBilling}
          />
        </div>
        <div className="flex justify-end">
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save financial settings"}</Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- Revenue Targets Manager (Phase 2.2) ---------------- */

function RevenueTargetsManager() {
  const qc = useQueryClient();
  const { data: targets = [] } = useQuery(revenueTargetsQuery);
  const { data: crews = [] } = useQuery(crewsQuery);

  const [scope, setScope] = useState<RevenueTargetRow["scope"]>("company");
  const [scopeRef, setScopeRef] = useState<string>("");
  const [period, setPeriod] = useState<RevenueTargetRow["period"]>("month");
  const [periodStart, setPeriodStart] = useState<string>(new Date().toISOString().slice(0, 8) + "01");
  const [amount, setAmount] = useState<number>(0);

  function invalidate() { qc.invalidateQueries({ queryKey: ["revenue_targets"] }); }

  async function addTarget() {
    if (!amount || amount <= 0) { toast.error("Enter a target amount"); return; }
    if (scope !== "company" && !scopeRef) { toast.error("Select the scope reference"); return; }
    try {
      await createRevenueTarget({
        scope, scope_ref: scope === "company" ? null : scopeRef,
        period, period_start: periodStart, target_amount: amount, notes: null,
      });
      toast.success("Target added");
      setAmount(0); setScopeRef("");
      invalidate();
    } catch { toast.error("Could not add target"); }
  }

  async function removeTarget(id: string) {
    try { await deleteRevenueTarget(id); toast.success("Target removed"); invalidate(); }
    catch { toast.error("Could not remove target"); }
  }

  async function editAmount(id: string, val: number) {
    try { await updateRevenueTarget(id, { target_amount: val }); invalidate(); }
    catch { toast.error("Could not update target"); }
  }

  const fmt = (n: number) => n >= 1_000_000 ? `$${(n/1_000_000).toFixed(2)}M` : `$${(n/1000).toFixed(0)}k`;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-4 w-4 text-muted-foreground" /> Revenue targets
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-6 items-end">
          <Field label="Scope">
            <Select value={scope} onValueChange={(v) => { setScope(v as RevenueTargetRow["scope"]); setScopeRef(""); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="company">Company-wide</SelectItem>
                <SelectItem value="crew">Crew</SelectItem>
                <SelectItem value="division">Division</SelectItem>
                <SelectItem value="region">Region</SelectItem>
                <SelectItem value="business_unit">Business unit</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          {scope === "crew" ? (
            <Field label="Crew">
              <Select value={scopeRef} onValueChange={setScopeRef}>
                <SelectTrigger><SelectValue placeholder="Select crew" /></SelectTrigger>
                <SelectContent>
                  {crews.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
          ) : scope === "company" ? (
            <div className="text-xs text-muted-foreground sm:col-span-1">—</div>
          ) : (
            <Field label={scope.charAt(0).toUpperCase() + scope.slice(1)}>
              <Input value={scopeRef} onChange={(e) => setScopeRef(e.target.value)} placeholder="e.g. NSW" />
            </Field>
          )}
          <Field label="Period">
            <Select value={period} onValueChange={(v) => setPeriod(v as RevenueTargetRow["period"])}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="month">Month</SelectItem>
                <SelectItem value="week">Week</SelectItem>
                <SelectItem value="day">Day</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Period start">
            <Input type="date" value={periodStart} onChange={(e) => setPeriodStart(e.target.value)} />
          </Field>
          <Field label="Target amount ($)">
            <Input type="number" value={amount || ""} onChange={(e) => setAmount(Number(e.target.value))} placeholder="0" />
          </Field>
          <Button onClick={addTarget} className="gap-1"><Plus className="h-4 w-4" /> Add target</Button>
        </div>

        <Separator />

        <div className="space-y-1.5">
          {targets.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">No revenue targets yet.</div>}
          {targets.map((t) => {
            const crewName = t.scope === "crew" ? (crews.find((c) => c.id === t.scope_ref)?.name ?? t.scope_ref) : t.scope_ref;
            return (
              <div key={t.id} className="flex items-center gap-3 rounded-md border border-border px-3 py-2">
                <Badge variant="outline" className="capitalize">{t.scope}</Badge>
                {crewName && <span className="text-sm font-medium">{crewName}</span>}
                <span className="text-xs text-muted-foreground">
                  {t.period} · {new Date(t.period_start).toLocaleDateString(undefined, { month: "short", year: "numeric" })}
                </span>
                <div className="ml-auto flex items-center gap-2">
                  <Input
                    type="number"
                    defaultValue={Number(t.target_amount)}
                    onBlur={(e) => {
                      const v = Number(e.target.value);
                      if (v !== Number(t.target_amount)) editAmount(t.id, v);
                    }}
                    className="h-8 w-32 text-right"
                  />
                  <span className="text-xs text-muted-foreground w-16 tabular-nums">{fmt(Number(t.target_amount))}</span>
                  <Button size="icon" variant="ghost" className="h-7 w-7 text-rose-600" onClick={() => removeTarget(t.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

function AccessRolesCard() {
  const qc = useQueryClient();
  const { data: myRoles = [], isLoading } = useMyRoles();
  const [busy, setBusy] = useState<AppRole | null>(null);

  const allRoles: AppRole[] = ["owner", "ops_manager", "crew_leader", "contractor", "admin"];

  async function grant(role: AppRole) {
    setBusy(role);
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) {
        toast.error("Sign in required to change roles.");
        return;
      }
      const { error } = await supabase
        .from("user_roles" as never)
        .insert({ user_id: userData.user.id, role } as never);
      if (error && !/duplicate|unique/i.test(error.message)) throw error;
      await qc.invalidateQueries({ queryKey: ["my-roles"] });
      toast.success(`Granted ${ROLE_LABELS[role]}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to grant role";
      toast.error(msg);
    } finally {
      setBusy(null);
    }
  }

  async function revoke(role: AppRole) {
    setBusy(role);
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;
      const { error } = await supabase
        .from("user_roles" as never)
        .delete()
        .eq("user_id", userData.user.id)
        .eq("role", role);
      if (error) throw error;
      await qc.invalidateQueries({ queryKey: ["my-roles"] });
      toast.success(`Removed ${ROLE_LABELS[role]}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to remove role";
      toast.error(msg);
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-primary" /> Access & roles
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Your active roles control what you can edit (contractor assignments, revenue targets, admin tools).
          If you're the first user, grant yourself <span className="font-medium">Owner</span> to unlock everything.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs uppercase tracking-wide text-muted-foreground">Active</span>
          {isLoading ? (
            <span className="text-sm text-muted-foreground">Loading…</span>
          ) : myRoles.length === 0 ? (
            <Badge variant="outline" className="text-xs">No roles assigned</Badge>
          ) : (
            myRoles.map((r) => (
              <Badge key={r} className="text-xs">{ROLE_LABELS[r]}</Badge>
            ))
          )}
        </div>
        <Separator />
        <div className="grid gap-2 sm:grid-cols-2">
          {allRoles.map((r) => {
            const has = myRoles.includes(r);
            return (
              <div
                key={r}
                className="flex items-center justify-between rounded-md border border-border px-3 py-2"
              >
                <div>
                  <div className="text-sm font-medium">{ROLE_LABELS[r]}</div>
                  <div className="text-xs text-muted-foreground font-mono">{r}</div>
                </div>
                {has ? (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy === r}
                    onClick={() => revoke(r)}
                  >
                    Remove
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    disabled={busy === r}
                    onClick={() => grant(r)}
                  >
                    {busy === r ? "Granting…" : "Grant"}
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}



